/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:21:42 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:35:55 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_LS_H
# define FT_LS_H

# include <stdio.h>
# include <sys/stat.h>
# include <time.h>
# include <string.h>
# include <stdlib.h>
# include <errno.h>
# include <fcntl.h>
# include <pwd.h>
# include <grp.h>
# include <dirent.h>
# include <sys/types.h>
# include <sys/xattr.h>
# include <sys/types.h>
# include <sys/acl.h>

# include "../libft/libft.h"

typedef struct		s_file
{
	char			ex_attri;
	char			*f_name;
	char			*perms;
	char			*uid;
	char			*gid;
	char			*mtime;
	int				myear;
	int				mmonth;
	int				mday;
	long long int	msecond;
	char			link[120];
	int				nlink;
	char			*f_size;
	int				is_file;
	struct s_file	*next;
}					t_file;

typedef struct		s_flag
{
	int				l;
	int				bigr;
	int				a;
	int				r;
	int				t;
	int				i;
	char			illegal;
}					t_flag;

/*
** I, Giorno Giovanna, have a piano;
*/

/*
** print
*/
void				ls_print(t_file **file, t_flag *f, char path[1024],
int z);
int					ls_print_non_valid(t_file **non_valid);
int					ls_print_regular_file(t_file **file, t_flag *f);
void				ls_print_world(t_file **d_file,
t_file **non_valid, t_file **file, t_flag *f);
int					print_l_flag_on(t_file **tmp);
int					print_l_flag_off(t_file **tmp);
/*
** info
*/
char				file_type(struct stat f_stat);
/*
** get_file
*/
void				get_file(char **gv, t_flag *f);
void				get_file_one(t_flag *f, char path[1024]);
int					get_file_a(t_file **d_file, t_flag *f,
t_file **file);
int					get_file_b(t_flag *f, char path[1024],
t_file **file);
/*
** time convert
*/
void				get_mmonth_convert(char *str, t_file **node);
void				get_mtime_i(struct stat f_stat, t_file **node);
/*
** s_file
*/
void				ls_push(t_file **head, char *f_name, char path[1024]);
void				ls_destroyer(t_file **head);
/*
** get_flag
*/
int					ls_flag(int gc, char **gv, t_flag *f);
/*
** get attributes
*/
char				*get_perms(struct stat f_stat);
int					get_attr(char path[1024]);
char				*get_uid(struct stat f_stat);
char				*get_gid(struct stat f_stat);
char				*get_fsize(struct stat f_stat);
char				*get_mtime(struct stat f_stat);
void				get_link(char buf[200], char tmp[1024]);
long long int		get_total(t_file **file);
/*
** sort
*/
void				ls_sort_rev(t_file **head);
void				ls_sort_mtime(t_file **head);
void				ls_sort_alpha(t_file **head);
void				ls_sort_world(t_file **head, t_flag *f);

#endif
