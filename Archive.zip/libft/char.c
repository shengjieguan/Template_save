/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   char.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 16:40:43 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 16:40:46 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	get_char(va_list ar, t_struct *k)
{
	unsigned char	c;
	char			*zero;
	char			*spc;

	k->width--;
	zero = fillzero(k->width);
	spc = fillspc(k->width);
	c = (unsigned char)va_arg(ar, int);
	if (c == (int)NULL)
		c = '\0';
	if (k->width > 0 && k->minus == 0 && k->w_neg == 0)
	{
		k->nprint += (k->zero == 1) ?
		write(1, zero, k->width) : write(1, spc, k->width);
		k->nprint += write(1, &c, 1);
	}
	else if (k->width > 0 && (k->minus == 1 || k->w_neg == 1))
	{
		k->nprint += write(1, &c, 1);
		k->nprint += write(1, spc, k->width);
	}
	else
		k->nprint += write(1, &c, 1);
	ft_strdel(&zero);
	ft_strdel(&spc);
}

void	get_percent(t_struct *k)
{
	char			*zero;
	char			*spc;

	k->width--;
	zero = fillzero(k->width);
	spc = fillspc(k->width);
	if (k->width > 1 && k->minus == 0 && k->w_neg == 0)
	{
		k->nprint += (k->zero == 1) ?
		write(1, zero, k->width) : write(1, spc, k->width);
		k->nprint += write(1, "%", 1);
	}
	else if (k->width > 1 && (k->minus == 1 || k->w_neg == 1))
	{
		k->nprint += write(1, "%", 1);
		k->nprint += write(1, spc, k->width);
	}
	else
		k->nprint += write(1, "%", 1);
	ft_strdel(&zero);
	ft_strdel(&spc);
}
