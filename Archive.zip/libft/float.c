/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   float.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 16:50:45 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 16:50:46 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void			get_width(t_struct *k, long long int pre_int,
long double post_int, int neg)
{
	int n_preint;

	n_preint = ft_numlen(pre_int);
	if (k->space == 1 && k->plus == 0 && neg == 0)
	{
		k->nprint += write(1, " ", 1);
		k->width--;
	}
	if (neg == 1)
		k->width--;
	if (k->plus == 1 && neg == 0)
		k->width -= 1;
	if (k->precis > 0)
		k->width -= n_preint + ft_numlen((long long int)post_int) + 1;
	else
		k->width -= n_preint;
}

static long double	get_post_int(long double f,
long long int *pre_int, t_struct *k)
{
	long double post_int;

	post_int = f - (long double)(*pre_int);
	post_int *= (k->precis >= 0) ? cifang(10, (k->precis + 1)) : cifang(10, 7);
	if ((long long int)post_int % 10 >= 5)
		post_int += 10;
	return (post_int);
}

void				get_float(va_list ar, t_struct *k)
{
	long double		f;
	long long int	pre_int;
	long double		post_int;
	int				neg;
	long long int	n;

	n = 1;
	n *= (k->precis >= 0) ? cifang(10, (k->precis) - 1) : cifang(10, 5);
	neg = 0;
	if (k->length == BIGL)
		f = (long double)va_arg(ar, long double);
	else
		f = (long double)va_arg(ar, double);
	neg = (f < 0) ? 1 : 0;
	f *= (f < 0) ? -1 : 1;
	pre_int = (long long int)f;
	post_int = get_post_int(f, &pre_int, k);
	k->n_zero = ft_numlen(n) - ft_numlen((long long int)post_int);
	if (k->n_zero <= 0 && (long long int)post_int >= 5)
		pre_int += (k->precis == 0) ? 1 : 0;
	post_int /= 10;
	k->n_zero = ft_numlen(n) - ft_numlen((long long int)post_int);
	get_width(k, pre_int, post_int, neg);
	output_f(k, pre_int, post_int, neg);
}
