/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   float_two.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 16:48:01 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 16:48:02 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	left_align_extend_two(t_struct *k, t_norm a, int neg)
{
	char	*spc_w;
	char	*n_zero;

	n_zero = fillzero(k->n_zero);
	spc_w = fillspc(k->width);
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	k->nprint += (k->plus == 1 && neg == 0) ? write(1, "+", 1) : 0;
	k->nprint += (neg == 1) ? write(1, "-", 1) : 0;
	k->nprint += write(1, &a.pre[0], ft_strlen(a.pre));
	if (k->hash == 1 || k->precis != 0)
		k->nprint += write(1, ".", 1);
	if (k->n_zero > 0)
		k->nprint += write(1, n_zero, k->n_zero);
	if (k->precis != 0)
		k->nprint += write(1, &a.post[0], ft_strlen(a.post));
	ft_strdel(&spc_w);
	ft_strdel(&n_zero);
}

static void	left_align_extend_one(t_struct *k, long long int pre_int,
long double post_int, int neg)
{
	t_norm	a;
	char	*zero_w;
	char	*n_zero;

	a.pre = ft_itoa_l(pre_int);
	a.post = ft_itoa_l(post_int);
	zero_w = fillzero(k->width);
	n_zero = fillzero(k->n_zero);
	k->nprint += (k->plus == 1 && neg == 0) ? write(1, "+", 1) : 0;
	k->nprint += (neg == 1) ? write(1, "-", 1) : 0;
	if (k->width > 0)
		k->nprint += write(1, zero_w, k->width);
	k->nprint += write(1, &a.pre[0], ft_strlen(a.pre));
	if (k->hash == 1 || k->precis != 0)
		k->nprint += write(1, ".", 1);
	if (k->n_zero > 0)
		k->nprint += write(1, n_zero, k->n_zero);
	if (k->precis != 0)
		k->nprint += write(1, &a.post[0], ft_strlen(a.post));
	ft_strdel(&zero_w);
	ft_strdel(&n_zero);
	ft_strdel(&a.pre);
	ft_strdel(&a.post);
}

static void	left_align(t_struct *k, long long int pre_int,
long double post_int, int neg)
{
	t_norm a;

	a.pre = ft_itoa_l(pre_int);
	a.post = ft_itoa_l(post_int);
	if (k->zero == 1 && k->precis < 0)
		left_align_extend_one(k, pre_int, post_int, neg);
	else
		left_align_extend_two(k, a, neg);
	ft_strdel(&a.pre);
	ft_strdel(&a.post);
}

static void	right_align(t_struct *k, long long int pre_int,
long double post_int, int neg)
{
	t_norm	a;
	char	*n_zero;
	char	*spc_w;

	n_zero = fillzero(k->n_zero);
	spc_w = fillspc(k->width);
	a.pre = ft_itoa_l(pre_int);
	a.post = ft_itoa_l(post_int);
	if (k->plus == 1 && neg == 0)
		k->nprint += write(1, "+", 1);
	if (neg == 1)
		k->nprint += write(1, "-", 1);
	k->nprint += write(1, &a.pre[0], ft_strlen(a.pre));
	if (k->hash == 1 || k->precis != 0)
		k->nprint += write(1, ".", 1);
	if (k->n_zero > 0)
		k->nprint += write(1, n_zero, k->n_zero);
	if (k->precis != 0)
		k->nprint += write(1, &a.post[0], ft_strlen(a.post));
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&a.pre);
	ft_strdel(&a.post);
	ft_strdel(&n_zero);
	ft_strdel(&spc_w);
}

void		output_f(t_struct *k, long long int pre_int,
long double post_int, int neg)
{
	if (k->minus == 0)
		left_align(k, pre_int, post_int, neg);
	else
		right_align(k, pre_int, post_int, neg);
}
