/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 20:01:50 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/16 20:01:51 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int				ft_atoi(const char *str)
{
	unsigned int		i;
	char				sign;
	unsigned long long	r;

	i = 0;
	sign = 1;
	r = 0;
	while (str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
	|| str[i] == '\r' || str[i] == ' ' || str[i] == '\f')
		i++;
	if (str[i] == '+')
		i++;
	else if (str[i] == '-')
	{
		sign = 0;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
		r = 10 * r + str[i++] - '0';
	return (int)((sign) ? (r) : (-r));
}

long long int	ft_atolli(const char *str)
{
	unsigned int		i;
	char				sign;
	long long int		r;

	i = 0;
	sign = 1;
	r = 0;
	while (str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
	|| str[i] == '\r' || str[i] == ' ' || str[i] == '\f')
		i++;
	if (str[i] == '+')
		i++;
	else if (str[i] == '-')
	{
		sign = 0;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
		r = 10 * r + str[i++] - '0';
	return ((sign) ? (r) : (-r));
}
