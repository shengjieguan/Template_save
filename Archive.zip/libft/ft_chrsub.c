/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_chrsub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/05 16:15:40 by xzhan             #+#    #+#             */
/*   Updated: 2019/10/05 16:15:41 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_chrsub(char *str, int c, char sub)
{
	int		i;
	char	*chrsub;

	i = 0;
	if (!(chrsub = (char*)malloc(sizeof(char) * (ft_strlen(str) + 1))))
		return (NULL);
	while (str[i] != '\0')
	{
		if (str[i] == c)
			chrsub[i] = sub;
		else
			chrsub[i] = str[i];
		i++;
	}
	chrsub[i] = '\0';
	return (chrsub);
}
