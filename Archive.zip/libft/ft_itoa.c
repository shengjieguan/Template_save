/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/19 12:18:24 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/19 12:18:27 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	len(int n)
{
	int	size;

	size = 0;
	while (n /= 10)
		size++;
	return (size + 1);
}

char		*ft_itoa(int n)
{
	char			*a;
	unsigned int	size;
	unsigned int	nb;
	unsigned int	index;

	nb = (n >= 0 ? (unsigned int)n : (unsigned int)(n * -1));
	size = len(nb);
	if (!(a = (char*)(malloc(size + 1 + (n < 0 ? 1 : 0)))))
		return (NULL);
	if (n < 0)
	{
		a[0] = '-';
		size++;
	}
	index = size - 1;
	while (nb >= 10)
	{
		a[index--] = (char)(nb % 10 + 48);
		nb /= 10;
	}
	a[index] = (char)(nb % 10 + 48);
	a[size] = '\0';
	return (a);
}
