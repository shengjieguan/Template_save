/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/26 12:13:11 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/26 12:13:18 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, t_list *(*f)(t_list *elem))
{
	t_list	*a;
	t_list	*b;

	if (!lst)
		return (NULL);
	a = f(lst);
	b = a;
	while (lst->next)
	{
		lst = lst->next;
		a->next = f(lst);
		a = a->next;
	}
	return (b);
}
