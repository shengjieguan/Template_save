/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 17:17:25 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/16 18:04:50 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memccpy(void *restrict dest, const void *restrict src,
int c, size_t n)
{
	unsigned char	*cdest;
	unsigned char	*csrc;
	size_t			i;

	cdest = (unsigned char*)dest;
	csrc = (unsigned char*)src;
	i = 0;
	while (i < n)
	{
		cdest[i] = (unsigned char)csrc[i];
		if (cdest[i] == ((unsigned char)c))
			return (dest + i + 1);
		i++;
	}
	return (NULL);
}
