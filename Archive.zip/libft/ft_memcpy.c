/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 16:57:07 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/16 16:57:08 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *to, const void *from, size_t a)
{
	unsigned char		*dest;
	unsigned char		*src;

	dest = (unsigned char*)to;
	src = (unsigned char*)from;
	if (!a || dest == src)
		return (dest);
	while (a-- > 0)
		*(dest++) = *(src++);
	return (to);
}
