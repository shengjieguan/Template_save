/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 11:44:14 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/17 11:44:17 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dst, const void *src, size_t len)
{
	unsigned char			*cdest;
	const unsigned char		*csrc;
	size_t					i;

	if (dst == src || len == 0)
		return (dst);
	i = 1;
	cdest = (unsigned char*)dst;
	csrc = (unsigned char*)src;
	if (cdest > csrc)
		while (i <= len)
		{
			cdest[len - i] = csrc[len - i];
			i++;
		}
	else
		while (len-- > 0)
			*(cdest++) = *(csrc++);
	return (dst);
}
