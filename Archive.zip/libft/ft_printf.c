/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   printf.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/25 13:17:08 by xzhan             #+#    #+#             */
/*   Updated: 2019/10/25 13:29:33 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		init(t_struct *k)
{
	k->w_neg = 0;
	k->n_zero = 0;
	k->n = 0;
	k->i = 0;
	k->width = 0;
	k->precis = -1;
	k->minus = 0;
	k->zero = 0;
	k->plus = 0;
	k->hash = 0;
	k->space = 0;
	k->length = 0;
	k->nprint = 0;
}

void		reset(t_struct *k)
{
	k->w_neg = 0;
	k->n_zero = 0;
	k->n = 0;
	k->width = 0;
	k->precis = -1;
	k->minus = 0;
	k->zero = 0;
	k->plus = 0;
	k->hash = 0;
	k->space = 0;
	k->length = 0;
}

static int	parse(t_struct *k, int index, const char *restrict fmt, va_list ar)
{
	k->i = index;
	while (!(ft_strchr("-+ #0123456789.*hlLcspdiouxXf%", fmt[k->i])))
		k->i++;
	if (ft_strchr("-+ #0123456789.*hlL", fmt[k->i]))
		regulate(k, fmt, ar);
	if (!fmt[k->i] && fmt[k->i] == '\0')
		return (-1);
	if (ft_strchr("cspdiouxXf%", fmt[k->i]))
	{
		separate(fmt, ar, k);
		reset(k);
	}
	return (k->i);
}

int			fmt_p(const char *restrict fmt, va_list ar, int index, t_struct *k)
{
	int n;

	n = 0;
	while (fmt[index] != '\0')
	{
		if (fmt[index] != '%' && fmt[index])
		{
			while (fmt[index + n] != '%' && fmt[index + n])
				n++;
			k->nprint += write(1, &fmt[index], n);
			index += n - 1;
			n = 0;
		}
		else if (fmt[index] == '%')
		{
			index++;
			index = parse(k, index, fmt, ar);
		}
		if (index == -1)
			return (0);
		index++;
	}
	return (k->nprint);
}

int			ft_printf(const char *restrict format, ...)
{
	va_list		ar;
	int			w_len;
	t_struct	*k;

	if (!(k = (t_struct*)malloc(sizeof(t_struct))))
		return (0);
	init(k);
	va_start(ar, format);
	if (!format[0] || ((int)ft_strlen(format) == 1 && format[0] == '%'))
	{
		free(k);
		return (0);
	}
	else
		w_len = fmt_p(format, ar, 0, k);
	va_end(ar);
	free(k);
	return (w_len);
}
