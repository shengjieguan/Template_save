/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/19 09:26:14 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/19 09:26:14 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*s3;
	char	*tmp;
	int		a;
	int		b;

	a = 0;
	b = 0;
	while (s1[a])
		a++;
	while (s2[b])
		b++;
	if (!s1 || !s2 || !(s3 = (char*)malloc(sizeof(char) * (a + b + 1))))
		return (NULL);
	tmp = s3;
	while (*s1 != '\0')
		*(tmp++) = *(s1++);
	while (*s2 != '\0')
		*(tmp++) = *(s2++);
	*tmp = '\0';
	return (s3);
}
