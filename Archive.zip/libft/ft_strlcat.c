/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 20:35:54 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/16 20:35:55 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *restrict dst, const char *restrict src
, size_t dstsize)
{
	size_t i;
	size_t a;
	size_t len;

	a = 0;
	i = 0;
	len = 0;
	while (dst[a] != '\0')
		a++;
	while (src[len] != '\0')
		len++;
	if (a >= dstsize)
		len += dstsize;
	else
		len += a;
	while (a + 1 < dstsize && src[i])
	{
		dst[a] = src[i];
		i++;
		a++;
	}
	dst[a] = '\0';
	return (len);
}
