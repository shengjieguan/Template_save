/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/18 14:54:27 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/18 14:54:27 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmap(char const *s, char (*f)(char))
{
	char *a;
	char *b;
	char *c;

	if (!s || !(c = (char*)malloc(sizeof(char) * (ft_strlen(s) + 1))))
		return (NULL);
	a = (char*)s;
	b = c;
	while (*a)
		*(b++) = f(*(a++));
	*b = '\0';
	return (c);
}
