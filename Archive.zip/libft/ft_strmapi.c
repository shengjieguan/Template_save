/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/18 15:22:04 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/18 15:22:05 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	char			*a;
	unsigned int	i;

	i = -1;
	if (!s)
		return (NULL);
	if (!(a = (char*)malloc(sizeof(*a) * (ft_strlen((char*)s) + 1))))
		return (NULL);
	while (s[++i])
		a[i] = f(i, s[i]);
	a[i] = '\0';
	return (a);
}
