/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/18 09:39:00 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/18 09:39:04 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	strcmpp(const char *s1, const char *s2, int len)
{
	size_t	i;

	i = 0;
	while (s2[i] && len-- != -1)
	{
		if (s1[i] == s2[i])
			i++;
		else
			return (-100000);
	}
	if (s2[i] == '\0')
		return (1);
	return (0);
}

char		*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t	i;

	i = 0;
	if (!(*needle))
		return ((char*)haystack);
	while (haystack[i] && len--)
	{
		if (haystack[i] == needle[0])
		{
			if (strcmpp(haystack + i, needle, (int)len) == 1)
				return (char*)(haystack + i);
		}
		i++;
	}
	return (NULL);
}
