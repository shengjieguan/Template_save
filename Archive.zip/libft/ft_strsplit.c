/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/19 09:55:18 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/19 09:55:19 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	len(char const *s, char c)
{
	int	i;
	int count;

	count = 0;
	i = 0;
	while (s[i])
	{
		if (s[i] != c)
			count++;
		i++;
	}
	return (count);
}

static int	len1(char const *s, char c)
{
	int	len;

	len = 0;
	while (s && s[len] != c)
		len++;
	return (len);
}

char		**ft_strsplit(char const *s, char c)
{
	int		i;
	char	**a;
	int		j;

	j = 0;
	i = 0;
	if (!s || !(a = (char**)malloc(sizeof(char*) * (len(s, c) + 1))))
		return (NULL);
	while (*s)
	{
		while (*s == c && *s != '\0')
			s++;
		if (*s != c && *s != '\0')
		{
			if (!(a[i] = (char*)malloc(sizeof(char) * (len1(s, c)))))
				return (NULL);
			while (*s != c && *s != '\0')
				a[i][j++] = (char)*s++;
			a[i][j] = '\0';
			i++;
			j = 0;
		}
	}
	a[i] = NULL;
	return (a);
}
