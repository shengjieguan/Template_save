/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 18:00:01 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/17 18:07:13 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strstr(const char *haystack, const char *needle)
{
	int len;
	int i;

	if (needle[0] == '\0')
		return ((char*)haystack);
	i = 0;
	len = ft_strlen((char*)needle);
	while (haystack[i] != '\0')
	{
		if (ft_strncmp(&haystack[i], needle, len) == 0)
			return ((char*)&haystack[i]);
		i++;
	}
	return (0);
}
