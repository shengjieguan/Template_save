/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/19 09:39:30 by xzhan             #+#    #+#             */
/*   Updated: 2019/09/19 09:39:30 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	isspa(char s)
{
	if (s == ' ' || s == '\n' || s == '\t')
		return (1);
	return (0);
}

char		*ft_strtrim(char const *s)
{
	int	i;
	int	j;

	if (!s)
		return (NULL);
	j = ft_strlen(s);
	i = 0;
	while (isspa(s[i]) && s[i])
		i++;
	while (isspa(s[j - 1]) && i < j)
		j--;
	if (i == j)
		return (ft_strnew(1));
	return ((ft_strsub(s, i, j - i)));
}
