/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   helper.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/11 16:51:40 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/11 16:51:41 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	num_len(long long int nb)
{
	long long int	len;

	len = 0;
	if (nb < 0)
	{
		nb = nb * -1;
		len++;
	}
	while (nb > 0)
	{
		nb = nb / 10;
		len++;
	}
	return (len);
}

char		*ft_itoa_l(long long int nb)
{
	char				*str;
	long long int		n;
	int					i;

	n = nb;
	i = num_len(n);
	if (!(str = (char*)malloc(sizeof(char) * (i + 1))))
		return (NULL);
	str[i--] = '\0';
	if (n == 0)
	{
		str[0] = 48;
		return (str);
	}
	if (n < 0)
	{
		str[0] = '-';
		n = n * -1;
	}
	while (n > 0)
	{
		str[i--] = 48 + (n % 10);
		n = n / 10;
	}
	return (str);
}

char		*ft_strndup(char *str, int n)
{
	char	*new_str;
	int		i;

	i = 0;
	if (!(new_str = (char*)malloc(sizeof(char) * (n + 1))))
		return (NULL);
	while (i < n)
	{
		new_str[i] = str[i];
		i++;
	}
	new_str[n] = '\0';
	return (new_str);
}

static int	ft_abs(long long int num)
{
	if (num < 0)
		num *= -1;
	return (num);
}

char		*ft_lltoa(long long int num, int base, signed char isupper)
{
	char			*res;
	size_t			size;
	long long int	temp;
	char			*g_ubase;
	char			*g_lbase;

	g_ubase = "0123456789ABCDEF";
	g_lbase = "0123456789abcdef";
	if (base == 10)
		return (ft_itoa_l(num));
	size = 2;
	temp = num;
	while ((temp /= base) != 0)
		size++;
	if (!(res = (char*)malloc(sizeof(char) * size)))
		return (NULL);
	res[--size] = '\0';
	res[--size] = (isupper == 1) ? g_ubase[ft_abs(num % base)] :\
		g_lbase[ft_abs(num % base)];
	while (num /= base)
		res[--size] = (isupper == 1) ? g_ubase[ft_abs(num % base)] :\
		g_lbase[ft_abs(num % base)];
	return (res);
}
