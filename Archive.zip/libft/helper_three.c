/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   helper_three.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/26 09:33:07 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/26 09:33:08 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*fillzero(int num)
{
	char	*str;
	int		i;

	i = 0;
	if (!(str = (char*)malloc(sizeof(char) * (num + 1))))
		return (NULL);
	while (i < num)
		str[i++] = '0';
	str[i] = '\0';
	return (str);
}

char	*fillspc(int num)
{
	char	*str;
	int		i;

	i = 0;
	if (!(str = (char*)malloc(sizeof(char) * (num + 1))))
		return (NULL);
	while (i < num)
		str[i++] = ' ';
	str[i] = '\0';
	return (str);
}
