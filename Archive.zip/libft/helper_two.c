/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   helperXD.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/12 20:44:51 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/12 20:44:52 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int			cifang(int num, int times)
{
	if (times <= 0)
		return (1);
	while (times > 1)
	{
		num *= 10;
		times--;
	}
	return (num);
}

int			ft_numlen(long long int num)
{
	int i;

	i = 0;
	if (num == 0)
		return (1);
	while (num > 0)
	{
		i++;
		num /= 10;
	}
	return (i);
}

char		*ft_lltoa_u(unsigned long long int num, int base,
signed char isupper)
{
	char						*res;
	size_t						size;
	unsigned long long int		temp;
	char						*g_ubase;
	char						*g_lbase;

	g_ubase = "0123456789ABCDEF";
	g_lbase = "0123456789abcdef";
	if (base == 10)
		ft_itoa_u(num);
	size = 2;
	temp = num;
	while ((temp /= base) != 0)
		size++;
	if (!(res = (char*)malloc(sizeof(char) * size)))
		return (NULL);
	res[--size] = '\0';
	res[--size] = (isupper == 1) ? g_ubase[num % base] :\
		g_lbase[num % base];
	while (num /= base)
		res[--size] = (isupper == 1) ? g_ubase[num % base] :\
		g_lbase[num % base];
	return (res);
}

static int	num_len_u(unsigned long long int nb)
{
	int		len;

	len = 0;
	while (nb > 0)
	{
		nb = nb / 10;
		len++;
	}
	return (len);
}

char		*ft_itoa_u(unsigned long long int nb)
{
	char					*str;
	unsigned long long int	n;
	int						i;

	n = nb;
	i = num_len_u(n);
	if (!(str = (char*)malloc(sizeof(char) * (i + 1))))
		return (NULL);
	str[i--] = '\0';
	if (n == 0)
	{
		str[0] = 48;
		return (str);
	}
	while (n > 0)
	{
		str[i--] = 48 + (n % 10);
		n = n / 10;
	}
	return (str);
}
