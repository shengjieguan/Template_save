/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hex.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 16:59:46 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 16:59:47 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	get_width_precis_hex(t_struct *k, int str_len)
{
	int precis;

	if (k->hash == 1)
		k->width -= 2;
	precis = 0;
	if (str_len >= k->precis)
		k->width -= str_len;
	else
	{
		k->width -= k->precis;
		precis = k->precis - str_len;
	}
	return (precis);
}

static void	output(t_struct *k, char *str, int precis, int is_upper)
{
	int str_len;

	str_len = (int)ft_strlen(str);
	precis = get_width_precis_hex(k, str_len);
	if (k->minus == 1)
		left_align_hex(k, str, precis, is_upper);
	else
		right_align_hex(k, str, precis, is_upper);
}

void		get_hex(va_list ar, t_struct *k, char ch)
{
	char			*str;
	int				is_upper;

	is_upper = (ch == 'X') ? 1 : 0;
	if (k->length == 0)
		k->n = va_arg(ar, unsigned int);
	else if (k->length == H)
		k->n = (unsigned int)va_arg(ar, unsigned int);
	else if (k->length == LL)
		k->n = (unsigned long long)va_arg(ar, unsigned long long);
	else if (k->length == L)
		k->n = (unsigned long)va_arg(ar, unsigned long);
	else if (k->length == HH)
		k->n = (unsigned char)va_arg(ar, unsigned int);
	if (k->n == 0 && (k->width > 0 || k->precis >= 0))
		str = ft_strdup("");
	else
		str = ft_lltoa_u(k->n, 16, is_upper);
	if (k->n != 0)
		output(k, str, 0, is_upper);
	else
		zero_out_hex(k);
	ft_strdel(&str);
}
