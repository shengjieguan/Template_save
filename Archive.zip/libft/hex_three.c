/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hex_two.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 16:58:50 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 16:58:51 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	zero_out_hex_extend(t_struct *k)
{
	char	*spc_w;
	char	*zero_p;

	zero_p = fillzero(k->precis);
	k->width -= (k->precis == 0) ? 0 : k->precis;
	spc_w = fillspc(k->width);
	if (k->minus == 0 && k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	if (k->precis > 0)
		k->nprint += write(1, zero_p, k->precis);
	if (k->minus == 1 && k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&spc_w);
	ft_strdel(&zero_p);
}

void		zero_out_hex(t_struct *k)
{
	char	*spc_w;
	char	*zero_w;

	if (k->precis < 0)
	{
		k->width--;
		spc_w = fillspc(k->width);
		zero_w = fillzero(k->width);
		if (k->minus == 0 && k->width > 0)
			k->nprint += (k->zero == 1) ?
		write(1, zero_w, k->width) : write(1, spc_w, k->width);
		k->nprint += write(1, "0", 1);
		if (k->minus == 1 && k->width > 0)
			k->nprint += write(1, spc_w, k->width);
		ft_strdel(&spc_w);
		ft_strdel(&zero_w);
	}
	else
		zero_out_hex_extend(k);
}
