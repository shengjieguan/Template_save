/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hex_two.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/26 09:56:11 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/26 09:56:12 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		left_align_hex(t_struct *k, char *str, int precis, int is_upper)
{
	char	*zero_p;
	char	*spc_w;

	spc_w = fillspc(k->width);
	zero_p = fillzero(precis);
	if (k->hash == 1)
		k->nprint += (is_upper == 1) ? write(1, "0X", 2) : write(1, "0x", 2);
	if (precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += write(1, &str[0], ft_strlen(str));
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&zero_p);
	ft_strdel(&spc_w);
}

static void	right_align_hex_extend(t_struct *k,
char *str, int precis, int is_upper)
{
	char	*spc_w;
	char	*zero_p;

	zero_p = fillzero(precis);
	spc_w = fillspc(k->width);
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	if (k->hash == 1 && k->n != 0)
		k->nprint += (is_upper == 1) ?
	write(1, "0X", 2) : write(1, "0x", 2);
	if (precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += write(1, &str[0], ft_strlen(str));
	ft_strdel(&spc_w);
	ft_strdel(&zero_p);
}

void		right_align_hex(t_struct *k, char *str, int precis, int is_upper)
{
	char	*zero_w;
	char	*zero_p;

	if (k->zero == 1 && k->precis < 0)
	{
		zero_w = fillzero(k->width);
		zero_p = fillzero(precis);
		if (k->hash == 1 && k->n != 0)
			k->nprint += (is_upper == 1) ?
			write(1, "0X", 2) : write(1, "0x", 2);
		if (k->width > 0)
			k->nprint += write(1, zero_w, k->width);
		if (precis > 0)
			k->nprint += write(1, zero_p, precis);
		k->nprint += write(1, &str[0], ft_strlen(str));
		ft_strdel(&zero_w);
		ft_strdel(&zero_p);
	}
	else
		right_align_hex_extend(k, str, precis, is_upper);
}
