/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   int.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 17:01:57 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 17:01:58 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	get_width(t_struct *k, int neg, int str_len)
{
	if (k->space == 1 && k->plus == 0 && neg == 0)
	{
		k->nprint += write(1, " ", 1);
		k->width--;
	}
	if (k->plus == 1 && neg == 0)
		k->width -= 1;
	if (neg == 1)
		k->width -= 1;
	if (k->precis >= str_len)
		k->width -= k->precis;
	else
		k->width -= str_len;
}

static void	get_int_extend(t_struct *k, int neg, int str_len, char *str)
{
	get_width(k, neg, str_len);
	output_int(k, str, neg, str_len);
}

void		get_int(va_list ar, t_struct *k, intmax_t n, int str_len)
{
	char		*str;
	int			neg;

	n = 0;
	if (k->length == 0)
		n = (int)va_arg(ar, int);
	if (k->length == HH)
		n = (signed char)va_arg(ar, int);
	if (k->length == H)
		n = (short int)va_arg(ar, int);
	if (k->length == L)
		n = (long int)va_arg(ar, long int);
	if (k->length == LL)
		n = (long long int)va_arg(ar, long long int);
	if (n == LLONG_MIN)
	{
		k->nprint += write(1, "-9223372036854775808", 20);
		return ;
	}
	neg = (n < 0) ? 1 : 0;
	n *= (n < 0) ? -1 : 1;
	str = (k->precis == 0 && n == 0) ? ft_strdup("") : ft_itoa_l(n);
	str_len = (int)ft_strlen(str);
	get_int_extend(k, neg, str_len, str);
	ft_strdel(&str);
}
