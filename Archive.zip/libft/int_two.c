/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   int_two.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/26 10:07:18 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/26 10:07:19 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	left_align_int(t_struct *k, char *str, int neg, int precis)
{
	char	*zero_p;
	char	*spc_w;

	spc_w = fillspc(k->width);
	zero_p = fillzero(precis);
	if (k->plus == 1 && neg == 0)
		k->nprint += write(1, "+", 1);
	if (neg == 1)
		k->nprint += write(1, "-", 1);
	if (precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += write(1, &str[0], ft_strlen(str));
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&zero_p);
	ft_strdel(&spc_w);
}

static void	right_align_int_extend(t_struct *k, char *str, int neg, int precis)
{
	char	*spc_w;
	char	*zero_p;

	zero_p = fillzero(precis);
	spc_w = fillspc(k->width);
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	if (k->plus == 1 && neg == 0)
		k->nprint += write(1, "+", 1);
	if (neg == 1)
		k->nprint += write(1, "-", 1);
	if (precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += write(1, &str[0], ft_strlen(str));
	ft_strdel(&spc_w);
	ft_strdel(&zero_p);
}

static void	right_align_int(t_struct *k, char *str, int neg, int precis)
{
	char *zero_w;

	if (k->zero == 1 && k->precis < 0)
	{
		zero_w = fillzero(k->width);
		if (k->plus == 1 && neg == 0)
			k->nprint += write(1, "+", 1);
		if (neg == 1)
			k->nprint += write(1, "-", 1);
		if (k->width > 0)
			k->nprint += write(1, zero_w, k->width);
		k->nprint += write(1, &str[0], ft_strlen(str));
		ft_strdel(&zero_w);
	}
	else
		right_align_int_extend(k, str, neg, precis);
}

void		output_int(t_struct *k, char *str, int neg, int str_len)
{
	int precis;

	precis = k->precis - str_len;
	if (k->minus == 1 || k->w_neg == 1)
		left_align_int(k, str, neg, precis);
	else
		right_align_int(k, str, neg, precis);
}
