/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   octal.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 17:06:38 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 17:06:40 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int				get_width_precis_octal(t_struct *k, int str_len)
{
	int precis;

	if (str_len >= k->precis)
	{
		if (k->hash == 1)
			k->width--;
		k->width -= str_len;
		precis = 0;
	}
	else
	{
		k->width -= k->precis;
		precis = k->precis - str_len;
	}
	return (precis);
}

static void		zero_out_extend(t_struct *k, int precis)
{
	char	*spc_w;
	char	*zero_p;

	precis = k->precis;
	k->width -= k->precis;
	spc_w = fillspc(k->width);
	zero_p = fillzero(precis);
	if (k->minus == 0 && k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	if (k->precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += (k->hash == 1 && precis == 0) ? write(1, "0", 1) : 0;
	if (k->minus == 1 && k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&spc_w);
	ft_strdel(&zero_p);
}

static void		zero_out(t_struct *k)
{
	char	*spc_w;
	char	*zero_w;

	if (k->precis < 0)
	{
		k->width--;
		zero_w = fillzero(k->width);
		spc_w = fillspc(k->width);
		if (k->minus == 0 && k->width > 0)
			k->nprint += (k->zero == 0)
		? write(1, spc_w, k->width) : write(1, zero_w, k->width);
		k->nprint += write(1, "0", 1);
		if (k->minus == 1 && k->width > 0)
			k->nprint += write(1, spc_w, k->width);
		ft_strdel(&spc_w);
		ft_strdel(&zero_w);
	}
	else
		zero_out_extend(k, 0);
}

void			get_octal(va_list ar, t_struct *k)
{
	unsigned long	n;
	char			*str;
	int				str_len;

	n = 0;
	if (k->length == 0)
		n = va_arg(ar, unsigned int);
	else if (k->length == H)
		n = (unsigned short int)va_arg(ar, unsigned int);
	else if (k->length == LL)
		n = (unsigned long long)va_arg(ar, unsigned long long);
	else if (k->length == L)
		n = (unsigned long)va_arg(ar, unsigned long);
	else if (k->length == HH)
		n = (unsigned char)va_arg(ar, unsigned int);
	str = ft_lltoa_u(n, 8, 1);
	str_len = (int)ft_strlen(str);
	if (n != 0)
		output_octal(k, str, 0, str_len);
	else
		zero_out(k);
	ft_strdel(&str);
}
