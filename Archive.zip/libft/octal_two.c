/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   octal_two.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/26 10:10:06 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/26 10:10:07 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	output_octal_extend(t_struct *k, char *str, int precis, int str_len)
{
	char	*zero_w;
	char	*zero_p;
	char	*spc_w;

	zero_w = fillzero(k->width);
	zero_p = fillzero(precis);
	spc_w = fillspc(k->width);
	if (k->width > 0)
		k->nprint += (k->zero == 1 && k->precis < 0) ?
	write(1, zero_w, k->width) : write(1, spc_w, k->width);
	k->nprint += (k->hash == 1 && precis <= str_len) ?
	write(1, "0", 1) : 0;
	if (precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += write(1, &str[0], str_len);
	ft_strdel(&zero_w);
	ft_strdel(&zero_p);
	ft_strdel(&spc_w);
}

void		output_octal(t_struct *k, char *str, int precis, int str_len)
{
	char	*zero_p;
	char	*spc_w;

	precis = get_width_precis_octal(k, str_len);
	if (k->minus == 1)
	{
		spc_w = fillspc(k->width);
		zero_p = fillzero(precis);
		k->nprint += (k->hash == 1 && precis <= str_len) ?
		write(1, "0", 1) : 0;
		if (precis > 0)
			k->nprint += write(1, zero_p, precis);
		k->nprint += write(1, &str[0], str_len);
		if (k->width > 0)
			k->nprint += write(1, spc_w, k->width);
		ft_strdel(&spc_w);
		ft_strdel(&zero_p);
	}
	else
		output_octal_extend(k, str, precis, str_len);
}
