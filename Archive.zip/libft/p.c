/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   p.c                                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 17:10:29 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 17:10:30 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	ft_strdell(char **zero_w, char **zero_p, char **spc_w)
{
	ft_strdel(zero_w);
	ft_strdel(zero_p);
	ft_strdel(spc_w);
}

static void	right_align(t_struct *k, char *str, int precis, int str_len)
{
	char *zero_w;
	char *zero_p;
	char *spc_w;

	spc_w = fillspc(k->width);
	zero_w = fillzero(k->width);
	zero_p = fillzero(precis);
	if (k->zero == 1 && precis < 0)
	{
		k->nprint += write(1, "0x", 2);
		if (k->width > 0)
			k->nprint += write(1, zero_w, k->width);
		k->nprint += write(1, &str[0], str_len);
	}
	else
	{
		if (k->width > 0)
			k->nprint += write(1, spc_w, k->width);
		k->nprint += write(1, "0x", 2);
		if (precis > 0)
			k->nprint += write(1, zero_p, precis);
		k->nprint += write(1, &str[0], str_len);
	}
	ft_strdell(&zero_w, &zero_p, &spc_w);
}

static void	left_align(t_struct *k, char *str, int precis, int str_len)
{
	char *spc_w;
	char *zero_p;

	spc_w = fillspc(k->width);
	zero_p = fillzero(precis);
	k->nprint += write(1, "0x", 2);
	if (precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += write(1, &str[0], str_len);
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&spc_w);
	ft_strdel(&zero_p);
}

void		get_p(va_list ar, t_struct *k)
{
	long long int	n;
	char			*str;
	int				precis;
	int				str_len;

	n = (long long int)va_arg(ar, long long int);
	if (n == 0 && k->precis == 0)
		str = ft_strdup("");
	else
		str = ft_lltoa(n, 16, 0);
	str_len = (int)ft_strlen(str);
	k->width -= (str_len + 2);
	precis = k->precis - str_len;
	if (k->minus == 1)
		left_align(k, str, precis, str_len);
	else
		right_align(k, str, precis, str_len);
	ft_strdel(&str);
}
