/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   regulation.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/05 13:22:48 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/05 13:22:49 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	handle_flag(const char *restrict fmt, t_struct *k)
{
	while (ft_strchr("+- #0", fmt[k->i]))
	{
		if (fmt[k->i] == '+')
			k->plus = 1;
		if (fmt[k->i] == '-')
			k->minus = 1;
		if (fmt[k->i] == ' ')
			k->space = 1;
		if (fmt[k->i] == '#')
			k->hash = 1;
		if (fmt[k->i] == '0')
			k->zero = 1;
		k->i++;
	}
}

void	handle_width(const char *restrict fmt, t_struct *k, va_list ar)
{
	int j;

	j = k->i;
	while ((fmt[k->i] != '\0' && fmt[k->i] >= 48 && fmt[k->i] <= 57)
	|| fmt[k->i] == '*')
	{
		if (fmt[k->i] == '*')
			widthstar(ar, k);
		k->i++;
	}
	if (j != k->i)
		k->i--;
	if (fmt[k->i] >= 48 && fmt[k->i] <= 57)
	{
		while (fmt[k->i] >= 48 && fmt[k->i] <= 57 && k->i > j)
			k->i--;
		if (fmt[k->i + 1] >= 48 && fmt[k->i + 1] <= 57 &&
			!(fmt[k->i] >= 48 && fmt[k->i] <= 57))
			k->i++;
		k->width = ft_atoi(&fmt[k->i]);
	}
	while ((fmt[k->i] != '\0' && fmt[k->i] >= 48 && fmt[k->i] <= 57)
	|| fmt[k->i] == '*')
		k->i++;
}

void	handle_precis(const char *restrict fmt, t_struct *k, va_list ar)
{
	if (fmt[k->i] == '.')
	{
		k->i++;
		if (fmt[k->i] == '*')
			precistar(ar, k);
		else
			k->precis = ft_atoi(&fmt[k->i]);
	}
	while ((fmt[k->i] != '\0' && fmt[k->i] >= 48 && fmt[k->i] <= 57)
	|| fmt[k->i] == '*')
		k->i++;
}

void	handle_length(const char *restrict fmt, t_struct *k)
{
	if (fmt[k->i] == 'l' && fmt[(k->i) + 1] != 'l')
		k->length = 1;
	else if (fmt[k->i] == 'l' && fmt[(k->i) + 1] == 'l')
		k->length = 2;
	else if (fmt[k->i] == 'h' && fmt[(k->i) + 1] != 'h')
		k->length = 3;
	else if (fmt[k->i] == 'h' && fmt[(k->i) + 1] == 'h')
		k->length = 4;
	else if (fmt[k->i] == 'L')
		k->length = 5;
	while (ft_strchr("lhL", fmt[k->i]) && fmt[k->i])
		k->i++;
}

void	regulate(t_struct *k, const char *restrict fmt, va_list ar)
{
	handle_flag(fmt, k);
	handle_width(fmt, k, ar);
	handle_precis(fmt, k, ar);
	handle_length(fmt, k);
}
