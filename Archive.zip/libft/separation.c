/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   separation.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 17:15:32 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 17:15:33 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	separate(const char *restrict fmt, va_list ar, t_struct *k)
{
	if (fmt[k->i] == 'c')
		get_char(ar, k);
	if (fmt[k->i] == 's')
		get_str(ar, k);
	if (fmt[k->i] == 'd' || fmt[k->i] == 'i')
		get_int(ar, k, 0, 0);
	if (fmt[k->i] == '%')
		get_percent(k);
	if (fmt[k->i] == 'p')
		get_p(ar, k);
	if (fmt[k->i] == 'o')
		get_octal(ar, k);
	if (fmt[k->i] == 'u')
		get_uint(k, ar);
	if (fmt[k->i] == 'X' || fmt[k->i] == 'x')
		get_hex(ar, k, fmt[k->i]);
	if (fmt[k->i] == 'f')
		get_float(ar, k);
}
