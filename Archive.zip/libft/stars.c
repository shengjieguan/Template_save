/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stars.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 17:16:07 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 17:16:07 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	widthstar(va_list ar, t_struct *k)
{
	k->width = (int)va_arg(ar, int);
	if (k->width < 0)
	{
		k->w_neg = 1;
		k->width *= -1;
	}
}

void	precistar(va_list ar, t_struct *k)
{
	k->precis = (int)va_arg(ar, int);
}
