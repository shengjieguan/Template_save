/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   string.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 17:17:44 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 17:17:44 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	left_align(char *str, t_struct *k, int str_len)
{
	char	*spc_w;

	spc_w = fillspc(k->width);
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	if (k->precis >= 0 && str[0] != '\0')
	{
		if (k->precis >= str_len)
			k->nprint += write(1, &str[0], str_len);
		else
			k->nprint += write(1, &str[0], k->precis);
	}
	else
		k->nprint += write(1, &str[0], str_len);
	ft_strdel(&spc_w);
}

static void	right_align(char *str, t_struct *k, int str_len)
{
	char	*spc_w;

	spc_w = fillspc(k->width);
	if (k->precis >= 0 && str[0] != '\0')
	{
		if (k->precis >= str_len)
			k->nprint += write(1, &str[0], str_len);
		else
			k->nprint += write(1, &str[0], k->precis);
	}
	else
		k->nprint += write(1, &str[0], str_len);
	if (k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&spc_w);
}

void		get_str(va_list ar, t_struct *k)
{
	char	*str;
	char	*new_str;
	int		str_len;

	str = va_arg(ar, char*);
	if (str == NULL)
		new_str = (k->precis == -1) ?
		ft_strdup("(null)") : ft_strndup("(null)", k->precis);
	else if (k->precis > -1 && k->precis <= (int)ft_strlen(str))
		new_str = ft_strndup(str, k->precis);
	else
		new_str = ft_strdup(str);
	str_len = (int)ft_strlen(new_str);
	k->width -= str_len;
	if (k->minus == 1)
		right_align(new_str, k, str_len);
	else if (k->minus == 0)
		left_align(new_str, k, str_len);
	ft_strdel(&new_str);
}
