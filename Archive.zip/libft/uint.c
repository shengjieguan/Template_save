/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   uint.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/22 17:18:49 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/22 17:18:50 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int			get_width_precis_uint(t_struct *k, char *str)
{
	int precis;
	int str_len;

	str_len = (int)ft_strlen(str);
	precis = 0;
	if (str_len >= k->precis)
		k->width -= str_len;
	else
	{
		k->width -= k->precis;
		precis = k->precis - str_len;
	}
	return (precis);
}

static void	zero_out_extend(t_struct *k)
{
	char *spc_w;
	char *zero_w;

	k->width--;
	zero_w = fillzero(k->width);
	spc_w = fillspc(k->width);
	if (k->minus == 0 && k->width > 0)
		k->nprint += (k->zero == 0) ?
	write(1, spc_w, k->width) : write(1, zero_w, k->width);
	k->nprint += write(1, "0", 1);
	if (k->minus == 1 && k->width > 0)
		k->nprint += write(1, spc_w, k->width);
	ft_strdel(&spc_w);
	ft_strdel(&zero_w);
}

static void	zero_out(t_struct *k)
{
	char *spc_w;
	char *zero_p;

	if (k->precis >= 0)
	{
		k->width -= k->precis;
		zero_p = fillzero(k->precis);
		spc_w = fillspc(k->width);
		if (k->minus == 0 && k->width > 0)
			k->nprint += write(1, spc_w, k->width);
		if (k->precis > 0)
			k->nprint += write(1, zero_p, k->precis);
		if (k->width > 0 && k->minus == 1)
			k->nprint += write(1, spc_w, k->width);
		ft_strdel(&zero_p);
		ft_strdel(&spc_w);
	}
	else
		zero_out_extend(k);
}

void		get_uint(t_struct *k, va_list ar)
{
	unsigned long	n;
	char			*str;

	n = 0;
	if (k->length == 0)
		n = va_arg(ar, unsigned int);
	else if (k->length == H)
		n = (unsigned int)va_arg(ar, unsigned int);
	else if (k->length == LL)
		n = (unsigned long long)va_arg(ar, unsigned long long);
	else if (k->length == L)
		n = (unsigned long)va_arg(ar, unsigned long);
	else if (k->length == HH)
		n = (unsigned char)va_arg(ar, unsigned int);
	str = ft_itoa_u(n);
	if (n != 0)
		output_uint(k, str, 0);
	else
		zero_out(k);
	ft_strdel(&str);
}
