/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   uint_two.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/26 10:21:27 by xzhan             #+#    #+#             */
/*   Updated: 2019/11/26 10:21:28 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	output_uint_extend(t_struct *k, char *str, int precis, int str_len)
{
	char	*spc_w;
	char	*zero_p;
	char	*zero_w;

	spc_w = fillspc(k->width);
	zero_w = fillzero(k->width);
	zero_p = fillzero(precis);
	if (k->width > 0)
		k->nprint += (k->zero == 1 && k->precis < 0) ?
		write(1, zero_w, k->width) : write(1, spc_w, k->width);
	if (precis > 0)
		k->nprint += write(1, zero_p, precis);
	k->nprint += write(1, &str[0], str_len);
	ft_strdel(&spc_w);
	ft_strdel(&zero_w);
	ft_strdel(&zero_p);
}

void		output_uint(t_struct *k, char *str, int precis)
{
	char	*zero_p;
	int		str_len;
	char	*spc_w;

	str_len = (int)ft_strlen(str);
	precis = get_width_precis_uint(k, str);
	if (k->minus == 1)
	{
		zero_p = fillzero(precis);
		spc_w = fillspc(k->width);
		if (precis > 0)
			k->nprint += write(1, zero_p, precis);
		k->nprint += write(1, &str[0], str_len);
		if (k->width > 0)
			k->nprint += write(1, spc_w, k->width);
		ft_strdel(&spc_w);
		ft_strdel(&zero_p);
	}
	else
		output_uint_extend(k, str, precis, str_len);
}
