/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_fsize.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:37:47 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:37:50 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

char			*get_fsize(struct stat f_stat)
{
	char	*f_size;

	f_size = ft_itoa_l(f_stat.st_size);
	return (f_size);
}

long long int	get_total(t_file **file)
{
	long long int	total;
	long long int	tmp;
	t_file			*temp;

	total = 0;
	temp = *file;
	while (temp != NULL)
	{
		tmp = ft_atolli(temp->f_size);
		if (tmp > 0 && tmp < 512)
			total++;
		else if (tmp > 512)
		{
			total += (tmp / 512);
			if (tmp % 512 > 0)
				total++;
		}
		temp = temp->next;
	}
	return (total);
}
