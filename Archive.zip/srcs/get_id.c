/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_id.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:38:06 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:38:08 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

char	*get_uid(struct stat f_stat)
{
	struct passwd	*pwd;
	char			*uid;

	pwd = getpwuid(f_stat.st_uid);
	uid = ft_strdup(pwd->pw_name);
	return (uid);
}

char	*get_gid(struct stat f_stat)
{
	struct group	*g;
	char			*gid;

	g = getgrgid(f_stat.st_gid);
	gid = ft_strdup(g->gr_name);
	return (gid);
}
