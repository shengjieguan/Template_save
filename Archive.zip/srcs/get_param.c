/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_param.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:40:18 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:40:19 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

void	get_file_two(t_flag *f, char path[1024], char **gv)
{
	t_file		*d_file;
	t_file		*file;
	t_file		*non_valid;
	struct stat	f_stat;
	int			j;

	j = f->i;
	d_file = NULL;
	file = NULL;
	non_valid = NULL;
	while (gv[f->i] != NULL)
	{
		if (lstat(gv[f->i], &f_stat) == 0)
			(file_type(f_stat) == 'd') ?
			ls_push(&d_file, gv[f->i], path) : ls_push(&file, gv[f->i], path);
		else
			ls_push(&non_valid, gv[f->i], path);
		f->i++;
	}
	ls_print_world(&d_file, &non_valid, &file, f);
}

void	get_file_one(t_flag *f, char path[1024])
{
	struct dirent	*dir;
	DIR				*d;
	t_file			*file;

	file = NULL;
	if ((d = opendir(path)))
	{
		while ((dir = readdir(d)) != NULL)
			if (f->a == 0)
			{
				if (dir->d_name[0] != '.')
					ls_push(&file, dir->d_name, path);
			}
			else
				ls_push(&file, dir->d_name, path);
		ls_print(&file, f, path, 0);
		closedir(d);
	}
}

void	get_file(char **gv, t_flag *f)
{
	char path[1024];

	ft_strcpy(path, ".");
	if (f->i == -1 || gv[1] == NULL)
		get_file_one(f, path);
	else
		get_file_two(f, path, gv);
}

int		get_file_a(t_file **d_file, t_flag *f, t_file **file)
{
	t_file			*temp;
	struct dirent	*dir;
	DIR				*d;

	*file = NULL;
	temp = *d_file;
	if ((d = opendir(temp->f_name)))
	{
		while ((dir = readdir(d)) != NULL)
			if (f->a == 0)
			{
				if (dir->d_name[0] != '.')
					ls_push(file, dir->d_name, temp->f_name);
			}
			else
				ls_push(file, dir->d_name, temp->f_name);
		closedir(d);
		return (0);
	}
	else
		return (1);
}

int		get_file_b(t_flag *f, char path[1024], t_file **file)
{
	struct dirent	*dir;
	DIR				*d;

	*file = NULL;
	if ((d = opendir(path)))
	{
		while ((dir = readdir(d)) != NULL)
			if (f->a == 0)
			{
				if (dir->d_name[0] != '.')
					ls_push(file, dir->d_name, path);
			}
			else
				ls_push(file, dir->d_name, path);
		closedir(d);
		return (0);
	}
	return (1);
}
