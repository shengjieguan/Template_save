/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_perm.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 14:04:48 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/04 14:04:49 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

char	file_type(struct stat f_stat)
{
	if (S_ISDIR(f_stat.st_mode))
		return ('d');
	else if (S_ISLNK(f_stat.st_mode))
		return ('l');
	else if (S_ISSOCK(f_stat.st_mode))
		return ('s');
	else if (S_ISCHR(f_stat.st_mode))
		return ('c');
	else if (S_ISBLK(f_stat.st_mode))
		return ('b');
	else if (S_ISFIFO(f_stat.st_mode))
		return ('p');
	else
		return ('-');
}

char	*get_perms(struct stat f_stat)
{
	mode_t	perm;
	char	*modeval;

	if (!(modeval = malloc(sizeof(char) * 10 + 1)))
		return (NULL);
	perm = f_stat.st_mode;
	modeval[0] = file_type(f_stat);
	modeval[1] = (perm & S_IRUSR) ? 'r' : '-';
	modeval[2] = (perm & S_IWUSR) ? 'w' : '-';
	modeval[3] = (perm & S_IXUSR) ? 'x' : '-';
	modeval[4] = (perm & S_IRGRP) ? 'r' : '-';
	modeval[5] = (perm & S_IWGRP) ? 'w' : '-';
	modeval[6] = (perm & S_IXGRP) ? 'x' : '-';
	modeval[7] = (perm & S_IROTH) ? 'r' : '-';
	modeval[8] = (perm & S_IWOTH) ? 'w' : '-';
	modeval[9] = (perm & S_IXOTH) ? 'x' : '-';
	modeval[10] = '\0';
	return (modeval);
}

int		get_attr(char path[1024])
{
	ssize_t xattr;

	xattr = 0;
	xattr = listxattr(path, NULL, 0, XATTR_NOFOLLOW);
	if (xattr > 0)
		return (1);
	return (0);
}
