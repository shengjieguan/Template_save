/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_time.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:49:42 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:49:43 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

char	*get_mtime(struct stat f_stat)
{
	char	*tmp;
	char	*f_mtime;
	int		i;
	int		j;
	int		z;

	z = 0;
	j = 4;
	tmp = ft_strdup(ctime(&f_stat.st_mtime));
	i = ft_strlen(tmp) - 1;
	while (tmp[i] != ':')
		i--;
	if (!(f_mtime = (char*)malloc(sizeof(char) * (12 + 1))))
		return (NULL);
	while (j < i)
	{
		f_mtime[z] = tmp[j];
		z++;
		j++;
	}
	f_mtime[z] = '\0';
	ft_strdel(&tmp);
	return (f_mtime);
}
