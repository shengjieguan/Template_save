/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ls_flag.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:51:37 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:51:38 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static int	syntax_check_extend(char *str, t_flag *f)
{
	int	i;

	i = 1;
	while (str[i] != '\0')
	{
		if (!ft_strchr("ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1", str[i]))
		{
			f->illegal = str[i];
			return (2);
		}
		i++;
	}
	return (0);
}

static int	syntax_check(char *str, t_flag *f)
{
	if (str[1] == '-' && str[2] == '\0')
		return (1);
	else if (str[1] == '-' && str[2] == '-')
	{
		f->illegal = '-';
		return (2);
	}
	else if (str[1] != '-' && ft_strchr(&str[2], '-'))
	{
		if (ft_strchr("ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1", str[1]))
			f->illegal = '-';
		else
			f->illegal = str[1];
		return (2);
	}
	else
		return (syntax_check_extend(str, f));
}

int			ls_flag(int gc, char **gv, t_flag *f)
{
	int j;
	int	check;

	j = 0;
	while (f->i < gc && gv[f->i][0] == '-' && gv[f->i][1] != '\0')
	{
		check = syntax_check(gv[f->i], f);
		if (check == 2)
			return (0);
		while (gv[f->i][++j] != '\0')
		{
			f->l = (gv[f->i][j] == 'l') ? 1 : f->l;
			f->bigr = (gv[f->i][j] == 'R') ? 1 : f->bigr;
			f->a = (gv[f->i][j] == 'a') ? 1 : f->a;
			f->r = (gv[f->i][j] == 'r') ? 1 : f->r;
			f->t = (gv[f->i][j] == 't') ? 1 : f->t;
		}
		f->i++;
		j = 0;
	}
	if (f->i == gc)
		f->i = -1;
	return (1);
}
