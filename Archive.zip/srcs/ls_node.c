/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ls_node.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:53:05 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:53:09 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static void	get_info(t_file **new_node, struct stat f_stat, char tmp[1024])
{
	(*new_node)->perms = get_perms(f_stat);
	(*new_node)->ex_attri = (get_attr(tmp) == 1) ? '@' : '\0';
	(*new_node)->nlink = f_stat.st_nlink;
	(*new_node)->uid = get_uid(f_stat);
	(*new_node)->gid = get_gid(f_stat);
	(*new_node)->f_size = get_fsize(f_stat);
	(*new_node)->mtime = get_mtime(f_stat);
	get_link((*new_node)->link, tmp);
	get_mtime_i(f_stat, new_node);
}

static void	del_info(t_file **node)
{
	ft_strdel(&((*node)->perms));
	ft_strdel(&((*node)->uid));
	ft_strdel(&((*node)->gid));
	ft_strdel(&((*node)->mtime));
	ft_strdel(&((*node)->f_size));
}

static void	build_path(char *f_name, char path[1024], char tmp[1024])
{
	if (f_name[0] != '~')
	{
		ft_strcpy(tmp, path);
		ft_strcat(tmp, "/");
		ft_strcat(tmp, f_name);
	}
	else if (ft_strcmp(f_name, "~") == 0)
		ft_strcpy(tmp, "~");
	else if (f_name[0] == '~' && ft_strcmp(path, ".") == 0)
		ft_strcpy(tmp, f_name);
}

void		ls_push(t_file **head, char *f_name, char path[1024])
{
	t_file		*new_node;
	struct stat	f_stat;
	char		tmp[1024];

	build_path(f_name, path, tmp);
	if (!(new_node = (t_file*)malloc(sizeof(t_file))))
		return ;
	if (lstat(tmp, &f_stat) == 0)
	{
		get_info(&new_node, f_stat, tmp);
		new_node->is_file = 0;
	}
	else
		new_node->is_file = -1;
	new_node->f_name = ft_strdup(f_name);
	new_node->next = (*head);
	(*head) = new_node;
}

void		ls_destroyer(t_file **head)
{
	t_file	*current;
	t_file	*next;

	current = *head;
	while (current != NULL)
	{
		if (current->is_file != -1)
			del_info(&current);
		ft_strdel(&current->f_name);
		free(current);
		next = current->next;
		current = next;
	}
	*head = NULL;
}
