/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ls_sort_alpha.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:55:07 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:55:08 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static void	ls_sorted_insert(t_file **head, t_file *new_node)
{
	t_file	*current;

	if (*head == NULL || ft_strcmp((*head)->f_name, new_node->f_name) > 0)
	{
		new_node->next = *head;
		*head = new_node;
	}
	else
	{
		current = *head;
		while (current->next != NULL &&
		ft_strcmp(current->next->f_name, new_node->f_name) < 0)
			current = current->next;
		new_node->next = current->next;
		current->next = new_node;
	}
}

void		ls_sort_alpha(t_file **head)
{
	t_file *sorted;
	t_file *current;
	t_file *next;

	sorted = NULL;
	current = *head;
	while (current != NULL)
	{
		next = current->next;
		ls_sorted_insert(&sorted, current);
		current = next;
	}
	*head = sorted;
}
