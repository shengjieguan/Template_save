/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ls_sort_mtime.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 18:56:32 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 18:56:33 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static int	ls_compare(t_file *current, t_file *new_node)
{
	long long int current_total;
	long long int new_total;

	new_total = (long long int)new_node->myear * 1000000000000 +
				(long long int)new_node->mmonth * 1000000000 +
				(long long int)new_node->mday * 1000000 +
				(long long int)new_node->msecond;
	current_total = (long long int)current->myear * 1000000000000 +
				(long long int)current->mmonth * 1000000000 +
				(long long int)current->mday * 1000000 +
				(long long int)current->msecond;
	if (current_total > new_total)
		return (1);
	else if (current_total < new_total)
		return (0);
	else if (current_total == new_total)
	{
		if (ft_strcmp(current->f_name, new_node->f_name) < 0)
			return (1);
		else
			return (0);
	}
	return (0);
}

static void	ls_sorted_insert(t_file **head, t_file *new_node)
{
	t_file	*current;

	if (*head == NULL || ls_compare(*head, new_node) == 0)
	{
		new_node->next = *head;
		*head = new_node;
	}
	else
	{
		current = *head;
		while (current->next != NULL &&
		ls_compare(current->next, new_node) == 1)
			current = current->next;
		new_node->next = current->next;
		current->next = new_node;
	}
}

void		ls_sort_mtime(t_file **head)
{
	t_file *sorted;
	t_file *current;
	t_file *next;

	sorted = NULL;
	current = *head;
	while (current != NULL)
	{
		next = current->next;
		ls_sorted_insert(&sorted, current);
		current = next;
	}
	*head = sorted;
}
