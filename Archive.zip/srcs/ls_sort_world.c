/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ls_sort_world.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:00:19 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:00:20 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

void	ls_sort_world(t_file **head, t_flag *f)
{
	ls_sort_alpha(head);
	if (f->t == 1)
		ls_sort_mtime(head);
	if (f->r == 1)
		ls_sort_rev(head);
}
