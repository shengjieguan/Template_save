/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:01:03 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:01:04 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static void	flag_init(t_flag *f)
{
	f->l = 0;
	f->bigr = 0;
	f->a = 0;
	f->r = 0;
	f->t = 0;
	f->i = 1;
	f->illegal = '\0';
}

int			main(int gc, char **gv)
{
	t_flag	*f;
	int		check;

	if (!(f = (t_flag*)malloc(sizeof(t_flag))))
		return (-1);
	flag_init(f);
	check = ls_flag(gc, gv, f);
	if (check == 0)
	{
		ft_printf("ls: illegal option -- %c\n", f->illegal);
		ft_printf("usage: ls [-ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1]");
		ft_printf(" [file ...]\n");
		free(f);
		return (-2);
	}
	get_file(gv, f);
	free(f);
	return (0);
}
