/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:11:02 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:11:03 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static int	is_local(char path[1024])
{
	int	len;
	int	dot;
	int	pos;

	len = ft_strlen(path) - 1;
	dot = 0;
	pos = 0;
	while (path[len] != '/')
	{
		if (path[len] != '.')
			break ;
		if (path[len] == '.')
			dot++;
		pos++;
		len--;
	}
	if (pos < 3 && dot > 0 && dot < 3)
		return (1);
	return (0);
}

static int	non_dot(char path[1024])
{
	if (ft_strcmp(path, "./.") == 0 || ft_strcmp(path, "./..") == 0 ||
		is_local(path))
		return (1);
	return (0);
}

static void	ls_print_extend(t_file **file, t_flag *f, char path[1024])
{
	t_file	*tmp;
	char	temp[1024];

	tmp = *file;
	ft_strcpy(temp, path);
	while (tmp != NULL)
	{
		if (tmp->is_file != -1 && tmp->perms[0] == 'd')
		{
			ft_strcat(path, "/");
			ft_strcat(path, tmp->f_name);
			if (non_dot(path))
			{
				ft_strcpy(path, temp);
				tmp = tmp->next;
				continue;
			}
			ft_printf("\n%s:\n", path);
			get_file_one(f, path);
		}
		ft_strcpy(path, temp);
		tmp = tmp->next;
	}
	ls_destroyer(file);
}

void		ls_print(t_file **file, t_flag *f, char path[1024], int z)
{
	t_file	*tmp;
	int		empty;

	empty = 0;
	ls_sort_world(file, f);
	tmp = *file;
	(f->l == 1) ? print_l_flag_on(&tmp) : print_l_flag_off(&tmp);
	if (z == 1 || (f->bigr == 1 && *file))
		ft_printf("\n");
	empty = (tmp == NULL) ? 1 : 0;
	if (f->bigr == 1)
	{
		(empty) ? 0 : ft_putchar('\n');
		ls_print_extend(file, f, path);
	}
	else
	{
		if (z == 0 && *file)
			ft_putchar('\n');
		ls_destroyer(file);
	}
}
