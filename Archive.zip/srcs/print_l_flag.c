/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_l_flag.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:06:10 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:06:11 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

int	print_l_flag_on(t_file **tmp)
{
	char	*total;

	total = ft_lltoa_u(get_total(tmp), 10, 0);
	if (tmp && *tmp)
		ft_printf("total %s\n", total);
	ft_strdel(&total);
	while (*tmp != NULL)
	{
		ft_printf("%s%c %2d %s %10s %6s %s %s",
		(*tmp)->perms, (*tmp)->ex_attri, (*tmp)->nlink, (*tmp)->uid,
		(*tmp)->gid, (*tmp)->f_size, (*tmp)->mtime, (*tmp)->f_name);
		if ((*tmp)->perms[0] == 'l')
			ft_printf(" -> %s", (*tmp)->link);
		if ((*tmp)->next != NULL)
			ft_putchar('\n');
		*tmp = (*tmp)->next;
	}
	return (0);
}

int	print_l_flag_off(t_file **tmp)
{
	while (*tmp != NULL)
	{
		ft_putstr((*tmp)->f_name);
		if ((*tmp)->next != NULL)
			ft_putstr("  ");
		(*tmp) = (*tmp)->next;
	}
	return (0);
}
