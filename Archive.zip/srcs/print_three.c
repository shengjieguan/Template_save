/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_three.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:07:47 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:07:48 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static char	*p_denied_fname(char *str)
{
	int		i;
	char	*f_name;

	i = ft_strlen(str) - 1;
	if (str[i] == '/')
	{
		f_name = ft_strdup("\0");
		return (f_name);
	}
	while (str[i] != '/')
		i--;
	i++;
	f_name = ft_strdup(&str[i]);
	return (f_name);
}

static void	ls_print_dir_extend_norm(char path[1024])
{
	char *p_denied_f;

	p_denied_f = p_denied_fname(path);
	ft_printf("ls: %s: Permission denied\n", p_denied_f);
	ft_strdel(&p_denied_f);
}

static void	ls_print_dir_extend(t_file **d_file, t_flag *f, int a)
{
	t_file	*tmp;
	t_file	*file;
	char	path[1024];
	int		p_denied;

	tmp = *d_file;
	(a == 0) ? 0 : ft_printf("\n");
	while (tmp != NULL)
	{
		file = NULL;
		ft_strcpy(path, tmp->f_name);
		p_denied = get_file_b(f, path, &file);
		ft_printf("%s:\n", tmp->f_name);
		if (p_denied == 0 && file != NULL)
			ls_print(&file, f, path, 1);
		else if (p_denied == 1)
			ls_print_dir_extend_norm(path);
		(tmp->next != NULL) ? ft_printf("\n") : 0;
		tmp = tmp->next;
	}
	ls_destroyer(d_file);
}

void		ls_print_dir(t_file **d_file, t_flag *f, int a)
{
	t_file	*file;
	char	path[1024];
	int		p_denied;
	char	*p_denied_f;

	if (*d_file == NULL)
		return ;
	ft_strcpy(path, (*d_file)->f_name);
	if (a == 0 && (*d_file)->next == NULL)
	{
		p_denied = get_file_a(d_file, f, &file);
		if (!p_denied)
			ls_print(&file, f, path, 0);
		else
		{
			p_denied_f = p_denied_fname((*d_file)->f_name);
			ft_printf("ls: %s: Permission denied\n", p_denied_f);
			ft_strdel(&p_denied_f);
		}
		ls_destroyer(d_file);
	}
	else
		ls_print_dir_extend(d_file, f, a);
}

void		ls_print_world(t_file **d_file, t_file **non_valid,
t_file **file, t_flag *f)
{
	int a;

	a = 0;
	ls_sort_alpha(non_valid);
	if (f->r == 1)
		ls_sort_rev(non_valid);
	ls_sort_world(file, f);
	ls_sort_world(d_file, f);
	if (ls_print_non_valid(non_valid))
		a = 1;
	if (ls_print_regular_file(file, f))
		a = 1;
	ls_destroyer(non_valid);
	ls_destroyer(file);
	ls_print_dir(d_file, f, a);
}
