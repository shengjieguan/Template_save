/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_two.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:10:06 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:10:07 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

int	ls_print_non_valid(t_file **non_valid)
{
	t_file	*temp;

	temp = *non_valid;
	if (temp == NULL)
		return (0);
	while (temp != NULL)
	{
		ft_printf("ls: %s: No such file or directory\n", temp->f_name);
		temp = temp->next;
	}
	return (1);
}

int	ls_print_regular_file(t_file **file, t_flag *f)
{
	t_file	*temp;

	temp = *file;
	if (temp == NULL)
		return (0);
	while (temp != NULL)
	{
		if (f->l == 0)
			ft_printf("%s  ", temp->f_name);
		else
		{
			ft_printf("%s%c %2d %s %10s %2s %s %s",
			(temp)->perms, (temp)->ex_attri, (temp)->nlink, (temp)->uid,
			(temp)->gid, (temp)->f_size, (temp)->mtime, (temp)->f_name);
			if ((temp)->perms[0] == 'l')
				ft_printf(" -> %s", (temp)->link);
		}
		temp = temp->next;
	}
	ft_putchar('\n');
	return (1);
}
