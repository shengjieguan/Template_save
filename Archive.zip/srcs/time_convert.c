/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   time_convert.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:14:53 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:14:55 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static void	get_msecond(char *str, t_file **node)
{
	int	i;

	i = ft_strlen(str) - 2;
	(*node)->msecond = 0;
	while (ft_isdigit(str[i]) || ft_isspac(str[i]))
		i--;
	i++;
	(*node)->msecond += ft_atolli(&str[i]);
	i -= 2;
	while (ft_isdigit(str[i]))
		i--;
	i++;
	(*node)->msecond += 60 * ft_atolli(&str[i]);
	i -= 2;
	while (ft_isdigit(str[i]))
		i--;
	i++;
	(*node)->msecond += 3600 * ft_atolli(&str[i]);
}

static void	get_myear(char *str, t_file **node)
{
	int	i;

	i = ft_strlen(str) - 2;
	while (ft_isdigit(str[i]))
		i--;
	(*node)->myear = ft_atolli(&str[i]);
}

void		get_mtime_i(struct stat f_stat, t_file **node)
{
	char	*str;
	int		i;

	str = ft_strdup(ctime(&f_stat.st_mtime));
	i = 0;
	while (!ft_isdigit(str[i]))
		i++;
	(*node)->mday = ft_atoi(&str[i]);
	get_myear(str, node);
	get_mmonth_convert(str, node);
	get_msecond(str, node);
	ft_strdel(&str);
}
