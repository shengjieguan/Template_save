/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   time_convert_two.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzhan <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/16 19:13:14 by xzhan             #+#    #+#             */
/*   Updated: 2019/12/16 19:13:15 by xzhan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_ls.h"

static char	*get_mmonth_c_helper(char *str)
{
	char	*month;
	int		i;
	int		j;

	i = 4;
	j = 0;
	if (!(month = (char*)malloc(sizeof(char) * 4)))
		return (NULL);
	while (i < 7)
	{
		month[j] = str[i];
		j++;
		i++;
	}
	month[j] = '\0';
	return (month);
}

static void	get_mmonth_cmp(t_file **node, char **month)
{
	if (ft_strcmp(*month, "Jan") == 0)
		(*node)->mmonth = 1;
	else if (ft_strcmp(*month, "Feb") == 0)
		(*node)->mmonth = 2;
	else if (ft_strcmp(*month, "Mar") == 0)
		(*node)->mmonth = 3;
	else if (ft_strcmp(*month, "Apr") == 0)
		(*node)->mmonth = 4;
	else if (ft_strcmp(*month, "May") == 0)
		(*node)->mmonth = 5;
	else if (ft_strcmp(*month, "Jun") == 0)
		(*node)->mmonth = 6;
	else if (ft_strcmp(*month, "Jul") == 0)
		(*node)->mmonth = 7;
	else if (ft_strcmp(*month, "Aug") == 0)
		(*node)->mmonth = 8;
	else if (ft_strcmp(*month, "Sep") == 0)
		(*node)->mmonth = 9;
	else if (ft_strcmp(*month, "Oct") == 0)
		(*node)->mmonth = 10;
	else if (ft_strcmp(*month, "Nov") == 0)
		(*node)->mmonth = 11;
	else
		(*node)->mmonth = 12;
}

void		get_mmonth_convert(char *str, t_file **node)
{
	char	*month;

	month = get_mmonth_c_helper(str);
	get_mmonth_cmp(node, &month);
	ft_strdel(&month);
}
