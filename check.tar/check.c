#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "libft/libft.h"
#include "libft/get_next_line.h"
typedef struct s_sort
{
	int	a[255];
	int	x;
	int	b[255];
	int	y;
}				t_sort;
int		sa_sb(int *x, int *y)
{
	int	temp;

	temp = *x;
	*x = *y;
	*y = temp;
	return (1);
}
int		ra(t_sort	*array)
{
	int	first;
	int i;

	i = 0;
	first = array->a[0];
	while(i < (array->x - 1))
	{
		array->a[i] = array->a[i + 1];
		i++;
	}
	array->a[i] = first;
	
	return (1);
}
int		rb(t_sort	*array)
{
	int	first;
	int i;

	i = 0;
	first = array->b[0];
	while(i < (array->y - 1))
	{
		array->b[i] = array->b[i + 1];
		i++;
	}
	array->b[i] = first;
	return (1);
}
int		pb(t_sort *array)
{
	int x;
	int y;
	
	if(array->x == 0)
		return (0);
	x = array->y;
	y = 0;
	--array->x;
	array->b[x] = array->b[x - 1];
	while(--x > 0)
	{
		array->b[x] = array->b[x -1];
	}
	array->b[0] = array->a[0];
	while(y < array->x)
	{
		array->a[y] = array->a[y + 1];
		y++;
	}
	array->y++;
	// printf("a=%d %d %d %d\n", array->a[0], array->a[1], array->a[2], array->x);
	// printf("b=%d %d %d %d\n", array->b[0], array->b[1], array->b[2], array->y);
	return (0);

}
int		pa(t_sort *array)
{
	int x;
	int y;
	
	//printf("y=%d", array->y);
	if(array->y == 0)
		return (0);
	x = array->x;
	y = 0;
	--array->y;
	array->a[x] = array->a[x - 1];
	while(--x > 0)
	{
		array->a[x] = array->a[x -1];
	}
	array->a[0] = array->b[0];
	while(y < array->y)
	{
		array->b[y] = array->b[y + 1];
		y++;
	}
	array->x++;
	return (1);

}

int		rra(t_sort *array)
{
	int	last;
	int i;

	i = array->x;
	last = array->a[array->x - 1];
	while(--i > 0)
	{
		array->a[i] = array->a[i -1];
	}
	array->a[0] = last;
	// ft_putnbr(array->a[0]);
	// ft_putnbr(array->a[1]);
	// ft_putnbr(array->a[2]);
	return (1);

}
int		rrb(t_sort *array)
{
	int	last;
	int i;

	i = array->y;
	last = array->b[array->y - 1];
	while(--i > 0)
	{
		array->b[i] = array->b[i -1];
	}
	array->b[0] = last;
	return (1);

}
void	check_input(t_sort *array)
{
	char *line;
	array->y = 0;
	while(get_next_line(0, &line))
	{
		
		if(!ft_strcmp(line, ft_strdup("pa")))
			pa(array);
		else if(!ft_strcmp(line, ft_strdup("pb")))
			pb(array);
		else if(!ft_strcmp(line, ft_strdup("sa")))
			sa_sb(&array->a[0], &array->a[1]);
		else if(!ft_strcmp(line, ft_strdup("sb")))
			sa_sb(&array->b[0], &array->b[1]);
		else if(!ft_strcmp(line, ft_strdup("ra")))
			ra(array);
		else if(!ft_strcmp(line, ft_strdup("rb")))
			rb(array);
		else if(!ft_strcmp(line, ft_strdup("rra")))
			rra(array);
		else if(!ft_strcmp(line, ft_strdup("rrb")))
			rrb(array);
		else if(!ft_strcmp(line, ft_strdup("ss")))
		{
			sa_sb(&array->a[0], &array->a[1]);
			sa_sb(&array->b[0], &array->b[1]);
		}
		else if(!ft_strcmp(line, ft_strdup("rr")))
		{
			ra(array);
			rb(array);
		}
		else if(!ft_strcmp(line, ft_strdup("rrr")))
		{
			rra(array);
			rrb(array);
		}
		else
		{
			break;
		}
		 
	}
	
}
int	check_av(int ar, char **av, t_sort *array)
{
	char **s;
	int i;
	int j;

	j = -1;
	s = (ar == 2 ? ft_strsplit(av[1], ' ') : ++av);
	while(s[++j])
	{	
		i = -1;
		while(s[j][++i])
			if(!ft_isdigit(s[j][i]))
				if((ar == 2 && s[j][i] != 32) || ar > 2)
					return (0);
		if(atoi(s[j]) > 2147483647 || atoi(s[j]) < -2147483648)
			return (0);
		array->a[j] = atoi(s[j]);
		i = j;
		while(--i >= 0)
			if(array->a[j] == array->a[i])
				return (0);
	}
	array->x = j;
	if((ar == 2 && --j < 1) || ar < 2)
		return (0);
	return (1);
}
int		check_result(t_sort *array)
{
	int i;

	i = 0;
	while(i < (array->x - 1))
	{
		if(array->a[i] > array->a[i + 1])
			return (0);
		i++;
	}
	return (1);
}
int	main(int ar, char **av)
{
	t_sort	array;
	
	if(!check_av(ar, av, &array))
	{
		puts("Error");
		return (0);
	}
	
	check_input(&array);
	if(check_result(&array))
		puts("ok");
	if(!check_result(&array))
		puts("ko");
	 return (0);
}
