#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "libft/libft.h"

int	check_av(int num[255], int ar, char **av)
{
	char **s;
	int i;
	int j;

	j = -1;
	s = (ar == 2 ? ft_strsplit(av[1], ' ') : ++av);
	while(s[++j])
	{	
		i = -1;
		while(s[j][++i])
			if(!ft_isdigit(s[j][i]))
				if((ar == 2 && s[j][i] != 32) || ar > 2)
					return (0);
		if(atoi(s[j]) > 2147483647 || atoi(s[j]) < -2147483648)
			return (0);
		num[j] = atoi(s[j]);
		i = j;
		while(--i >= 0)
			if(num[j] == num[i])
				return (0);
	} 
	if((ar == 2 && --j < 1) || ar < 2)
		return (0);
	return (1);
}

int	main(int ar, char **av)
{
	
	 int	num[255];
	// int i;
	
	if(!check_av(num, ar, av))
	{
		puts("Error");
		return (0);
	}

	 return (0);
}
