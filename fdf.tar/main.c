#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include "get_next_line.h"
#include "libft/libft.h"

typedef struct    s_list_map
{
    struct s_list_map    *next;
    int            data;
}                t_list_map;

typedef	struct	s_map
{
	int			x;
	int			y;
	t_list_map  **map;
}	
			t_map;
t_list_map    *ft_create_elem(int data)
{
    t_list_map    *temp;

    temp = malloc(sizeof(t_list_map));
    temp->data = data;
    temp->next = NULL;
    return (temp);
}
void    ft_list_push_back(t_list_map **begin_list, int data)
{
    t_list_map    *current;

    current = *begin_list;
    if (!current)
    {
        *begin_list = ft_create_elem(data);
        return ;
    }
    while (current->next != 0)
        current = current->next;
    current->next = ft_create_elem(data);
}

int		ft_countstr(char **s)
{
	int i;
	int j;

	j = 0;
	i = 0;
	while(s[j][i])
	{
		i = 0;
		while(s[j][i])
		{
			if(s[j][i] == '-')
				i++;
			while(ft_isdigit(s[j][i]))
				i++;
			if(s[j][i])
				return (0);
		}
		j++;
	}
	return (j);
}

int		read_file(t_map map, int fd)
{
	char *line;
	char **s;
	int i = 0;
	t_list_map	*begin_list;

	begin_list = malloc(sizeof(t_list_map));
	map.x = 0;
	map.y = 0;
	
	while(get_next_line(fd, &line) == 1)
	{
		i = 0;
		if(!*(s = ft_strsplit(line, ' ')))
			return (0);
		if(map.x > 0)
		{
			if (map.x != ft_countstr(s))
				return (0);
		}
		if(map.x == 0)
		{
			if(!(map.x = ft_countstr(s)))
				return (0);
			begin_list->data = atoi(s[i++]);
  			begin_list->next = NULL;
		}
		while(s[i])
		{
			//printf("%d", begin_listdata);
			ft_list_push_back(&begin_list, atoi(s[i]));
			i++;
		}
		map.y++;
	}
	map.map = &begin_list;
	return (1);
}

int		main(int	ar, char **av)
{
	t_map map;
	int fd;

	
	if (ar < 2)
	{
		puts("not enough arguments");
		return (1);
	}
	fd = open(av[1], O_RDONLY);
	if(fd < 0 || !read_file(map, fd))
	{
		puts("Invaild file");
		return (1);
	}
	printf("%d", &map.map.data);
	return (0);
}

