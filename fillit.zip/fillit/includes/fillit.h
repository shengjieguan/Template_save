/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fillit.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skoh <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/21 15:02:48 by skoh              #+#    #+#             */
/*   Updated: 2019/10/23 14:42:16 by skoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FILLIT_H
# define FILLIT_H

# include <unistd.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <stdlib.h>
# include <limits.h>

typedef struct	s_tetri
{
	char	letter;
	struct	s_tetri *next;
}				t_tetri;

/* line */
# define MATCH_1 (arr == "####")
# define MATCH_2 (arr == "#...#...#...#")

/* square */
# define MATCH_3 (arr == "##..##")

/* Z */
# define MATCH_4 (arr == "#...##...#")
# define MATCH_5 (arr == "##.##")
# define MATCH_6 (arr == "#..##..#")
# define MATCH_7 (arr == "##...##")

/* _|_ */
# define MATCH_8 (arr == "#..###")
# define MATCH_9 (arr == "###..#")
# define MATCH_10 (arr == "#...##..#")
# define MATCH_11 (arr == "#..##...#")

/* L */
# define MATCH_12 (arr == "##..#...#")
# define MATCH_13 (arr == "###...#")
# define MATCH_14 (arr == "#...#..##")
# define MATCH_15 (arr == "#...###")
# define MATCH_16 (arr == "##...#...#")
# define MATCH_17 (arr == "###.#")
# define MATCH_18 (arr == "#...#...##")
# define MATCH_19 (arr == "#.###")

int		parse_file(int fd);
int		file_is_valid(int fd);
int		tetri_are_valid(int ret, char *buf);
int		char_check(char *buf);
int		valid_shape(char *buf);
char	*trim_dots(char const *s);
void	ft_putchar(char c);
void	ft_putstr(const char *s);
char	*ft_strnew(size_t size);
size_t	ft_strlen(const char *s);

#endif
