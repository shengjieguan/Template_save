/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_and_validate.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skoh <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/23 11:49:20 by skoh              #+#    #+#             */
/*   Updated: 2019/10/23 14:42:14 by skoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/fillit.h"
#include <stdio.h>

int		match(char *arr)
{
	char *tetri_str;
	tetri_str = malloc(sizeof(char) * (8 + 1));

	if (MATCH_1)
		tetri_str = "00010203";
/*	(MATCH_2 > 0) && (tetri_str = "00102030");
	(MATCH_3 > 0) && (tetri_str = "00100111");
	(MATCH_4 > 0) && (tetri_str = "00011112");
	(MATCH_5 > 0) && (tetri_str = "10200111");
	(MATCH_6 > 0) && (tetri_str = "10011102");
	(MATCH_7 > 0) && (tetri_str = "00101121");
	(MATCH_8 > 0) && (tetri_str = "10011121");
	(MATCH_9 > 0) && (tetri_str = "00102011");
	(MATCH_10 > 0) && (tetri_str = "00011102");
	(MATCH_11 > 0) && (tetri_str = "10011112");
	(MATCH_12 > 0) && (tetri_str = "00100102");
	(MATCH_13 > 0) && (tetri_str = "00102021");
	(MATCH_14 > 0) && (tetri_str = "10110212");
	(MATCH_15 > 0) && (tetri_str = "00011121");
	(MATCH_16 > 0) && (tetri_str = "00101112");
	(MATCH_17 > 0) && (tetri_str = "00102001");
	(MATCH_18 > 0) && (tetri_str = "00010212");
	(MATCH_19 > 0) && (tetri_str = "20011121");
*/	if (tetri_str == NULL)
	{
		printf("couldn't find\n");
		return (0);
	}
	printf("%s\n", tetri_str);
	return (1);
}

int		valid_shape(char *buf)
{
	int		ctr1;
	int		ctr2;
	char	tmp[20];
	char	*arr;

	ctr1 = 0;
	ctr2 = 0;
	while (buf[ctr1] != '\0')
	{
		if (buf[ctr1] == '#' || buf[ctr1] == '.')
		{
			tmp[ctr2] = buf[ctr1];
			ctr2++;
		}
		ctr1++;
	}
	tmp[ctr2] = '\0';
	arr = trim_dots(tmp);
	printf("%s\n", arr);
	match(arr);
	return (0);
}

int		char_check(char *buf)
{
	int		ctr;
	int		hash_count;

	ctr = 0;
	hash_count = 0;
	while (ctr < 19)
	{
		if (buf[ctr] != '#' & buf[ctr] != '.' && buf[ctr] != '\n')
			return (0);
		if (buf[ctr] == '#')
			hash_count++;
		ctr++;
	}
	if (buf[ctr] != '\n' && hash_count != 4)
		return (0);
	return (1);
}

int		build_valid_tetri(int ret, char *buf)
{
	int		ctr;

	ctr = 0;
	while (ctr < ret)
	{
		if (char_check(&buf[ctr]) == 0)
			return (0);
		if (valid_shape(&buf[ctr]) == 0)
			return (0);
		ctr += 21;
	}
	return (1);
}

int		file_is_valid(int fd)
{
	if (fd < 0 || fd > OPEN_MAX)
		return (0);
	return (1);
}

int		parse_file(int fd)
{
	int		ret;
	char	buf[545];

	if (file_is_valid(fd) == 0)
		return (0);
	ret = read(fd, buf, 545);
	buf[ret] = '\0';
	close(fd);
	if ((ret < 19 || ret > 544) || (ret + 1) % 21 != 0)
		return (0);
	if (build_valid_tetri(ret, buf) == 0)
		return (0);
	return (1);
}
