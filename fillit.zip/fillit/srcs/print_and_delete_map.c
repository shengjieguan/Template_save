/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_and_delete_map.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skoh <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/24 13:58:19 by skoh              #+#    #+#             */
/*   Updated: 2019/10/24 13:59:09 by skoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/fillit.h"

void	print_map(char  **map, int size)
{
	int i;

	i = 0;
	while (i < size)
	{
		ft_putstr(map[i]);
		ft_putchar('\n');
		i++;
	}
}

void	delete_map(char **map, int size)
{
	int i;

	i = 0;
	while (i < size)
	{
		ft_memdel((void **)&(map[i]));
		i++;
	}
	ft_memdel((void **)&map);
}
