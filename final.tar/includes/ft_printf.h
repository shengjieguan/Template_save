/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 13:03:21 by shguan            #+#    #+#             */
/*   Updated: 2019/12/04 12:34:19 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include "../src/libft/libft.h"
# include <stdio.h>
# include <stdlib.h>
# include <stdarg.h>
# include <unistd.h>
# include <string.h>
# include <stdint.h>

typedef	struct	s_tab
{
	int			flag_hash;
	int			flag_zero;
	int			flag_minus;
	int			flag_space;
	int			flag_plus;
	int			pres;
	int			pres_nb;
	int			width;
	int			width_nb;
	char		*length;
	int			len;
	char		*format;
}				t_tab;

char			*ft_pres_nb(char *format, t_tab *arg);
char			*ft_width_nb(char *format, t_tab *arg);
char			*ft_length(char *format, t_tab *arg);
char			*ft_flag(char *format, t_tab *arg);
void			init_arg(t_tab *arg);
char			*check_format(char *format, t_tab *arg, va_list ap);
int				ft_printf(const char *format, ...);
int				print_d(t_tab *arg, va_list ap);
int				print_s(t_tab *arg, va_list ap);
int				print_u(t_tab *arg, va_list ap);
int				print_p(t_tab *arg, va_list ap);
int				print_x(t_tab *arg, va_list ap, char c);
int				print_o(t_tab *arg, va_list ap);
int				print_c(t_tab *arg, va_list ap);
int				print_f(t_tab *arg, va_list ap);
int				print_percentage(t_tab *arg);
int				print_lf(t_tab *arg, va_list ap);
uintmax_t		num_uintmax_t(t_tab *arg, va_list ap);
intmax_t		num_intmax_t(t_tab *arg, va_list ap);
int				ft_countnbr_unsigned(uintmax_t i, int base);
int				ft_countnbr_signed(intmax_t i, int base);
void			print_pad(int padded_len, t_tab *arg, char c);

#endif
