/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:02:47 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 13:00:27 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;

	s = "sSdDioOuUxXcCp%";
	format = ft_flag(format, arg);
	format = ft_width_nb(format, arg);
	format = ft_pres_nb(format, arg);
	format = ft_length(format, arg);
	if (ft_strchr(s, *format) == NULL)
		(write(1, "%", 1)) && (format = arg->format);
	(*format == 's' || *format == 'S') && (print_s(arg, ap));
	(*format == 'p') && (print_p(arg, ap));
	(*format == 'd' || *format == 'D' || *format == 'i') && (print_d(arg, ap));
	(*format == 'o' || *format == 'O') && (print_o(arg, ap));
	(*format == 'u' || *format == 'U') && (print_u(arg, ap));
	(*format == 'x' || *format == 'X') && (print_x(arg, ap, *format));
	(*format == 'c' || *format == 'C') && (print_c(arg, ap));
	(*format == '%') && (print_percentage(arg));
	return (format);
}

void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}

int		ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%')
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if (*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	init_arg(arg);
	return (arg->len);
}
int main(void)
{
int a;
ft_printf("%c.\n", 'a');
	printf("%c.\n", 'a');

	ft_printf("%c.\n", '\0');
	printf("%c.\n", '\0');
	
	ft_printf("%c.\n", (char)0xff11ff11);
	printf("%c.\n", (char)0xff11ff11);

	ft_printf("%c.\n", -21);
	printf("%c.\n", -21);

	ft_printf("%4c.\n", 'U');
	printf("%4c.\n", 'U');

	ft_printf("1%-1c.\n", 12);
	printf("1%-1c.\n", 12);

	ft_printf("2%-12c.\n", '\n');
	printf("2%-12c.\n", '\n');

	ft_printf("hello ca%----4c %1c va %10c%-c ??.\n", '\0', '\n', (char)564, 0);
	printf("hello ca%----4c %1c va %10c%-c ??.\n\n", '\0', '\n', (char)564, 0);

	ft_printf("%.2s.\n", "coco ei titi");
	printf("%.2s.\n", "coco ei titi");

	ft_printf("%.0s.\n", "coco ei titi");
	printf("%.0s.\n", "coco ei titi");

	ft_printf("%.s.\n", "coco");
	printf("%.s.\n", "coco");

	ft_printf("%.2s.\n", NULL);
	printf("%.2s.\n", NULL);

	ft_printf("%10s.\n", NULL);
	printf("%10s.\n", NULL);

	ft_printf("%-8s.\n", "coco");
	printf("%-8s.\n", "coco");
	
		ft_printf("%8s.\n", "coco");
	printf("%8s.\n", "coco");

	ft_printf("%-2s.\n", "");
	printf("%-2s.\n", "");
	
	while (1);
	return 0;
}