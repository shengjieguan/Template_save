/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:02:47 by shguan            #+#    #+#             */
/*   Updated: 2019/12/02 10:24:56 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;

	s = "sSdDioOuUxXcCpf%";
	format = ft_flag(format, arg);
	format = ft_width_nb(format, arg);
	format = ft_pres_nb(format, arg);
	format = ft_length(format, arg);
	arg->format = format;
	(*format == 's' || *format == 'S') && (print_s(arg, ap));
	(*format == 'p') && (print_p(arg, ap));
	(*format == 'd' || *format == 'D' || *format == 'i') && (print_d(arg, ap));
	(*format == 'o' || *format == 'O') && (print_o(arg, ap));
	(*format == 'u' || *format == 'U') && (print_u(arg, ap));
	(*format == 'x' || *format == 'X') && (print_x(arg, ap, *format));
	(*format == 'c' || *format == 'C') && (print_c(arg, ap));
	(*format == '%') && (print_percentage(arg));
	if (*format == 'f' && !ft_strcmp(arg->length, "L"))
		print_lf(arg, ap);
	else if (*format == 'f')
		print_f(arg, ap);
	//else if(*format == 'f')
	//	print_f(arg, ap);
	if (ft_strchr(s, *format) == NULL)
		format = arg->format;
	return (format);
}

void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}

int		ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%' && *(format + 1))
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if (*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	free(arg);
	return (arg->len);
}
