/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa_uintmax_t.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:08:59 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 11:09:56 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_itoa_uintmax_t(uintmax_t value, uintmax_t base, char c)
{
	size_t	i;
	size_t	len;
	int		sign;
	char	tmp[130];
	char	*ret;
puts("comme")
	len = 0;
	sign = (!value ? -1 : 1);
	(value == 0) && (tmp[len++] = '0');
	while (value)
	{
		(c == 'd' || c == 'u') && (tmp[len++] = HEX_NUM[value % base * sign]);
		(c == 'x' || c == 'p') && (tmp[len++] = HEX[value % base * sign]);
		(c == 'X') && (tmp[len++] = HEX_BIG[value % base * sign]);
		value /= base;
	}
	(sign == -1 && base == 10) && (tmp[len++] = '-');
	if (!(ret = (char*)malloc(sizeof(char) * (len + 1))))
		return (NULL);
	ret[len] = 0;
	i = -1;
	while (++i < len)
		ret[i] = tmp[len - 1 - i];
	return (ret);
}
