/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   num_type.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:34:04 by shguan            #+#    #+#             */
/*   Updated: 2019/12/03 14:55:54 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void		print_pad(int padded_len, t_tab *arg, char c)
{
	int	i;

	i = 0;
	while (i < padded_len)
	{
		write(1, &c, 1);
		arg->len++;
		i++;
	}
}

int			ft_countnbr_unsigned(uintmax_t i, int base)
{
	int	n;

	n = 1;
	if (!n && n != 0)
	{
		n++;
		i *= -1;
	}
	while (i > 9)
	{
		i /= base;
		n++;
	}
	return (n);
}

uintmax_t	num_uintmax_t(t_tab *arg, va_list ap)
{
	uintmax_t	num;

	num = 0;
	if (arg->length == NULL)
		num = (unsigned)va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "h"))
		num = (unsigned short)va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "hh"))
		num = (unsigned char)va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "l"))
		num = (unsigned long)va_arg(ap, long);
	else if (!ft_strcmp(arg->length, "ll") || ft_strcmp(arg->length, "z"))
		num = (unsigned long long)va_arg(ap, long long);
	return (num);
}

intmax_t	num_intmax_t(t_tab *arg, va_list ap)
{
	long long int	num;

	num = 0;
	if (arg->length == NULL)
		num = va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "h"))
		num = (short)va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "hh"))
		num = (signed char)va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "l"))
		num = va_arg(ap, long);
	else if (!ft_strcmp(arg->length, "ll"))
		num = (long long)va_arg(ap, long long);
	else if (!ft_strcmp(arg->length, "z"))
		num = va_arg(ap, size_t);
	if (num < -9223372036854775807)
		write(1, "-9223372036854775808", 20) && (arg->len += 20);
	if (num > 9223372036854775807)
	{
		write(1, "9223372036854775808", 19);
		arg->len += 19;
	}
	return (num);
}

int			ft_countnbr_signed(intmax_t i, int base)
{
	int n;

	n = 1;
	if (i < 0)
	{
		n++;
		i *= -1;
	}
	while (i > 9)
	{
		i /= base;
		n++;
	}
	return (n);
}
