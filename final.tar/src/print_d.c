/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:40:42 by shguan            #+#    #+#             */
/*   Updated: 2019/12/03 14:58:19 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void	ft_num_neg(t_tab *arg, int arg_len, intmax_t num, char c)
{
	arg->width_nb--;
	arg_len--;
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	arg->pres_nb -= (arg->pres_nb > arg_len ? arg_len : arg->pres_nb);
	if(arg->width_nb && !arg->flag_minus)
	{
		if (arg->flag_zero && !arg->pres)
		{
		 write(1, "-", 1);
		 num *= -1;
		}
		print_pad(arg->width_nb, arg, c);	
	}
	if (arg->pres)
	{
		 write(1, "-", 1);
		 num *= -1;
	}
	if(arg->pres_nb)
		print_pad(arg->pres_nb, arg, '0');
	ft_putnbr_signed(num, 10);
	if(arg->width_nb && arg->flag_minus)
		print_pad(arg->width_nb, arg, c);	
}

void	ft_num_pos(t_tab *arg, int arg_len, intmax_t num, char c)
{
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	arg->pres_nb -= (arg->pres_nb > arg_len ? arg_len : arg->pres_nb);
	if (arg->flag_plus || arg->flag_space) 
	{
		arg->width_nb--;
		arg->len++;
		(arg->flag_zero && arg->flag_plus) && write(1, "+", 1);
		(arg->flag_space) && write(1, " ", 1);
	}
	if(arg->width_nb && !arg->flag_minus)
		print_pad(arg->width_nb, arg, c);	
	if(arg->flag_plus && !arg->flag_zero)
		 write(1, "+", 1);
	if(arg->pres_nb)
		print_pad(arg->pres_nb, arg, '0');
	ft_putnbr_signed(num, 10);
	if(arg->width_nb && arg->flag_minus)
		print_pad(arg->width_nb, arg, c);	
}

void	ft_num_zero(t_tab *arg, char c)
{
	(arg->flag_plus) && arg->width_nb--;
	(arg->flag_plus && arg->flag_minus) && write(1, "+", 1);
	print_pad(arg->width_nb, arg, c);
	(arg->flag_plus && !arg->flag_minus) && write(1, "+", 1);
	arg->len--;
}

int		print_d(t_tab *arg, va_list ap)
{
	int			arg_len;
	intmax_t	num;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	(arg->flag_zero && arg->pres) && (c = ' ');
	num = num_intmax_t(arg, ap);
	if (!(num >= -9223372036854775807 && num <= 9223372036854775807))
		return (arg->len);
	(arg_len = ft_countnbr_signed(num, 10)) && (arg->len += arg_len);
	if(!num && arg->pres && arg->pres_nb < 1 && !arg->width)
		ft_num_zero(arg, c);
	else if(num >= 0)
		ft_num_pos(arg, arg_len, num, c);
	else if(num < 0)
		ft_num_neg(arg, arg_len, num, c);
	return (arg->len);
}
