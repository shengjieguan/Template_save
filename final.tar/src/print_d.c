/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_d.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 11:40:42 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 11:51:06 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

int		print_d_result(t_tab *arg, intmax_t num, int arg_len, char c)
{
	if (arg->flag_plus && num >= 0 && !arg->pres)
		write(1, "+", 1) && arg->len++;
	//if ((arg->width_nb - arg_len >= arg->pres_nb) && !arg->flag_zero)
	if (((arg_len -1) < arg->pres_nb) && !arg->flag_zero)
		(num <= -1 && arg->pres) && arg->width_nb--;
	else if (arg->width_nb > arg_len && num < 0 && arg->flag_zero)
		write(1, "-", 1) && (num *= -1) && arg_len-- && arg->width_nb--;
	if (arg->width_nb && arg->pres)
		arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	if (arg->width_nb && !arg->pres)
		arg->width_nb -= arg_len;
	if (arg->width_nb > 0 && !arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	if (arg->pres_nb > 0)
	{
		if (arg->flag_plus && num >= 0)
			(write(1, "+", 1)) && arg->width_nb-- && arg->len++;
		if (num < 0)
			write(1, "-", 1) && (num *= -1) && arg->pres_nb++;
		print_pad(arg->pres_nb - arg_len, arg, '0');
	}
	ft_putnbr_signed(num, 10);
	if (arg->width_nb > 0 && arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	return (1);
}

int		print_d(t_tab *arg, va_list ap)
{
	int			arg_len;
	intmax_t	num;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	(arg->flag_zero && arg->pres) && (c = ' ');
	num = num_intmax_t(arg, ap);
	(arg_len = ft_countnbr_signed(num, 10)) && (arg->len += arg_len);
	(arg->flag_plus && num >= 0 && !arg->flag_minus) && arg->width_nb--;
	if (arg->pres && (arg->pres_nb < 1) && !num)
	{
		print_pad(arg->width_nb, arg, c);
		arg->len--;
		return (arg->len);
	}
	if (arg->flag_space == 1 && !arg->flag_minus && !arg->flag_plus && num >= 0)
	{
		(write(1, " ", 1)) && arg->width_nb--;
		arg->len++;
	}
	return (print_d_result(arg, num, arg_len, c));
}
