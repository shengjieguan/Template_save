/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_f.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 09:52:58 by shguan            #+#    #+#             */
/*   Updated: 2019/12/04 12:28:56 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void			float_to_int(t_tab *arg, long double num, int num_int)
{
	intmax_t n;
	int i;
	int count;
	int zero;

	i = ft_countnbr_signed(num_int, 10);
	count = i + arg->pres_nb;
	zero = arg->pres_nb;
	while(arg->pres_nb-- > 0)
		num *= 10;
	//printf("1=%Lf", num);
	num *= 10;
	n = (long double)(num / 1);
		

	
	if((n % 10) > 5)
	{
		n /= 10;
		n++;
	}
	else
		n /= 10;
	count -= ft_countnbr_signed(n, 10);
	while(count-- > 0)
	{
		if(i == 0)
			write(1, ".", 1);
		i--;
		write(1, "0", 1);
	}
	
	if(i > 0)
	{
			ft_putnbr_signed(num_int, 10);
			count = 1;
			printf("p=%d", arg->pres_nb);
			while (arg->pres_nb < zero)
			{
				//printf("%d", count);
				count *= 10;
			}	
			i = 0;
	}
	
printf("nn=%jd", n);	
	printf("c=%d", count);
	n %= zero
	(i == 0) && write(1, ".", 1);
	zero -= ft_countnbr_signed(n, 10);
	printf("n=%jd", n);
	//printf("%jd", n);
	while(zero-- > 0)
		write(1, "0", 1);
	//ft_putnbr_signed(n, 10);
}

long double	ft_num(t_tab *arg, long double num)
{
	if (num > 0)
	{
		(arg->flag_plus) && write(1, "+", 1) && arg->len++;
		if (!arg->flag_plus && arg->flag_space)	
		{

			write(1, " ", 1) && arg->len++;
			arg->width_nb--;
		}		
	}
	if (num < 0)
	{	
		(num *= -1) && write(1, "-", 1) && arg->len++;
		arg->width_nb--;
	}
	return (num);
}

int			print_lf(t_tab *arg, va_list ap)
{
	long double	num;
	int		num_int;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	num = va_arg(ap, long double);
	
	(arg->pres_nb == -1) && (arg->pres_nb = 6);
	num = ft_num(arg, num);
	num_int = (long double)(num / 1);
	//printf("1=%Lf", num);
	//printf("2=%d", num_int);

	arg->width_nb -= (arg->pres_nb + 1 + ft_countnbr_signed(num_int, 10));
	arg->len += ft_countnbr_signed(num_int, 10) + 1 + arg->pres_nb;
	if (!arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	//	printf("1=%Lf", num);
	float_to_int(arg, num, num_int);
	if (arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}

int			print_f(t_tab *arg, va_list ap)
{
	long double	num;
	int			num_int;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	num = va_arg(ap, double);
	(arg->pres_nb == -1) && (arg->pres_nb = 6);
	num = ft_num(arg, num);
	num_int = (long double)(num / 1);
	arg->width_nb -= (arg->pres_nb + 1 + ft_countnbr_signed(num_int, 10));
	arg->len += ft_countnbr_signed(num_int, 10) + 1 + arg->pres_nb;
	if (!arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	float_to_int(arg, num, num_int);
	if (arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}
