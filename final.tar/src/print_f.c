/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_f.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/04 09:52:58 by shguan            #+#    #+#             */
/*   Updated: 2019/12/04 12:28:56 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

long double	ft_num(t_tab *arg, long double num)
{
	if (num > 0)
	{
		(arg->flag_plus) && write(1, "+", 1) && arg->len++;
		if (!arg->flag_plus && arg->flag_space)
			write(1, " ", 1) && arg->len++ && arg->width_nb--;
	}
	if (num < 0)
		(num *= -1) && write(1, "-", 1) && arg->len++ && arg->width_nb--;
	return (num);
}

int			print_lf(t_tab *arg, va_list ap)
{
	long double	num;
	int			num_int;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	num = va_arg(ap, long double);
	(arg->pres_nb == -1) && (arg->pres_nb = 6);
	num = ft_num(arg, num);
	num_int = (long double)(num / 1);
	num -= num_int;
	arg->width_nb -= (arg->pres_nb + 1 + ft_countnbr_signed(num_int, 10));
	arg->len += ft_countnbr_signed(num_int, 10) + 1 + arg->pres_nb;
	while (arg->pres_nb-- > 0)
		num *= 10;
	if (!arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	ft_putnbr_signed(num_int, 10);
	write(1, ".", 1);
	ft_putnbr_signed(num, 10);
	if (arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}

int			print_f(t_tab *arg, va_list ap)
{
	long double	num;
	int			num_int;
	char		c;

	c = (arg->flag_zero ? '0' : ' ');
	num = va_arg(ap, double);
	(arg->pres_nb == -1) && (arg->pres_nb = 6);
	num = ft_num(arg, num);
	num_int = (long double)(num / 1);
	num -= num_int;
	arg->width_nb -= (arg->pres_nb + 1 + ft_countnbr_signed(num_int, 10));
	arg->len += ft_countnbr_signed(num_int, 10) + 1 + arg->pres_nb;
	while (arg->pres_nb-- > 0)
		num *= 10;
	if (!arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	ft_putnbr_signed(num_int, 10);
	write(1, ".", 1);
	ft_putnbr_signed(num, 10);
	if (arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}
