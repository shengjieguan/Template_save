/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_p.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/29 10:09:12 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 10:38:42 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

int	print_result(char *str, t_tab *arg, int arg_len)
{
	if ((arg->width_nb >= 1 || arg->pres_nb >= 1) && !arg->flag_minus)
	{
		if (arg->pres_nb < arg->width_nb)
			print_pad(arg->width_nb, arg, ' ');
		write(1, "0x", 2) && (arg->len += 2);
		print_pad(arg->pres_nb, arg, '0');
		write(1, str, arg_len) && (arg->len += arg_len);
	}
	else if ((arg->width_nb >= 1 || arg->pres_nb >= 1) && arg->flag_minus)
	{
		print_pad(arg->pres_nb, arg, '0');
		write(1, "0x", 2) && (arg->len += 2);
		write(1, str, arg_len) && (arg->len += arg_len);
		if (arg->pres_nb < arg->width_nb && arg->width_nb)
			print_pad(arg->width_nb, arg, ' ');
	}
	else
	{
		if (!arg->flag_minus)
			write(1, "0x", 2) && (arg->len += 2);
		if (arg->pres_nb < 1 && arg->pres)
			return (arg->len);
		write(1, str, arg_len) && (arg->len += arg_len);
	}
	return (1);
}

int		print_p(t_tab *arg, va_list ap)
{
	uintmax_t	str_nb;
	char		*str;
	int			arg_len;

	str_nb = (uintmax_t)va_arg(ap, void*);
	str = ft_itoa_uintmax_t(str_nb, 16, 'p');
	arg_len = ft_strlen(str);
	arg->width_nb -= (arg_len + 2);
	arg->pres_nb -= arg_len;
	print_result(str, arg, arg_len);
	free(str);
	return (arg->len);
}
