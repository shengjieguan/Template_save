/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_percentage.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/26 16:07:39 by shguan            #+#    #+#             */
/*   Updated: 2019/11/29 12:08:16 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

int		print_percentage(t_tab *arg)
{
	char	c;

	c = (arg->flag_zero ? '0' : ' ');
	if (arg->width_nb > 0 && !arg->flag_minus)
		print_pad(--arg->width_nb, arg, c);
	write(1, "%", 1) && arg->len++;
	if (arg->width_nb > 0 && arg->flag_minus)
		print_pad(--arg->width_nb, arg, c);
	return (arg->len);
}
