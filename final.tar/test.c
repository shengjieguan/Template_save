#include "includes/ft_printf.h"

int main()
{
	

	//ft_printf("%.8Lf", -5.02999949l);
	//printf("%.8Lf\n", -5.02999949l);

//ft_printf("%Lf", 0.08942555l);
//printf("%Lf\n", 0.08942555l);

ft_printf("%.7Lf\n", 573.924l);
//printf("%.7Lf", 573.924l);
return (0);
}