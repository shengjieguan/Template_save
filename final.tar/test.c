#include "includes/ft_printf.h"

int main()
{
	ft_printf("%+5i\n", 35);
	printf("%+5i\n", 35);

	ft_printf("%+7i\n", 0);
	printf("%+7i\n", 0);
	ft_printf("%010.5i\n", -216);
	printf("%010.5i\n", -216);
	ft_printf("% -7i\n", 33);
	printf("% -7i\n", 33);

	ft_printf("% i\n", 0);
	printf("% i\n", 0);

ft_printf("%+.0i", -1);
printf("%+.0i", -1);
}
