#include "includes/ft_printf.h"
#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>
int	main()
{

int a;
printf("{%f}{%lf}{%Lf}", 1.42, 1.42, 1.42l);
printf("{%f}{%lf}{%Lf}", 1.42, 1.42, 1.42l);

   ft_printf("%c.\n", 'a');
   	printf("%c.\n", 'a');
   
   	ft_printf("%c.\n", '\0');
   	printf("%c.\n", '\0');
   	
   	ft_printf("%c.\n", (char)0xff11ff11);
   	printf("%c.\n", (char)0xff11ff11);
   
   	ft_printf("%c.\n", -21);
   	printf("%c.\n", -21);
   
   	ft_printf("%4c.\n", 'U');
   	printf("%4c.\n", 'U');
   
   	ft_printf("1%-1c.\n", 12);
   	printf("1%-1c.\n", 12);
   
   	ft_printf("2%-12c.\n", '\n');
   	printf("2%-12c.\n", '\n');
   
   	ft_printf("hello ca%----4c %1c va %10c%-c ??.\n", '\0', '\n', (char)564, 0);
   	printf("hello ca%----4c %1c va %10c%-c ??.\n\n", '\0', '\n', (char)564, 0);

 	ft_printf("%.2s.\n", "coco ei titi");
 	printf("%.2s.\n", "coco ei titi");
 
 	ft_printf("%.0s.\n", "coco ei titi");
 	printf("%.0s.\n", "coco ei titi");
 
 	ft_printf("%.s.\n", "coco");
 	printf("%.s.\n", "coco");
 
 	ft_printf("%.2s.\n", NULL);
 	printf("%.2s.\n", NULL);
 
 	ft_printf("%10s.\n", NULL);
 	printf("%10s.\n", NULL);
 
 	ft_printf("%-8s.\n", "coco");
 	printf("%-8s.\n", "coco");
 	
 		ft_printf("%8s.\n", "coco");
 	printf("%8s.\n", "coco");
 
 	ft_printf("%-2s.\n", "");
 	printf("%-2s.\n", "");
 	
 	ft_printf("%1s.\n", "hi");
 	printf("%1s.\n", "hi");
 	
 
 	ft_printf("%.0s.%s.%---12s.\n", "hi", "coco", NULL);
 	printf("%.0s.%s.%---12s.\n", "hi", "coco", NULL);
 
 	ft_printf("%1.4s et .%-6.8s. et %4.2s\n", "tuuu", "12345", "hu");
 	printf("%1.4s et .%-6.8s. et %4.2s\n", "tuuu", "12345", "hu");
    ft_printf("%p\n", NULL);
    printf("%p\n", NULL);
  
  ft_printf("%p\n", &a);
    printf("%p\n", &a);
  
      ft_printf("%20p.\n", &a);
      printf("%20p.\n", &a);
  
      ft_printf("%-20p.\n", &a);
      printf("%-20p.\n", &a);
  
     ft_printf("%2p\n", &a);
     printf("%2p\n", &a);
  
     ft_printf("%----24p et hello %2p %12p\n", &a, &a, NULL);
      printf("%----24p et hello %2p %12p\n", &a, &a, NULL);
 
   ft_printf("%u\n", 0);
   printf("%u\n", 0);
   
   ft_printf("%u\n", 1234);
   printf("%u\n", 1234);
   
   ft_printf("%u\n", -1001234);
   printf("%u\n", -1001234);
   
   ft_printf("%hhu\n", (unsigned char)20);
   printf("%hhu\n", (unsigned char)20);
   
   ft_printf("%hu\n", (unsigned short)12220);
   printf("%hu\n", (unsigned short)12220);
   
   ft_printf("%.10u\n", 21);
   printf("%.10u\n", 21);
   
   ft_printf("%.1u\n", 121);
   printf("%.1u\n", 121);
   
   ft_printf("%.0u\n", 76543);
   printf("%.0u\n", 76543);
   
   ft_printf("%4u\n", 1);
   printf("%4u\n", 1);
   
   ft_printf("%-12u.\n", 17894);
   printf("%-12u.\n", 17894);
   
   ft_printf("%2u\n", 17894);
   printf("%2u\n", 17894);
   
   ft_printf("%08u\n", 171894);
   printf("%08u\n", 171894);
   
   ft_printf("%0u.\n", 194);
   printf("%0u.\n", 194);
   
   ft_printf("%-3u.\n", 194);
   printf("%-3u.\n", 194);
   
   ft_printf("toto et %02u coco %-5lu. mimi\n", 19, (unsigned long)-20);
   printf("toto et %02u coco %-5lu. mimi\n", 19, (unsigned long)-20);
   
   ft_printf("toto et %00009U%-2lu mimi et titi%--14u.\n", 0, (unsigned long)14, 200);
   printf("toto et %00009U%-2lu mimi et titi%--14u.\n", 0, (unsigned long)14, 200);
   
   ft_printf("ko%-4.2hhu et %05.2u!\n", (unsigned char)-456, 0);
   printf("ko%-4.2hhu et %05.2u!\n", (unsigned char)-456, 0);
   
   ft_printf("%05.1u %3.4hu %-4.7U.\n", 45, (unsigned short)-1789, 147);
   printf("%05.1u %3.4hu %-4.7U.\n", 45, (unsigned short)-1789, 147);
   
   ft_printf("%.u\n", 0);
   printf("%.u\n", 0);
   
   ft_printf("%.0U\n", 0);
   printf("%.0U\n", 0);
   ft_printf("%x\n", 0);
   printf("%x\n", 0);
  
   ft_printf("%X\n", 0xa0);
   printf("%X\n", 0xa0);
  
   ft_printf("%x\n", 0xa0ffff);
   printf("%x\n", 0xa0ffff);
  
   ft_printf("%x\n", -12345678);
   printf("%x\n", -12345678);
  
   ft_printf("%X\n", -1234567800);
  printf("%X\n", -1234567800);
  
   ft_printf("%#X\n", 0);
  printf("%#X\n", 0);
  
   ft_printf("%#x.\n", 0x78aa);
  printf("%#x.\n", 0x78aa);
  
   ft_printf("%#X\n", 0xff7744);
  printf("%#X\n", 0xff7744);
  
   ft_printf("%.x.\n", 12);
  printf("%.x.\n", 12);
  
   ft_printf("%.0X.\n", 0xaabbcc);
  printf("%.0X.\n", 0xaabbcc);
  
   ft_printf("%4x\n", 0xdd);
  printf("%4x\n", 0xdd);
  
   ft_printf("%011X\n", 0xdd66);
  printf("%011X\n", 0xdd66);
  
   ft_printf("%-6x.\n", 0xdd66);
  printf("%-6x.\n", 0xdd66);
  
   ft_printf("%-2x.\n", 0xadd66);
  printf("%-2x.\n", 0xadd66);
  
   ft_printf("%20x\n", 0x123456bc);
  printf("%20x\n", 0x123456bc);
  
   ft_printf("test%---10.6x et %01hhX !!\n", 0xaabb, (unsigned char)0);
  printf("test%---10.6x et %01hhX !!\n", 0xaabb, (unsigned char)0);
  
   ft_printf("t %#7.5X%0006.2x et %lX!\n", 0xab, 0x876, 0xff11ff11ff1);
  printf("t %#7.5X%0006.2x et %lX!\n", 0xab, 0x876, 0xff11ff11ff1);
  
   ft_printf("toto %0##0.4X%#4.2xet c'est fini .\n", 0x037a, 0x9e);
  printf("toto %0##0.4X%#4.2xet c'est fini .\n", 0x037a, 0x9e);
  
   ft_printf("cc%#.4X et %#0012x %#04hX !!\n", 0xaef, 0xe, (unsigned short)0);
  printf("cc%#.4X et %#0012x %#04hX !!\n", 0xaef, 0xe, (unsigned short)0);
  
   ft_printf("%#.22zX et %020.14jx\n", 0xff1144ff1144, 0xffaabbccee);
   printf("%#.22zX et %020.14jx\n", 0xff1144ff1144, 0xffaabbccee);
  
   ft_printf("osef ! %#9llX et %-12hhx.\n", (unsigned long long)-1248759650, (unsigned char)-1478223695);
  printf("osef ! %#9llX et %-12hhx.\n", (unsigned long long)-1248759650, (unsigned char)-1478223695);
  
   ft_printf("%hhx\n", (unsigned char)-10);
  printf("%hhx\n", (unsigned char)-10);
  
   ft_printf("%hX\n", (unsigned short)40);
  printf("%hX\n", (unsigned short)40);
  
   ft_printf("%lx\n", 30000001245258745);
  printf("%lx\n", 30000001245258745);
  
   ft_printf("%llX\n", (unsigned long long)0xaaffee11996677);
  printf("%llX\n", (unsigned long long)0xaaffee11996677);
  
   ft_printf("%lx\n", (unsigned long)-178965423);
  printf("%lx\n", (unsigned long)-178965423);
  
   ft_printf("%jX\n", (uintmax_t)-1765423);
  printf("%jX\n", (uintmax_t)-1765423);
  
   ft_printf("%zx\n", 65423000000);
   printf("%zx\n", 65423000000);
  
   ft_printf("% .7X\n", 0xaa);
    printf("% .7X\n", 0xaa);
  
  ft_printf("%.0x.\n", 0);
  printf("%.0x.\n", 0);
  
   ft_printf("toto %##.0xet %#.X.%###.1x\n", 0, 0, 0);
  printf("toto %##.0xet %#.X.%###.1x\n", 0, 0, 0);
  
   ft_printf("%0#10.0x %0#x\n", 12345, 0);
  printf("%0#10.0x %0#x\n", 12345, 0);
  
   ft_printf("%0#10.0x\n", 0);
  printf("%0#10.0x\n", 0);
   	ft_printf("%d\n", 42);
   	printf("%d\n\n", 42);
  
   	ft_printf("%d\n", -42);
   	printf("%d\n\n", -42);
  
  
  	ft_printf("% d\n", 0);
  	printf("% d\n\n", 0);
  
  	ft_printf("%+d\n", 0);
  	printf("%+d\n\n", 0);
  
  	ft_printf("%+++d\n", 534);
  	printf("%+++d\n\n", 534);
  
  	ft_printf("%+d\n", -4440);
  	printf("%+d\n\n", -4440);
  
  	ft_printf("% d\n", 0xff11ff);
  	printf("% d\n\n", 0xff11ff);
  
  	ft_printf("%ld\n", 0x44ff551100);
  	printf("%ld\n\n", 0x44ff551100);
  ^
  	ft_printf("%zi\n", (long)40000);
  	printf("%zi\n\n", (long)40000);
  ^
  	ft_printf("%lld\n", (long long)-4278900);
  	printf("%lld\n\n", (long long)-4278900);
  ^
  	ft_printf("%hd\n", (short)0x1789ffff);
  	printf("%hd\n\n", (short)0x1789ffff);
  ^
  	ft_printf("%lli\n", (long long)0x11ff11ff11ff11ff);
  	printf("%lli\n\n", (long long)0x11ff11ff11ff11ff);
  ^
  	ft_printf("%lD\n", 0xff11ff11ff88);
  	printf("%ld\n\n", 0xff11ff11ff88);
  ^
  	ft_printf("%D\n", 0);
  	printf("%D\n\n", 0);
  ^
  	ft_printf("%i\n", (signed int)0xff11);
  	printf("%i\n\n", (signed int)0xff11);
  ^
  ^
  	ft_printf("%.12d\n", 1144);
  	printf("%.12d\n\n", 1144);
  ^
  	ft_printf("%.2i\n", -10);
  	printf("%.2i\n\n", -10);
  ^
  	ft_printf("%.i\n", 44);
  	printf("%.i\n\n", 44);
  ^
  	ft_printf("%.0d\n", -21);
  	printf("%.0d\n\n", -21);
  ^
  	ft_printf("%.5d\n", -421);
  	printf("%.5d\n\n", -421);
  ^
  	ft_printf("%5d\n", -741);
  	printf("%5d\n\n", -741);
  
  	ft_printf("%08i\n", -71);
  	printf("%08i\n\n", -71);
  ^
  	ft_printf("%-2i\n", -7);
  	printf("%-2i\n\n", -7);
  ^
  	ft_printf("%-7d.\n", 7789);
  	printf("%-7d.\n\n", 7789);
  ^
  	ft_printf("%.5d\n", -421);
  	printf("%.5d\n\n", -421);
  ^
  	ft_printf("%0d\n", -579);
  	printf("%0d\n\n", -579);
  ^
  	ft_printf("%04d\n", 0);
  	printf("%04d\n\n", 0);
  ^
  	ft_printf("%+12.5d.\n", 140);
  	printf("%+12.5d.\n\n", 140);
  ^
  
  	ft_printf("%00+10.4d\n", 0);
  	printf("%00+10.4d\n\n", 0);
  ^
  	ft_printf("%20.ld et %.4hhi !\n", 0x11ffaa147, (signed char)-8);
  	printf("%20.ld et %.4hhi !\n\n", 0x11ffaa147, (signed char)-8);
  ^
  	ft_printf("% 20.12ld et % 05D% 4.8hi !\n", 0x11ffaa147, 24, (short)-2345);
  	 printf("% 20.12ld et % 05D% 4.8hi !\n\n", 0x11ffaa147, 24, (short)-2345);
  
  	 	ft_printf("%00+10.4d\n", 0);
  	printf("%00+10.4d\n\n", 0);
  	ft_printf("%.12d\n", 1144);
  	printf("%.12d\n\n", 1144);
  
  	ft_printf("%o\n", 0);
  	printf("%o\n", 0);
  	ft_printf("%o\n", 1475);
  	printf("%o\n", 1475);
  
  	ft_printf("%o\n", -123654789);
  	printf("%o\n", -123654789);
  
  	ft_printf("%#o\n", 0);
  	printf("%#o\n", 0);
  
  
  ft_printf("%#o\n", 1000); 0
  printf("%#o\n", 1000);
  ft_printf("%#o\n", -896);^0
  printf("%#o\n", -896);
  
  ft_printf("%hho\n", (unsigned char)-12);
  printf("%hho\n", (unsigned char)-12);
  
  ft_printf("%ho\n", (unsigned short)1475);
  printf("%ho\n", (unsigned short)1475);
  
  ft_printf("%lo\n", (unsigned long)258);
  printf("%lo\n", (unsigned long)258);
  
  ft_printf("%O\n", 0);
  printf("%O\n", 0);
  
  ft_printf("%O\n", -1470);
  printf("%O\n", -1470);
  
  ft_printf("%.2o\n", 0);
  printf("%.2o\n", 0);
  
  ft_printf("%.2o\n", 120);
  printf("%.2o\n", 120);
  
  ft_printf("%03o\n", 0);
  printf("%03o\n", 0);
  ft_printf("%.o\n", 12012);
  printf("%.o\n", 12012);
  
  ft_printf("%.24o\n", 12012);
  printf("%.24o\n", 12012);
  
  ft_printf("%1o\n", 0);
  printf("%1o\n", 0);
  
  ft_printf("%01o\n", 0);
  printf("%01o\n", 0);
  
  ft_printf("%03o\n", 0);
  printf("%03o\n", 0);
  
  ft_printf("%6o\n", 01423);
  printf("%6o\n", 01423);
  
  ft_printf("%2o\n", 01423);
  printf("%2o\n", 01423);
  
  ft_printf("%-12o.\n", 01423);
  printf("%-12o.\n", 01423);
  
  ft_printf("%011o\n", 013);
  printf("%011o\n", 013);
  
  ft_printf("%-6o\n", 0155224);
  printf("%-6o\n", 0155224);
  
  ft_printf("coco et %-#-#--24O titi%#012o\n", 12, -874); 0
  printf("coco et %-#-#--24O titi%#012o\n", 12, -874);
  
  ft_printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);
  printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);
  
  ft_printf("%024hho et%#.o %0012.O\n", (unsigned char)12, 1, 123654789);
  printf("%024hho et%#.o %0012.O\n", (unsigned char)12, 1, 123654789);
  
  ft_printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);
  printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);
  
  ft_printf("%.0o\n", 0);
  printf("%.0o\n", 0);
  
  ft_printf("%.O\n", 0);
  printf("%.O\n", 0);
  
  ft_printf("toto %###.0o%#.O et %#.1o !\n", 0, 0, 0);
  printf("toto %###.0o%#.O et %#.1o !\n", 0, 0, 0);
  
  ft_printf("m%#.9odee\n", 123456789);
  printf("m%#.9odee\n", 123456789);
  
  ft_printf("%o\n", 0);
  	printf("%o\n", 0);
  
  ft_printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);
  printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);
  
  ft_printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);
  printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);
  
  ft_printf("%.2o\n", 0);
  printf("%.2o\n", 0);
 	system("leaks a.out");	
  return 0;
}
