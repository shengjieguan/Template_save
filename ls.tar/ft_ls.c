#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>


typedef struct s_ls
{
	struct s_ls *next;
	char *filename;
	char *user;
	char *group;
	char *time;
	nlink_t	nlink;
	off_t size;
	char mode[12];
	time_t	mtime;
}				t_ls;


char		*stat_time(char *src)
{
	int n;
	char *d;

	n = strlen(src) - 9;
	d = (char*)malloc(n);
	while(--n >= 0)
		d[n] = src[n];
	return (d);
}
char		ft_file_type(int m)
{
	if ((m & 61440) == 49152)
		return ('s');
	if ((m & 61440) == 40960)
		return ('l');
	if ((m & 61440) == 32768)
		return ('-');
	if ((m & 61440) == 24576)
		return ('b');
	if ((m & 61440) == 16384)
		return ('d');
	if ((m & 61440) == 8192)
		return ('c');
	return ('p');
}
void		stat_mode(char *mode, int m)
{
	mode[0] = ft_file_type(m);
	mode[1] = (m & 256) ? 'r' : '-';
	mode[2] = (m & 128) ? 'w' : '-';
	mode[3] = (m & 64) ? 'x' : '-';
	if (m & 2048)
		mode[3] = mode[3] == 'x' ? 's' : 'S';
	mode[4] = (m & 32) ? 'r' : '-';
	mode[5] = (m & 16) ? 'w' : '-';
	mode[6] = (m & 8) ? 'x' : '-';
	if (m & 1024)
		mode[6] = mode[6] == 'x' ? 's' : 'S';
	mode[7] = (m & 4) ? 'r' : '-';
	mode[8] = (m & 2) ? 'w' : '-';
	mode[9] = (m & 1) ? 'x' : '-';
	if (m & 512)
		mode[9] = mode[9] == 'x' ? 't' : 'T';
	mode[10] = ' ';
	mode[11] = '\0';
}

t_ls		*ft_create_elem(void *data)
{
	t_ls	*tmp;
	struct stat stat;

	if (!(tmp = (t_ls *)malloc(sizeof(t_ls))))
		return (NULL);
	tmp->filename = data;
	lstat(data, &stat);
	stat_mode(tmp->mode, stat.st_mode);
	tmp->user = getpwuid(stat.st_uid)->pw_name;
	tmp->group = getgrgid(stat.st_gid)->gr_name;
	tmp->nlink = stat.st_nlink;
	tmp->size = stat.st_size;
	tmp->time = stat_time((ctime(&stat.st_mtime)) + 4);
	tmp->next = NULL;
	tmp->mtime = stat.st_mtime;
	
	return (tmp);
}
void	create_linklist(t_ls **begin_list, void *data)
{
	t_ls	*list;

	list = *begin_list;
	if (list)
	{
		while (list->next)
			list = list->next;
		list->next = ft_create_elem(data);
	}
	else
		*begin_list = ft_create_elem(data);
}
void	print_ls(t_ls *ls)
{
	while(ls)
	{
		printf("%s %hu %s %s %lld %s %s\n", ls->mode, ls->nlink, ls->user, ls->group, ls->size, ls->time, ls->filename);
		printf("%ld\n", ls->mtime);
		ls = ls->next;
	}
}
// char	*ft_strchr(char *s, int c)
// {
// 	while (*s != '\0' && *s != (char)c)
// 		s++;
// 	if (*s != (char)c)
// 		return (NULL);
// 	else
// 		return ((char*)s);
// }
void  swap(t_ls *p1, t_ls *p2)
{
  p1->next = p2->next;
    p2->next = p1;
    return (p2);
}
  
  
void  sort_list(t_ls *c)
{
  while(c->next)
  {
    if(c->data[0] > c->next->data[0])
    {
      swap(c, c->next);
      sort_list(c);
    }
    c = c->next;
  }
void	sort_by_time(t_ls *ls)
{

}
void	sort_by_rev(t_ls **ls)
{
	t_ls *root;
	t_ls *node;
	t_ls *next;

	root = *ls;
	node = 0;
	while (root)
	{
		next = (*root).next;
		(*root).next = node;
		node = root;
		root = next;
	}
	*ls = node;
}

void	use_flag_sort_linklist(t_ls **ls, char *flag)
{
	if(strchr(flag, 't'))
		sort_by_time(ls);
	if(strchr(flag, 'r'))
		sort_by_rev(ls);
}

int	main(int ar, char **av)
{
	DIR *dir;
	struct dirent *ptr;
	t_ls	*ls;

	dir = opendir(".");
	while((ptr = readdir(dir)) > 0)
	{
		create_linklist(&ls, strdup(ptr->d_name));
	}
	if (ar == 2 && av[1][0] == '-')
		use_flag_sort_linklist(&ls, av[1] + 1);
	print_ls(ls);
	closedir(dir);
}
// paipai@Guans-MacBook-Pro LS % ls -.
// ls: illegal option -- .
// usage: ls [-@ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1%] [file ...]