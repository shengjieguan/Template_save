#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <math.h>
#include "../includes/get_next_line.h"
#include "../libft/libft.h"
#include "../miniLibX/mlx.h"
#define WIN_WID 1800
#define WIN_HEI 900

typedef struct s_map
{
	double center_x;
	double center_y;
	//double c_z;
	int		x;
	int		y;
	int		num;
}				t_map;
typedef struct s_image
{
	int bpp;
	int nextian;
	int size;

}				t_image;
typedef struct s_mlx
{
	void	*mlx;
	void	*window;
	void	*img;
	char	*data;
	t_map 	*map[9999];
	int		map_width;
	int		map_height;
	int		count_point;
	int		map_num_max;
	int		map_num_min;
	t_image	*image;
}				t_mlx;



void	init(t_mlx *mlx)
{
	mlx->map_width = 0;
	mlx->map_height = -1;
	mlx->map_num_max = 0;
	mlx->map_num_min = 0;


}

void swap(double *x, double *y)
{
double temp;
temp=*x;
*x=*y;
*y=temp;
}


void				plot(t_mlx *mlx, int x, int y)
{
	int				i;
	// int				dest;
	// unsigned int	new_color;

	// if (y < 0 || x < 0)
	// 	return ;
	// new_color = mlx_get_color_value(mlx->img, 0x00FFFF);
	// dest = y * mlx->image->size + x * (mlx->image->bpp / 8);
	// i = -1;
	// while (++i < mlx->image->bpp / 8)
	// {
	// 	if (mlx->image->nextian == 0)
	// 		mlx->data[dest + i] = new_color >> (i * 8) & 0xFF;
	// 	else
	// 		mlx->data[dest + i] = new_color >> (mlx->image->bpp - (i + 1) * 8) & 0xFF;
	// }
	i = 0;
	i = (x * 4) + (y * mlx->image->size);
	mlx->data[i++] = (char)0;
	mlx->data[i++] = (char)0;
	mlx->data[i++] = (char)255;
}

void	line(t_map cur, t_map next, t_mlx *mlx)
{
	
	double	x;
	double  y;
	if(fabs((cur.center_x - next.center_x)) > fabs((cur.center_y - next.center_y)))
	{
		if (cur.center_x > next.center_x)
			line(next, cur, mlx);
		x = cur.center_x - 1;
		y = cur.center_y + ((next.center_y - cur.center_y) * (x - cur.center_x)) / (next.center_x - cur.center_x);
		while (++x < next.center_x)
			plot(mlx, x, y);
	}
	else
	{
		if (cur.center_y > next.center_y)
			line(next, cur, mlx);
		x = cur.center_y - 1;
		y = cur.center_x + ((next.center_x - cur.center_x) * (x - cur.center_y)) / (next.center_y - cur.center_y);
		printf("check = %f, %f %f\n", x, next.center_y, y);
		while (++x < next.center_y)
			plot(mlx, y, x);
	}
	// double	dx;
	// double dy;
	// double error;
	// double ystep;
	// double y;
	// double x;
	// int steep;

	// dx = fabs(next.center_x - cur.center_x);
	// dy = fabs(next.center_y - cur.center_y);
	// steep = (dy > dx ? 1 : 0);
	// if (steep)
	// {
	// 	swap(&cur.center_x, &cur.center_y);
	// 	swap(&next.center_x, &next.center_y);
	// }
	
	// dx = next.center_x - cur.center_x;
	// dy = fabs(next.center_y - cur.center_y);
	// error = dx / 2;
	// y = cur.center_y - 1;
	// x = cur.center_x - 1;
	// // printf("x = %f\n" , x);
	//  printf("next_x = %f\n" , next.center_x);
	// ystep = (next.center_y > cur.center_y ? 1 : -1);
	// while(++x <= next.center_x)
	// {
	// 	printf("x = %f %f\n" , x, y);
	// 	(steep) ? plot(mlx, y, x) : plot(mlx, x, y);
		
	// 	error -= dy;
	// 	printf("error = %f\n" , error);
	// 	if(error < 0)
	// 	{
	// 		y += ystep;
	// 		error +=dx;
	// 	}
	// }

}

// void	line(t_map *cur, t_map *next, t_mlx *mlx)
// {
// 	double	dx;
// 	double dy;
// 	double error;
// 	double ystep;
// 	double y;
// 	double x;
// 	int steep;

// 	dx = next->center_x - cur->center_x;
// 	dy = next->center_y - cur->center_y;
// 	steep = (dy > dx ? 1 : 0);
// 	if (steep)
// 	{
// 		swap(&cur->center_x, &cur->center_y);
// 		swap(&next->center_x, &next->center_y);
// 		dx = next->center_x - cur->center_x;
// 		dy = next->center_y - cur->center_y;
// 	}

// 	error = dx / 2;
// 	y = cur->center_y - 1;
// 	x = cur->center_x - 1;
// 	// printf("x = %f\n" , x);
// 	// printf("next_x = %f\n" , next->center_x);
// 	ystep = (next->center_y > cur->center_y ? 1 : -1);
// 	while(++x <= next->center_x)
// 	{
// 		(steep) ? plot(mlx, y, x) : plot(mlx, x, y);
		
// 		error -= dy;
// 		if(error < 0)
// 		{
// 			y += ystep;
// 			error +=dx;
// 		}
// 	}
	// int	x;
	// int	y;
	// int	dx;
	// int	dy;

	// y = 0;
	// x = cur->x;
	// dx = next->x - cur->x;
	// dy = next->y - cur->y;
	// while (x < next->x)
	// {
	// 	y = cur->y + dy * (x - cur->x) / dx;
	// 	plot(mlx, x, y);
	// 	x++;
	// }
//}
void	move_map_to_center(t_mlx *mlx)
{
	int i;

	i = -1;
	while(++i <= mlx->count_point)
	{
		mlx->map[i]->center_x = (WIN_WID/2 - (mlx->map_width * 20) / 2) + mlx->map[i]->x;
		mlx->map[i]->center_y = (WIN_HEI/2 - (mlx->map_height * 20) / 2) + mlx->map[i]->y - mlx->map[i]->num * 20;
		// mlx->map[i]->center_x = (double)mlx->map[i]->x;
		// mlx->map[i]->center_y = (double)mlx->map[i]->y;
		// mlx->map[i]->center_x += ((mlx->map[i]->x * 0.65 - 0.8 * mlx->map[i]->y) * 20);
		// mlx->map[i]->center_y += ((-mlx->map[i]->num * 0.04 + (0.65/ 2.0) * mlx->map[i]->x + (0.8 / 2.0) * mlx->map[i]->y) * 20);
	}

	// int i;

	// i = 0;
	// while (i < mlx->count_point)
	// {
	// 	mlx->map[i]->center_x = (mlx->map[i]->x - mlx->map[i]->y) * (mlx->map_width / 2);
	// 	//mlx->map[i]->center_x = mlx->map[i]->x * (mlx->map_width / 2);
	// 	mlx->map[i]->center_y = ((mlx->map[i]->y) * (mlx->map_height / 2))
	// 		- (mlx->map[i]->num * 20);
	// 	mlx->map[i]->center_x += (WIN_WID / 2);
	// 	mlx->map[i]->center_y += (WIN_HEI / 2);
	// 	i++;
	// }
	i = 0;
	if (i < mlx->count_point)
	{
		printf("%f %f\n", mlx->map[i]->center_x, mlx->map[i]->center_y);
		i++;
	}
}


void	draw_line(t_mlx *mlx)
{
	
	int i;

	i = 0;

	move_map_to_center(mlx);
	// printf("c1 = %f\n" , mlx->map[1]->center_x);
	// printf("c1 = %f\n" , mlx->map[1]->center_y);
	// printf("c2 = %f\n" , mlx->map[2]->center_x);
	// printf("c2= %f\n" , mlx->map[2]->center_y);
	// printf("%d %d\n", mlx->map_width, mlx->map_height);
	//printf("p2 = %f\n" , y);
	// i = -1;
	// while (++i < mlx->count_point)
	// 	printf("%f\n", mlx->map[i]->center_x);
	//printf("%d", mlx->count_point);
	printf("c1 = %f\n" , mlx->map[0]->center_x);
	printf("c3 = %f\n" , mlx->map[3]->center_x);
	// 	if(mlx->map[i]->x + 20 < mlx->map_width * 20)
	// 		line(*mlx->map[i], *mlx->map[i + 1], mlx);
	// 	if(mlx->map[i]->y < mlx->map_height * 20)
	// 		line(*mlx->map[i], *mlx->map[i + mlx->map_width], mlx);

	// i = 3;
	// 			if(mlx->map[i]->x + 20 < mlx->map_width * 20)
	// 		line(*mlx->map[i], *mlx->map[i + 1], mlx);
	// 	if(mlx->map[i]->y < mlx->map_height * 20)
	// 		line(*mlx->map[i], *mlx->map[i + mlx->map_width], mlx);
	while (i < mlx->count_point)
	{

		if(mlx->map[i]->x + 20 < mlx->map_width * 20)
			line(*mlx->map[i], *mlx->map[i + 1], mlx);
		if(mlx->map[i]->y < mlx->map_height * 20)
			line(*mlx->map[i], *mlx->map[i + mlx->map_width], mlx);			
		i++;
	}

	mlx_put_image_to_window(mlx->mlx, mlx->window, mlx->img, 0, 0);
}
t_map	*add_to_map(int num, int x, int y)
{
	t_map *map;

	if(!(map = malloc(sizeof(t_map))))
		return (NULL);
	map->x = x * 20;
	map->y = y * 20;
	map->num = num;
	//printf("%d %d\n", map->x, map->y);
	return (map);
}
int		read_file(t_mlx *mlx, int fd)
{
	char *line;
	char **s;
	int i;
	int j;

	j = -1;
	mlx->map_width = 0;
	while(get_next_line(fd, &line) == 1)
	{
		 i = -1;
		mlx->map_height++;
		if(!*(s = ft_strsplit(line, ' ')))
			return (0);
		while(s[++i])
		{
			mlx->map[++j] = add_to_map(atoi(s[i]), i, mlx->map_height);
		}
		if(mlx->map_width == 0)
			mlx->map_width = i;
		else if (mlx->map_width != 0 && mlx->map_width != i )
			return 0;
		
	}
	mlx->count_point = j;
	return (1);
}

int		main(int	ar, char **av)
{
	t_mlx	mlx;
	int fd;

	init(&mlx);
	if (ar < 2)
	{
		puts("not enough arguments");
		return (1);
	}
	fd = open(av[1], O_RDONLY);
	if(fd < 0 || !read_file(&mlx, fd))
	{
		puts("Invaild file");
		return (1);
	}
	// printf("p1 = %d\n" , mlx.map[0]->x);
	// printf("p2 = %d\n" , mlx.map[1]->x);
	// printf("p3 = %d\n" , mlx.map[2]->x);
	if (!(mlx.mlx = mlx_init())
		|| !(mlx.window = mlx_new_window(mlx.mlx, WIN_WID, WIN_HEI, "FDF"))
		|| !(mlx.image = ft_memalloc(sizeof(t_image)))
		|| !(mlx.img = mlx_new_image(mlx.mlx, WIN_WID, WIN_HEI))
		|| !(mlx.data = mlx_get_data_addr(mlx.img, &mlx.image->bpp, 
			&mlx.image->size, &mlx.image->nextian)))
		exit(EXIT_FAILURE);
	draw_line(&mlx);
	mlx_loop(mlx.mlx);
	return (0);
}

