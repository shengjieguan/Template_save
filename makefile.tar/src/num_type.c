#include "../includes/ft_printf.h"

void    print_pad(int padded_len, t_tab *arg, char c)
{
    int    i;

    i = 0;
    while (i < padded_len)
    {
	write (1, &c, 1);
        arg->len++;
        i++;
    }
}

int		ft_countnbr_unsigned(uintmax_t i, int base)
{
	int n;

	n = 1;
	if (!n && n != 0)
	{
		n++;
		i *= -1;
	}
	while(i > 9)
	{
		i /= base;
		n++;
	}
	return n;
}

void	ft_putnbr_unsigned(uintmax_t n, int base)
{
	uintmax_t tmp;

	tmp = (uintmax_t)n;
	if (!n && n != 0)
	//if (n < 0)
	{
		ft_putchar('-');
		tmp *= -1;
	}
	if (tmp > 9)
		ft_putnbr_unsigned(tmp / base, base);
	ft_putchar(tmp % base + '0');
}

void	num_uintmax_t(uintmax_t num, t_tab *arg)
{
	if (arg->length == NULL)
		(num = (unsigned int)num);
	else if (!ft_strcmp(arg->length, "h"))
		num = (unsigned short)num;
	else if (!ft_strcmp(arg->length, "hh"))
		num = (unsigned char)num;
	else if (!ft_strcmp(arg->length, "l"))
		num = (unsigned long)num;
	else if (!ft_strcmp(arg->length, "ll") ||
			ft_strcmp(arg->length, "z"))
		num = (unsigned long long)num;
}

intmax_t	num_intmax_t(intmax_t num, t_tab *arg, va_list ap)
{
	if (arg->length == NULL)
		num = va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "h"))
		num = (short)va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "hh"))
		num = (signed char)va_arg(ap, int);
	else if (!ft_strcmp(arg->length, "l"))
		num = va_arg(ap, long);
	else if (!ft_strcmp(arg->length, "ll"))
		num = va_arg(ap, long long);
	else if (!ft_strcmp(arg->length, "z"))
		num = va_arg(ap, size_t);
	return (num);

}

int		ft_countnbr_signed(intmax_t i, int base)
{
	int n = 1;
	if(i < 0)
	{
		n++;
		i *= -1;
	}
	while(i > 9)
	{
		i /= base;
		n++;
	}
	return n;
}

void	ft_putnbr_signed(intmax_t n, int base)
{
	if (n < 0)
	{
		write(1, "-", 1);
		n *= -1;
	}
	if (n > 9)
		ft_putnbr_signed(n / 10, base);
	ft_putchar(n % 10 + '0');
}

char    *ft_itoa_base(uintmax_t value, uintmax_t base, char c)
{
    size_t    i;
    size_t    len;
    int        sign;
    char    tmp[130];
    char    *ret;

    len = 0;
    sign = (!value ? -1 : 1);
	//sign = (value < 0 ? -1 : 1);
    if (value == 0)
        tmp[len++] = '0';
    while (value)
    {
		if(c == 'x' || c == 'p')
        	tmp[len++] = HEX[value % base * sign];
		if(c == 'X')
			tmp[len++] = HEX_BIG[value % base * sign];
        value /= base;
    }
    if (sign == -1 && base == 10)
        tmp[len++] = '-';
    if (!(ret = (char*)malloc(sizeof(char) * (len + 1))))
        return (NULL);
    ret[len] = 0;
    i = -1;
    while (++i < len)
        ret[i] = tmp[len - 1 - i];
    return (ret);
}
