#include "../includes/ft_printf.h"
intmax_t	print_width_nb(t_tab *arg, intmax_t num, char c)
{

		if(num < 0 && !arg->pres && arg->flag_zero)
			write(1, "-", 1) && (num *= -1);
		(arg->flag_plus && num >= 0) && arg->width_nb--;
		print_pad(arg->width_nb, arg, c);
		return (num);
}

int		print_d(t_tab *arg, va_list ap)
{
	int arg_len;
	intmax_t	num;
	char c;
	
	num = 0;
	c = (arg->flag_zero ? '0' : ' ');
	(arg->flag_zero && arg->flag_plus) && (c = ' ');
	num = num_intmax_t(num, arg, ap);
	arg_len = ft_countnbr_signed(num, 10);
	if (arg->flag_space == 1 && !arg->flag_minus && !arg->flag_plus && num >= 0)
		(write(1, " ", 1)) && arg->width_nb-- && arg->len++;
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	(arg->flag_plus && num >= 0 && !arg->pres) && write(1, "+", 1);
	if(arg->width_nb > 0 && !arg->flag_minus)
		num = print_width_nb(arg, num, c);
	if(arg->pres_nb > 0)
	{
		(arg->flag_plus && num >= 0) && (write(1, "+", 1));
		if(num < 0)
			write(1, "-", 1) && (num *= -1) && arg->pres_nb++;
		print_pad(arg->pres_nb - arg_len, arg, '0');
	}
	ft_putnbr_signed(num, 10);	
	if(arg->width_nb > 0 && arg->flag_minus)
		num = print_width_nb(arg, num, c);
	(arg->width_nb > 0) && (arg->len += arg->width_nb);
	arg->len += (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	return (arg->len);
}
