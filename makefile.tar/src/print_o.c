#include "../includes/ft_printf.h"

int		print_o(t_tab *arg, va_list ap)
{
	int arg_len;
	uintmax_t	num;
	char c;
	
	c = (arg->flag_zero ? '0' : ' ');
	num = va_arg(ap, uintmax_t);
	num_uintmax_t(num, arg);
	arg_len = ft_countnbr_unsigned(num, 8);
	(arg->flag_hash && num != 0) && arg->width_nb--;
	(arg->pres) && (c = ' ');
	if (!arg->flag_hash && arg->pres_nb < 1 && arg->pres && !num && !arg->width_nb)
	{	write(1, "", 1);
		return (1);
	}
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	if(arg->width_nb > 0 && !arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	if (arg->pres_nb > 0)
		print_pad(arg->pres_nb - arg_len, arg, '0');
	if(arg->flag_hash && num != 0 && arg->pres_nb <= arg_len)
		write(1, "0", 1) && arg->len++;
	ft_putnbr_unsigned(num, 8);
	if(arg->width_nb > 0 && arg->flag_minus)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}
