#include "../includes/ft_printf.h"

void	display(t_tab *arg, char c, char *str)
{
	int n;

	n = arg->width_nb - strlen(str);
	if(n > 0)
	{
		arg->len += n;
		while(n-->0)
			write(1, &c, 1);
	}
}

int	print_s(t_tab *arg, va_list ap)
{
	char	*str;
	char	c;
	int		arg_len;

	str = va_arg(ap, char *);
	c = (arg->flag_zero == 1 ? '0' : ' ');
	if(!str)
		str = "(null)";
	arg_len = ft_strlen(str);
	arg->width_nb -= (arg->pres_nb > arg_len ? arg_len : arg->pres_nb);
	if(!arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);
	if(arg->pres == 1 && arg->pres_nb)
		(arg->pres_nb - arg_len > 0) ? write(1, str, arg_len) : write(1, str, arg->pres_nb);
	if(arg->pres == 1 && !arg->pres_nb)
		write(1, "", 1);
	if(arg->pres != 1)
		write(1, str, arg_len);
	if (arg->flag_minus == 1  && arg->width_nb)
		print_pad(arg->width_nb, arg, ' ');
	arg->len += arg_len;
	return (arg->len);
}
