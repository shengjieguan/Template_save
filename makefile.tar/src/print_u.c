#include "../includes/ft_printf.h"

int		print_u(t_tab *arg, va_list ap)
{
	int arg_len;
	intmax_t	num;
	char c;

	c = (arg->flag_zero == 1 ? '0' : ' ');
	num = va_arg(ap, uintmax_t);
	num_uintmax_t(num, arg);
	arg_len = ft_countnbr_unsigned(num, 10);
	(arg->pres == 1) && (c = ' ');
	if ((arg->pres == 1 && arg->pres_nb < 1) && num == 0)
	{	
		write(1, "", 1);
		return (1);
	}
	arg->pres_nb > arg_len ? (arg->width_nb -= arg->pres_nb) : (arg->width_nb -= arg_len);
	if(arg->width_nb > 0 && arg->flag_minus == 0)
		print_pad(arg->width_nb, arg, c);
	if(arg->pres_nb > 0)
		print_pad(arg->pres_nb - arg_len, arg, '0');
	ft_putnbr_unsigned(num, 10);
	if(arg->width_nb > 0 && arg->flag_minus == 1)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}
