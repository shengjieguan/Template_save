#include "ft_printf.h"
int	ft_isdigit(int c)
{
	return (c > 47 && c < 58);
}
