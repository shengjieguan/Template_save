#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "ft_printf.h"
//typedef struct s_tab
//{
//	int	flag_hash;
//	int	flag_zero;
//	int	flag_minus;
//	int	flag_space;
//	int	flag_plus;
//	int	pres;
//	int	pres_nb;
//	int	width;
//	int	width_nb;
//	char	*length;
//}//		t_tab;

int	ft_handler(char **format, va_list ap, t_tab *arg)
{
	if (**format == 's' || **format == 'S')
//		return (print_s(bag, args, i));

		return (101);
	else if (**format == 'p')
//		return (print_p(bag, args, i));
		return (102);
	else if (**format == 'd' || **format == 'D' || **format == 'i')
//		return (print_d(bag, args, i));
		return (103);
	else if (**format == 'o' || **format == 'O')
//		return (print_o(bag, args, i));
		return (104);
	else if (**format == 'u' || **format == 'U')
//		return (print_u(bag, args, i));
		return (105);
	else if (**format == 'x' || **format == 'X')
//		return (print_x(bag, args, i));
		return (106);
	else if (**format == 'c' || **format == 'C')
//		return (print_c(bag, args, i));
		return (107);
	else if (**format == '%')
//		return (print_percent(bag, args, i));
		return (108);
	return (0);
}

char	*ft_pres(char **format, t_tab *arg, va_list ap)
{
	int	i;
	if(**format == '.')
	{
		format++;
		arg->pres = 1;
		if(**format == '*')
		{
			if((i = va_arg(ap, int)) >= 0)
				arg->pres_nb = i;
			else
			{
				arg->pres = 0;
				arg->width = 1;
				arg->width_nb = -i;
			}
			format++;
		}
		else if(ft_isdigit(**format))
		{
			while(ft_isdigit(**format))
				arg->pres_nb = arg->pres_nb * 10 + *(*format)++ - '0';
		}
	}
	return (*format);
}
char	*ft_length(char **format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if(**format == 'h' && *(*format + 1) == 'h')
	{
		arg->length = "hh";
		return (*format += 2);
	}
	else if(**format == 'l' && *(*format + 1) == 'l')
	{
		arg->length = "ll";
		return (*format += 2);
	}
	else if (ft_strchr(s, **format) != NULL)
	{
		if (**format == 'h')
			arg->length = "h";
		else if (**format == 'l')
			arg->length = "l";
		else if (**format == 'j')
			arg->length = "j";
		else if (**format == 'z')
			arg->length = "z";
		return ((*format)++);
	}
	else
		return (*format);
}
	
char	*ft_width(char **format, t_tab *arg, va_list ap)
{
	int i;
	arg->width_nb = 0;
	while(**format == '*' || ft_isdigit(**format))
	{
		arg->width = 1;
		if(**format == '*')
		{
			if (i == va_arg(ap, int) < 0)
			{
				arg->flag_minus = 1;
				arg->width_nb = -i;
			}
			else
				arg->width_nb = i;
			format++;
		}
		else if(ft_isdigit(**format))
		{
			while (ft_isdigit(**format))
				arg->width_nb = arg->width_nb *10 + *(*format)++ - '0';
		}
	}
	return (*format);
}


char	*ft_flag(char **format, t_tab *arg)
{
	while (**format == '#' || **format == '0' || **format == '-' ||
			**format == ' ' || **format == '+')
	{
		(**format == '#') && (arg->flag_hash = 1);
		(**format == '0') && (arg->flag_zero = 1);
		(**format == '-') && (arg->flag_minus = 1);
		(**format == ' ') && (arg->flag_space = 1);
		(**format == '+') && (arg->flag_plus = 1);
		(arg->flag_minus) && (arg->flag_zero = 0);
		(arg->flag_plus) && (arg->flag_space = 0);
		format++;
	}
	return (*format);
}
int	solve_arg(char **format, va_list ap)
{
	int nb;
	char *s;
	t_tab	*arg;

	s = "sSpdDioOuUxXcC%";
	nb = 0;
	format++;
	arg = malloc(sizeof(t_tab));
	if(!(**format))
		return (0);
	while(**format)
	{
		if(ft_flag(format, arg) == NULL)
			return (-1);
		if(ft_width(format, arg, ap) == NULL)
			return (-1);
		if(ft_pres(format, arg, ap) == NULL)
			return (-1);
		if(ft_length(format, arg) == NULL)
			return (-1);
		if(ft_strchr(s, **format) == NULL)
			return (-1);
		if(nb == ft_handler(format, ap, arg) >= 0)
			break;
	}
	return (nb);
}

int	ft_printf(const char *format, ...)
{
	va_list	ap;
	int	len;
	int	arg_len;
	
	len = 0;
	va_start(ap, format);
	while(*format)
	{
		if(*format == '%')
		{
			if((arg_len = solve_arg((char**)&format, ap)) == -1)
				return (-1);
			len += arg_len;
			format += arg_len;
		}
		else if(*format != '%')
		{
			write(1, format, 1);
			len++;
			format++;
		}
	}
	va_end(ap);
	return (len);
}
