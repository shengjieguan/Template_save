#include "ft_printf.h"
int	ft_handler(char *format, va_list ap, t_tab *arg)
{
	if (*format == 's' || *format == 'S')
		return (101);
	else if (*format == 'p')
		return (102);
	else if (*format == 'd' || *format == 'D' || *format == 'i')
		return (103);
	else if (*format == 'o' || *format == 'O')
		return (104);
	else if (*format == 'u' || *format == 'U')
		return (105);
	else if (*format == 'x' || *format == 'X')
		return (106);
	else if (*format == 'c' || *format == 'C')
		return (107);
	return (-1);
}
char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if(*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{

		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if(ft_strchr(s, *format))
	{
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'h') && (arg->length = "j");
		(*format == 'l') && (arg->length = "t");
		(*format == 'h') && (arg->length = "z");
		(*format == 'l') && (arg->length = "q");
		return(format + 1);
	}
	return (format);

}
char	*ft_pres(char *format, t_tab *arg, va_list ap)
{
	arg->pres_nb = 0;
	if(*format == '.')
	{
		format++;
		while(ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width(char *format, t_tab *arg, va_list ap)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb *10 + *format++ - '0';
	return (format);
}
char    *ft_flag(char *format, t_tab *arg)
{

    while (*format == '#' || *format == '0' || *format == '-' || *format == ' ' || *format == '+')
    {
        (*format == '0') && (arg->flag_zero = 1);
        (*format == '-') && (arg->flag_minus = 1);
        (*format == ' ') && (arg->flag_space = 1);
        (*format == '+') && (arg->flag_plus = 1);
        (arg->flag_minus) && (arg->flag_zero = 0);
        (arg->flag_plus) && (arg->flag_space = 0);
        format++;
    }
    return (format);
}
void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = 0;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}

int    ft_printf(const char *format, ...)
{
    va_list    ap;
    t_tab    *arg;
    
    arg = malloc(sizeof(t_tab));
    arg->len = 0;
    va_start(ap, format);
    while(*format)
    {
        if(*format == '%')
        {
		init_arg(arg);
            (arg->format = (char *)format) && format++;
		if(!*format)
			return (-1);
		if((format = ft_flag((char *)format, arg)) == NULL)
	          return (-1);
               	if((format = ft_width((char *)format, arg, ap)) == NULL)
        	       return (-1);
   	        if((format = ft_pres((char *)format, arg, ap)) == NULL)
                	return (-1);
	              if((format = ft_length((char *)format, arg)) == NULL)
        	          return (-1);
		if((ft_handler((char *)format, ap, arg)) == -1)
                  (write(1, "%", 1)) && (format = arg->format);
      	}
      else if(*format != '%')
            (write(1, format, 1)) && (arg->len++);
	format++;
    }
    va_end(ap);
    return (arg->len);
}
