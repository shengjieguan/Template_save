#ifndef FT_PRINTF_H
#define FT_PRINTF_H

typedef struct s_tab
{
	int	flag_hash;
	int	flag_zero;
	int	flag_minus;
	int	flag_space;
	int	flag_plus;
	int	pres;
	int	pres_nb;
	int	width;
	int	width_nb;
	char	*length;
}		t_tab;

int	ft_printf(const char *format, ...);
char	*ft_strchr(const char *s, int c);
int	ft_isdigit(int c);
#endif
