#include "ft_printf.h"
int main()
{
	ft_printf("%s", "adf%%");
	return (0);
}
