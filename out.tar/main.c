#include "ft_printf.h"
int main()
{
	ft_printf("%d", ft_printf("adf%%"));
	return (0);
}
