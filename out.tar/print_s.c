#include "ft_printf.h"
void	display(t_tab *arg, char c, char *str)
{
	int n;

	n = arg->width_nb - ft_strlen(str);
	if(n > 0)
	{
		arg->len += n;
		while(n-->0)
			write(1, &c, 1);
	}
}

int	print_s(t_tab *arg, va_list ap)
{
	char	*str;
	char	c;
	
	str = va_arg(ap, char *);
	if(!str)
		str = "(null)";
	if(arg->flag_minus != 1)
	{
		c = (arg->flag_zero == 1 ? '0' : ' ');
		display(arg, c, str);
	}
	if(arg->pres == 1)
		(arg->pres_nb >= 0) ? write(1, str, arg->pres_nb) : write(1, "", 1);
	if(arg->pres != 1)
		write(1, str, ft_strlen(str));
	if (arg->flag_minus == 1)
		(display(arg, ' ', str));
	arg->len += ft_strlen(str);
	return (0);
}
