/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_and_validate.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skoh <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/23 11:49:20 by skoh              #+#    #+#             */
/*   Updated: 2019/10/24 13:49:22 by skoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/fillit.h"

char	*match(char *arr)
{
	char *tetri_str;

	tetri_str = NULL;
	(ft_strcmp(arr, SHAPE_1) == 0) && (tetri_str = "00103020");
	(ft_strcmp(arr, SHAPE_2) == 0) && (tetri_str = "00010203");
	(ft_strcmp(arr, SHAPE_3) == 0) && (tetri_str = "00101101");
	(ft_strcmp(arr, SHAPE_4) == 0) && (tetri_str = "00011112");
	(ft_strcmp(arr, SHAPE_5) == 0) && (tetri_str = "10012011");
	(ft_strcmp(arr, SHAPE_6) == 0) && (tetri_str = "10011102");
	(ft_strcmp(arr, SHAPE_7) == 0) && (tetri_str = "00102111");
	(ft_strcmp(arr, SHAPE_8) == 0) && (tetri_str = "10012111");
	(ft_strcmp(arr, SHAPE_9) == 0) && (tetri_str = "00102011");
	(ft_strcmp(arr, SHAPE_10) == 0) && (tetri_str = "00011102");
	(ft_strcmp(arr, SHAPE_11) == 0) && (tetri_str = "10011112");
	(ft_strcmp(arr, SHAPE_12) == 0) && (tetri_str = "00011002");
	(ft_strcmp(arr, SHAPE_13) == 0) && (tetri_str = "00102021");
	(ft_strcmp(arr, SHAPE_14) == 0) && (tetri_str = "10021112");
	(ft_strcmp(arr, SHAPE_15) == 0) && (tetri_str = "00012111");
	(ft_strcmp(arr, SHAPE_16) == 0) && (tetri_str = "00101112");
	(ft_strcmp(arr, SHAPE_17) == 0) && (tetri_str = "00102001");
	(ft_strcmp(arr, SHAPE_18) == 0) && (tetri_str = "00011202");
	(ft_strcmp(arr, SHAPE_19) == 0) && (tetri_str = "20012111");
	if (tetri_str == NULL)
	{
		ft_putstr("invalid shape\n");
		return (NULL);
	}
	return (tetri_str);
}

char	*valid_shape(char *buf)
{
	int		ctr1;
	int		ctr2;
	char	tmp[20];
	char	*arr;
	char	*valid;

	ctr1 = 0;
	ctr2 = 0;
	while (ctr1 < 19)
	{
		if (buf[ctr1] == '#' || buf[ctr1] == '.')
		{
			tmp[ctr2] = buf[ctr1];
			ctr2++;
		}
		ctr1++;
	}
	tmp[ctr2] = '\0';
	arr = trim_dots(tmp);
	valid = match(arr);
	free(arr);
	return (valid);
}

int		char_check(char *buf)
{
	int		ctr;
	int		hash_count;

	ctr = 0;
	hash_count = 0;
	while (ctr < 19)
	{
		if (buf[ctr] != '#' & buf[ctr] != '.' && buf[ctr] != '\n')
			return (0);
		if (buf[ctr] == '#')
			hash_count++;
		ctr++;
	}
	if (buf[ctr] != '\n' && hash_count != 4)
		return (0);
	return (1);
}

int		build_valid_tetri(int ret, char *buf)
{
	char	**tetri_arr;
	int		ctr;
	int		ctr2;
	int		tetri_count;

	tetri_count = (ret + 1) / 21;
	tetri_arr = (char **)(malloc(sizeof(char *) * tetri_count));
	ctr = 0;
	ctr2 = 0;
	while (ctr < ret)
	{
		if (char_check(&buf[ctr]) == 0)
			return (0);
		if ((tetri_arr[ctr2] = valid_shape(&buf[ctr])) == NULL)
			return (0);
		ctr += 21;
		ctr2++;
	}
	solve(tetri_arr, tetri_count);
	free(tetri_arr);
	return (1);
}

int		file_is_valid(int fd)
{
	if (fd < 0 || fd > OPEN_MAX)
		return (0);
	return (1);
}

int		parse_file(int fd)
{
	int		ret;
	char	buf[545];

	if (file_is_valid(fd) == 0)
		return (0);
	ret = read(fd, buf, 545);
	buf[ret] = '\0';
	close(fd);
	if ((ret < 19 || ret > 544) || (ret + 1) % 21 != 0)
		return (0);
	if (build_valid_tetri(ret, buf) == 0)
		return (0);
	return (1);
}
