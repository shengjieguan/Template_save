/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skoh <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/24 13:22:44 by skoh              #+#    #+#             */
/*   Updated: 2019/10/24 14:22:49 by skoh             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/fillit.h"
#include <stdio.h>
int	overlap(char map[16][16], char *tetri_arr, int a, int b)
{
	int i;
	int x;
	int y;

	i = 0;
	x = tetri_arr[i] + a - 48;
	y = tetri_arr[i + 1] + b - 48;

	while(i <= 7 && map[y][x] == '.')
	{
//		printf("i_x_y=%d %d %d", i, x, y);
		i += 2;
		x = tetri_arr[i] + a - 48;
		y = tetri_arr[i + 1] + b - 48;
	}
	return(i);
}

void	place(char *tetri_arr, char map[16][16], char character, int a, int b)
{
	int i;
	int x;
	int y;

	i = 0;
	x = tetri_arr[i] + a - 48;
	y = tetri_arr[i + 1] + b - 48;
	while (i <= 6)
	{	
		x = tetri_arr[i] + a - 48;
		y = tetri_arr[i + 1] + b - 48;
		map[y][x] = character;
		i += 2;
	}
}

int		x_bounds(char *tetri_arr, int size, int x)
{
	return (tetri_arr[0] + x -48 < size &&
				tetri_arr[2] + x - 48 < size &&
				tetri_arr[4] + x - 48< size &&
				tetri_arr[6] + x - 48< size);
}

int		y_bounds(char *tetri_arr, int size, int y)
{
	return (tetri_arr[1] + y - 48< size &&
				tetri_arr[3] + y - 48< size &&
				tetri_arr[5] + y - 48< size &&
				tetri_arr[7] + y - 48< size);
}

int recursion(char **tetri_arr, char map[16][16], int size, char *character)
{
	int x;
	int y;
	int i;

	i = 0;
	x = 0;
	y = 0;

	while(y_bounds(tetri_arr[i], size, y))
	{
		x = 0;
		while(x_bounds(tetri_arr[i], size, x))
		{
			if(overlap(map, tetri_arr[i], x, y) == 8)
			{
				place(tetri_arr[i], map, character[i], x, y);

				print_map(map, size);
				if (recursion(&tetri_arr[i + 1], map, size, &character[i + 1]) == 1)
					return (1);
				else
				{
					place(tetri_arr[i], map, '.', x, y);
					print_map(map, size);
				}
			}
			x++;
		}
		y++;
	}
	return (0);
}

void	set_board(int size, char map[16][16])
{
	int x;
	int y;

	y = -1;
	while(++y < size)
	{
		x = -1;
		while(++x < size)
			map[y][x] = '.';
	}
}

void	solve(char **tetri_arr, int tetri_count)
{
	char map[16][16];
	int size;
	char *character;

	character = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	size = 2;
	while(size * size < tetri_count * 4)
		size++;
	set_board(size, map);

	while(recursion(tetri_arr, map, size, character) == 0)
	{
		puts("se");
		size++;
		set_board(size, map);
	}
	print_map(map, size);
}
