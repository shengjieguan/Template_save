#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#define HEX "0123456789abcdef"
# define MAX(x, y) x > y ? x : y
# define MIN(x, y) x < y ? x : y

typedef struct s_tab
{
    int    flag_hash;
    int    flag_zero;
    int    flag_minus;
    int    flag_space;
    int    flag_plus;
    int    pres;
    int    pres_nb;
    int    width;
    int    width_nb;
    char    *length;
    int     len;
    char *format;
}        t_tab;

void    print_pad(int padded_len, t_tab *arg, char c)
{
    int    i;

    i = 0;
    while (i < padded_len)
    {
        putchar(c);
        arg->len++;
        i++;
    }
}
void    output2(char *address_str, t_tab *arg, int arg_len)
{
    uintmax_t    pad_space_nb;
    uintmax_t    pad_zero_nb;

    pad_space_nb = arg->width_nb - arg_len - 2;
    pad_zero_nb = arg->pres_nb - arg_len;
	(pad_space_nb < 0) && (pad_space_nb = 0);
	(pad_zero_nb < 0) && (pad_zero_nb = 0);
    write(1, "0x", 2) && (arg->len += 2);
    if (pad_space_nb > 0 || pad_zero_nb > 0)
    {
        if (pad_zero_nb >= pad_space_nb)
        {
            print_pad(pad_zero_nb, arg, '0');
            puts(address_str);
        }
        if (pad_zero_nb < pad_space_nb)
        {
            print_pad(pad_zero_nb, arg, '0');
            puts(address_str);
            print_pad(pad_space_nb - pad_zero_nb, arg, ' ');
        }
    }
    else
        puts(address_str);
}

void    output1(char *address_str, t_tab *arg, int arg_len)
{
    uintmax_t    pad_space_nb;
    uintmax_t    pad_zero_nb;

    pad_space_nb = arg->width_nb - arg_len - 2;
    pad_zero_nb = arg->pres_nb - arg_len;
	(pad_space_nb < 0) && (pad_space_nb = 0);
	(pad_zero_nb < 0) && (pad_zero_nb = 0);
    if (pad_space_nb > 0 || pad_zero_nb > 0)
    {
        if (pad_zero_nb >= pad_space_nb)
        {
            write(1, "0x", 2) && (arg->len += 2);
            print_pad(pad_zero_nb, arg, '0');
        }
        if (pad_zero_nb < pad_space_nb)
        {
            print_pad(pad_space_nb - pad_zero_nb, arg, ' ');
            write(1, "0x", 2) && (arg->len += 2);
            print_pad(pad_zero_nb, arg, '0');
        }
    }
    else
        write(1, "0x", 2) && (arg->len += 2);
    puts(address_str);
}
char	*ft_itoa_base(uintmax_t value, uintmax_t base)
{
	size_t	i;
	size_t	len;
	uintmax_t		sign;
	char	tmp[130];
	char	*ret;

	len = 0;
	sign = (value < 0 ? -1 : 1);
	if (value == 0)
		tmp[len++] = '0';
	while (value)
	{
		tmp[len++] = HEX[value % base * sign];
		value /= base;
	}
	if (sign == -1 && base == 10)
		tmp[len++] = '-';
	if (!(ret = (char*)malloc(sizeof(char) * (len + 1))))
		return (NULL);
	ret[len] = 0;
	i = -1;
	while (++i < len)
		ret[i] = tmp[len - 1 - i];
	return (ret);
}

int		print_p(t_tab *arg, va_list ap)
{
	uintmax_t	nb;
	int			i;
	char *str;
	nb = (uintmax_t)va_arg(ap, void*);
	str = ft_itoa_base(nb, 16);
	i = strlen(str);
	if(arg->flag_minus == 0)
	{
		
		if(arg->width_nb > arg->pres_nb)
		{
			print_pad(arg->width_nb - i - arg->pres_nb, arg, ' ');
			
		}
		write(1, "0x", 2) && (arg->width_nb -= 2);
		puts(str);
	}
	return (arg->len);
}
char	*ft_strchr(const char *s, int c)
{
	while (*s && *s != c)
		s++;
	while (!*s && c)
		return (0);
	return ((char *)s);
}
char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if (*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{
		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if (ft_strchr(s, *format))
	{
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'h') && (arg->length = "j");
		(*format == 'l') && (arg->length = "t");
		(*format == 'h') && (arg->length = "z");
		(*format == 'l') && (arg->length = "q");
		return (format + 1);
	}
	return (format);

}
int	ft_isdigit(int c)
{
	return (c > 47 && c < 58);
}
char	*ft_pres(char *format, t_tab *arg, va_list ap)
{
	if(*format == '.')
	{
		format++;
		arg->pres = 1;
		if(ft_isdigit(*format))
			arg->pres_nb = 0;
		while(ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width(char *format, t_tab *arg, va_list ap)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb *10 + *format++ - '0';
	return (format);
}
char    *ft_flag(char *format, t_tab *arg)
{
	while (*format == '#' || *format == '0' || *format == '-' || *format == ' ' || *format == '+')
	{
	(*format == '0') && (arg->flag_zero = 1);
	(*format == '-') && (arg->flag_minus = 1);
	(*format == ' ') && (arg->flag_space = 1);
	(*format == '+') && (arg->flag_plus = 1);
	(arg->flag_minus) && (arg->flag_zero = 0);
	(arg->flag_plus) && (arg->flag_space = 0);
	format++;
	}
	return (format);
}
void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}
char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;
	s = "sSdDioOuUxXcCp";
	format = ft_flag(format, arg);
	format = ft_width(format, arg, ap);
	format = ft_pres(format, arg, ap);
	format = ft_length(format, arg);
	if (ft_strchr(s, *format) == NULL)
		(write(1, "%", 1)) && (format = arg->format);
	(*format == 's' || *format == 'S') && (print_p(arg, ap));
	(*format == 'p') && (print_p(arg, ap));
	(*format == 'd' || *format == 'D' || *format == 'i') && (print_p(arg, ap));
	(*format == 'o' || *format == 'O') && (print_p(arg, ap));
	(*format == 'u' || *format == 'U') && (print_p(arg, ap));
	(*format == 'x' || *format == 'X') && (print_p(arg, ap));
	(*format == 'c' || *format == 'C') && (print_p(arg, ap));
	return (format);
}
int    ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%')
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if(*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	return (arg->len);
}
int main()
{
	int	a = 10;
	
	ft_printf("%p\n", NULL);
	printf("%p\n\n", NULL);

	ft_printf("%p\n", &a);
	printf("%p\n\n", &a);

	ft_printf("%20p", &a);
	printf("%20p", &a);
	return (0);
}

