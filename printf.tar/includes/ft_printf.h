
#ifndef FT_PRINTF_H
#define FT_PRINTF_H
#include "../src/libft/libft.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#define HEX "0123456789abcdef"
#define HEX_BIG "0123456789ABCDEF"
typedef struct s_tab
{
    int    flag_hash;
    int    flag_zero;
    int    flag_minus;
    int    flag_space;
    int    flag_plus;
    int    pres;
    int    pres_nb;
    int    width;
    int    width_nb;
    char    *length;
    int     len;
    char *format;
}        t_tab;

char	*ft_length(char *format, t_tab *arg);
char	*ft_pres(char *format, t_tab *arg, va_list ap);
char	*ft_width(char *format, t_tab *arg, va_list ap);
char    *ft_flag(char *format, t_tab *arg);
void	init_arg(t_tab *arg);
char	*check_format(char *format, t_tab *arg, va_list ap);
int     ft_printf(const char *format, ...);
int     print_d(t_tab *arg, va_list ap);
int     print_s(t_tab *arg, va_list ap);
int     print_u(t_tab *arg, va_list ap);
int     print_p(t_tab *arg, va_list ap);
int     print_x(t_tab *arg, va_list ap, char c);
int     print_o(t_tab *arg, va_list ap);
int		print_c(t_tab *arg, va_list ap);
int		print_percentage(t_tab *arg);
uintmax_t	num_uintmax_t(t_tab *arg, va_list ap);
intmax_t	num_intmax_t(t_tab *arg, va_list ap);
void	ft_putnbr_unsigned(uintmax_t n, int base);
void	ft_putnbr_signed(intmax_t n, int base);
int		ft_countnbr_unsigned(uintmax_t i, int base);
int		ft_countnbr_signed(intmax_t i, int base);
char    *ft_itoa_base(uintmax_t value, uintmax_t base, char c);
void    print_pad(int padded_len, t_tab *arg, char c);

#endif
