# define MAX(x, y) x > y ? x : y
# define MIN(x, y) x < y ? x : y
#define HEX "0123456789ABCDEF"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
typedef struct s_tab
{
    int    flag_hash;
    int    flag_zero;
    int    flag_minus;
    int    flag_space;
    int    flag_plus;
    int    pres;
    int    pres_nb;
    int    width;
    int    width_nb;
    char    *length;
    int     len;
    char *format;
}        t_tab;

char    *ft_itoa_base(uintmax_t value, uintmax_t base)
{
    size_t    i;
    size_t    len;
    uintmax_t        sign;
    char    tmp[130];
    char    *ret;

    len = 0;
    sign = (value < 0 ? -1 : 1);
    if (value == 0)
        tmp[len++] = '0';
    while (value)
    {
        tmp[len++] = HEX[value % base * sign];
        value /= base;
    }
    if (sign == -1 && base == 10)
        tmp[len++] = '-';
    if (!(ret = (char*)malloc(sizeof(char) * (len + 1))))
        return (NULL);
    ret[len] = 0;
    i = -1;
    while (++i < len)
        ret[i] = tmp[len - 1 - i];
    return (ret);
}

void    ptr_output2(char *address_str, t_tab *arg, int arg_len)
{
    uintmax_t    pad_space_nb;
    uintmax_t    pad_zero_nb;

    pad_space_nb = MAX(arg->width_nb - arg_len - 2, 0);
    pad_zero_nb = MAX(arg->pres_nb - arg_len, 0);
    print_hex_flag_hash(arg);
    if (pad_space_nb > 0 || pad_zero_nb > 0)
    {
        if (pad_zero_nb >= pad_space_nb)
        {
            print_padded_char(pad_zero_nb, arg, '0');
            putstr(address_str);
        }
        if (pad_zero_nb < pad_space_nb)
        {
            print_padded_char(pad_zero_nb, arg, '0');
            putstr(address_str);
            print_padded_char(pad_space_nb - pad_zero_nb, arg, ' ');
        }
    }
    else
        putstr(address_str);
}
void    ptr_output1(char *address_str, t_tab *arg, int arg_len)
{
    uintmax_t    pad_space_nb;
    uintmax_t    pad_zero_nb;

    pad_space_nb = MAX(arg->width_nb - arg_len - 2, 0);
    pad_zero_nb = MAX(arg->pres_nb - arg_len, 0);
    if (pad_space_nb > 0 || pad_zero_nb > 0)
    {
        if (pad_zero_nb >= pad_space_nb)
        {
            print_hex_flag_hash(arg);
            print_padded_char(pad_zero_nb, arg, '0');
        }
        if (pad_zero_nb < pad_space_nb)
        {
            print_padded_char(pad_space_nb - pad_zero_nb, arg, ' ');
            print_hex_flag_hash(arg);
            print_padded_char(pad_zero_nb, arg, '0');
        }
    }
    else
        print_hex_flag_hash(arg);
    putstr(address_str);
}
int        handle_ptr(va_list ap, t_tab *arg)
{
    uintmax_t    arg_address_nb;
    char        *address_str;
    int            arg_len;

    arg_address_nb = (uintmax_t)va_arg(ap, void*);
    address_str = ft_itoa_base(arg_address_nb, 16);
    arg_len = strlen(address_str);
    arg->len += arg_len;
    if (arg->flag_minus == 0)
        ptr_output1(address_str, arg, arg_len);
    if (arg->flag_minus == 1)
        ptr_output2(address_str, arg, arg_len);
    free(address_str);
    return (arg->len);
}

void    init_arg(t_tab *arg)
{
    arg->flag_hash = 0;
    arg->flag_zero = 0;
    arg->flag_minus = 0;
    arg->flag_space = 0;
    arg->flag_plus = 0;
    arg->pres = 0;
    arg->pres_nb = -1;
    arg->width = 0;
    arg->width_nb = 0;
    arg->length = NULL;
}
int    ft_printf(const char *format, ...)
{
    va_list    ap;
    t_tab    *arg;

    arg = malloc(sizeof(t_tab));
    arg->len = 0;
    va_start(ap, format);
    while (*format)
    {
        if (*format == '%')
        {
            handle_ptr(ap, arg);
        }
        else if(*format != '%')
            (write(1, format, 1)) && (arg->len++);
        format++;
    }
    va_end(ap);
    return (arg->len);
}

int main()
{
  ft_printf("%p", NULL);
  printf("%p", NULL);
  return 0;
}
