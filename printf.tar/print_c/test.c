int main()
{
	ft_printf("%c\n", 'a');
	printf("%c\n\n", 'a');

	ft_printf("%c\n", '\0');
	printf("%c\n\n", '\0');
	
	ft_printf("%c\n", (char)0xff11ff11);
	printf("%c\n\n", (char)0xff11ff11);

	ft_printf("%c\n", -21);
	printf("%c\n\n", -21);

	ft_printf("%4c\n", 'U');
	printf("%4c\n\n", 'U');

	ft_printf("%-1c\n", 12);
	printf("%-1c\n\n", 12);

	ft_printf("%-12c\n", '\n');
	printf("%-12c\n\n", '\n');

	ft_printf("hello ca%----4c %1c va %10c%-c ??\n", '\0', '\n', (char)564, 0);
	printf("hello ca%----4c %1c va %10c%-c ??\n\n", '\0', '\n', (char)564, 0);
	return (0);
}

