#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
typedef struct s_tab
{
    int    flag_hash;
    int    flag_zero;
    int    flag_minus;
    int    flag_space;
    int    flag_plus;
    int    pres;
    int    pres_nb;
    int    width;
    int    width_nb;
    char    *length;
    int     len;
    char *format;
}        t_tab;
int	ft_strcmp(const char *s1, const char *s2)
{
	unsigned char *us1;
	unsigned char *us2;

	us1 = (unsigned char*)s1;
	us2 = (unsigned char*)s2;
	while (*us1 && *us1 == *us2)
	{
		us1++;
		us2++;
	}
	return (*us1 - *us2);
}

int		ft_countnbr(intmax_t i)
{
	int n = 1;
	if(i < 0)
	{
		n++;
		i *= -1;
	}
	while(i > 9)
	{
		i /= 10;
		n++;
	}
	return n;
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(intmax_t n)
{
	intmax_t tmp;

	tmp = (intmax_t)n;
	if (n < 0)
	{
		ft_putchar('-');
		tmp *= -1;
	}
	if (tmp > 9)
		ft_putnbr(tmp / 10);
	ft_putchar(tmp % 10 + '0');
}

int		print_d(t_tab *arg, va_list ap)
{
	int i;
	intmax_t	num;

	num = va_arg(ap, intmax_t);
	if (arg->length == NULL)
		(num = (int)num);
	else if (!ft_strcmp(arg->length, "h"))
		num = (short)num;
	else if (!ft_strcmp(arg->length, "hh"))
		num = (signed char)num;
	else if (!ft_strcmp(arg->length, "l"))
		num = (long)num;
	else if (!ft_strcmp(arg->length, "ll") ||
			ft_strcmp(arg->length, "z"))
		num = (long long)num;
	(arg->flag_space == 1) && (write(1, " ", 1));

	i = ft_countnbr(num);
	(i < arg->pres_nb) && (arg->width_nb -= (arg->pres_nb - i));
	(arg->flag_plus == 1) && arg->width_nb--;
	(arg->flag_space == 1) && (arg->width_nb-- && arg->pres_nb--);
	while((arg->width_nb - i) > 0 && arg->flag_minus == 0)
	{
		if (arg->flag_zero == 1 && num < 0)
			write(1, "-", 1) && (num *= -1);
		if(arg->flag_plus == 0)
			arg->flag_zero == 1 ? write(1, "0", 1) : write(1, " ", 1);
		if(arg->flag_plus == 1)
			write(1, " ", 1);
		arg->width_nb--;
	}
	if (arg->flag_plus == 1 && num >= 0)
	   	write(1, "+", 1) && arg->pres_nb--;
	if (num < 0)
		write(1, "-", 1) && (num *= -1);
	while((arg->pres_nb - i + 1) > 0)
		write(1, "0", 1) && arg->pres_nb--;
	ft_putnbr(num);
	while((arg->width_nb - i) > 0 && arg->flag_minus == 1)
	{
		if (arg->flag_zero == 1 && num < 0)
			write(1, "-", 1) && (num *= -1);
		arg->flag_zero == 1 ? write(1, "0", 1) : write(1, " ", 1);
		arg->width_nb--;
	}
	arg->len += ft_countnbr(num);
	return (arg->len);
}
char	*ft_strchr(const char *s, int c)
{
	while (*s && *s != c)
		s++;
	while (!*s && c)
		return (0);
	return ((char *)s);
}
char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if (*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{
		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if (ft_strchr(s, *format))
	{
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'j') && (arg->length = "j");
		(*format == 't') && (arg->length = "t");
		(*format == 'z') && (arg->length = "z");
		(*format == 'q') && (arg->length = "q");
		return (format + 1);
	}
	return (format);

}
int	ft_isdigit(int c)
{
	return (c > 47 && c < 58);
}
char	*ft_pres(char *format, t_tab *arg, va_list ap)
{
	if(*format == '.')
	{
		format++;
		arg->pres = 1;
		if(ft_isdigit(*format))
			arg->pres_nb = 0;
		while(ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width(char *format, t_tab *arg, va_list ap)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb *10 + *format++ - '0';
	return (format);
}
char    *ft_flag(char *format, t_tab *arg)
{
	while (*format == '#' || *format == '0' || *format == '-' || *format == ' ' || *format == '+')
	{
	(*format == '0') && (arg->flag_zero = 1);
	(*format == '-') && (arg->flag_minus = 1);
	(*format == ' ') && (arg->flag_space = 1);
	(*format == '+') && (arg->flag_plus = 1);
	(arg->flag_minus) && (arg->flag_zero = 0);
	(arg->flag_plus) && (arg->flag_space = 0);
	format++;
	}
	return (format);
}
void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}
char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;
	s = "sSdDioOuUxXcC";
	format = ft_flag(format, arg);
	format = ft_width(format, arg, ap);
	format = ft_pres(format, arg, ap);
	format = ft_length(format, arg);
	if (ft_strchr(s, *format) == NULL)
		(write(1, "%", 1)) && (format = arg->format);
	(*format == 's' || *format == 'S') && (print_d(arg, ap));
	(*format == 'p') && (print_d(arg, ap));
	(*format == 'd' || *format == 'D' || *format == 'i') && (print_d(arg, ap));
	(*format == 'o' || *format == 'O') && (print_d(arg, ap));
	(*format == 'u' || *format == 'U') && (print_d(arg, ap));
	(*format == 'x' || *format == 'X') && (print_d(arg, ap));
	(*format == 'c' || *format == 'C') && (print_d(arg, ap));
	return (format);
}
int    ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%')
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if(*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	return (arg->len);
}
int	main()
{

//	ft_printf("%d\n", 42);
//	printf("%d\n\n", 42);

//	ft_printf("%d\n", -42);
//	printf("%d\n\n", -42);


	ft_printf("% d\n", 0);
	printf("% d\n\n", 0);

	ft_printf("%+d\n", 0);
	printf("%+d\n\n", 0);

	ft_printf("%+++d\n", 534);
	printf("%+++d\n\n", 534);

	ft_printf("%+d\n", -4440);
	printf("%+d\n\n", -4440);

	ft_printf("% d\n", 0xff11ff);
	printf("% d\n\n", 0xff11ff);

	ft_printf("%ld\n", 0x44ff551100);
	printf("%ld\n\n", 0x44ff551100);

	ft_printf("%zi\n", (long)40000);
	printf("%zi\n\n", (long)40000);

	ft_printf("%lld\n", (long long)-4278900);
	printf("%lld\n\n", (long long)-4278900);

	ft_printf("%hd\n", (short)0x1789ffff);
	printf("%hd\n\n", (short)0x1789ffff);

	ft_printf("%lli\n", (long long)0x11ff11ff11ff11ff);
	printf("%lli\n\n", (long long)0x11ff11ff11ff11ff);

	ft_printf("%lD\n", 0xff11ff11ff88);
	printf("%ld\n\n", 0xff11ff11ff88);

	ft_printf("%D\n", 0);
	printf("%D\n\n", 0);

	ft_printf("%i\n", (signed int)0xff11);
	printf("%i\n\n", (signed int)0xff11);

	ft_printf("%.12d\n", 1144);
	printf("%.12d\n\n", 1144);

	ft_printf("%.2i\n", -10);
	printf("%.2i\n\n", -10);

	ft_printf("%.i\n", 44);
	printf("%.i\n\n", 44);

	ft_printf("%.0d\n", -21);
	printf("%.0d\n\n", -21);

	ft_printf("%.5d\n", -421);
	printf("%.5d\n\n", -421);

	ft_printf("%5d\n", -741);
	printf("%5d\n\n", -741);

	ft_printf("%08i\n", -71);
	printf("%08i\n\n", -71);

	ft_printf("%-2i\n", -7);
	printf("%-2i\n\n", -7);

	ft_printf("%-7d.\n", 7789);
	printf("%-7d.\n\n", 7789);

	ft_printf("%.5d\n", -421);
	printf("%.5d\n\n", -421);

	ft_printf("%0d\n", -579);
	printf("%0d\n\n", -579);

	ft_printf("%04d\n", 0);
	printf("%04d\n\n", 0);

	ft_printf("%+12.5d\n", 140);
	printf("%+12.5d\n\n", 140);

	ft_printf("%00+10.4d\n", 0);
	printf("%00+10.4d\n\n", 0);

	ft_printf("%20.ld et %.4hhi !\n", 0x11ffaa147, (signed char)-8);
	printf("%20.ld et %.4hhi !\n\n", 0x11ffaa147, (signed char)-8);

	ft_printf("% 20.12ld et % 05D% 4.8hi !\n", 0x11ffaa147, 24, (short)-2345);
	 printf("% 20.12ld et % 05D% 4.8hi !\n\n", 0x11ffaa147, 24, (short)-2345);
	return 0;//
}
