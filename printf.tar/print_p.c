#include "ft_printf.c"

void    print_result(char *str, t_tab *arg, int zero_nb, int space_nb, int arg_len)
{
    if ((space_nb > 0 || zero_nb > 0) && arg->flag_minus == 0)
    {
		
		if (zero_nb < space_nb)
            print_pad(space_nb - zero_nb, arg, ' ');
    	write(1, "0x", 2) && (arg->len += 2);
		write(1, str, arg_len);
        print_pad(zero_nb, arg, '0');

	}
	else if ((space_nb > 0 || zero_nb > 0) && arg->flag_minus == 1)
    {
        print_pad(zero_nb, arg, '0');
		write(1, "0x", 2) && (arg->len += 2);
        write(1, str, arg_len);
        if (zero_nb < space_nb)
            print_pad(space_nb - zero_nb, arg, ' ');
    }
    else
	{
		if(arg->flag_minus == 0)
			write(1, "0x", 2) && (arg->len += 2);
		write(1, str, arg_len);
	}
}
int        print_p(t_tab *arg, va_list ap)
{
    uintmax_t    str_nb;
    char        *str;
    int            arg_len;
	int    space_nb;
    int    zero_nb;

    
    str_nb = (uintmax_t)va_arg(ap, void*);
    str = ft_itoa_base(str_nb, 16);
    (arg_len = strlen(str)) && (arg->len += arg_len);
	space_nb = arg->width_nb - arg_len - 2;
    zero_nb = arg->pres_nb - arg_len;
	space_nb = (space_nb > 0 ? space_nb : 0);
	zero_nb = (zero_nb > 0 ? zero_nb : 0);
    print_result(str, arg, zero_nb, space_nb, arg_len);
    return (arg->len);
}
