#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
typedef struct s_tab
{
    int    flag_hash;
    int    flag_zero;
    int    flag_minus;
    int    flag_space;
    int    flag_plus;
    int    pres;
    int    pres_nb;
    int    width;
    int    width_nb;
    char    *length;
    int     len;
    char *format;
}        t_tab;

void	display(t_tab *arg, char c, char *str)
{
	int n;

	n = arg->width_nb - strlen(str);
	if(n > 0)
	{
		arg->len += n;
		while(n-->0)
			write(1, &c, 1);
	}
}

int	print_s(t_tab *arg, va_list ap)
{
	char	*str;
	char	c;
	
	str = va_arg(ap, char *);
	if(!str)
		str = "(null)";
	if(arg->flag_minus != 1)
	{
		c = (arg->flag_zero == 1 ? '0' : ' ');
		display(arg, c, str);
	}
	if(arg->pres == 1)
		(arg->pres_nb >= 0) ? write(1, str, arg->pres_nb) : write(1, "", 1);
	if(arg->pres != 1)
		write(1, str, strlen(str));
	if (arg->flag_minus == 1)
		(display(arg, ' ', str));
	arg->len += strlen(str);
	return (arg->len);
}
char	*ft_strchr(const char *s, int c)
{
	while (*s && *s != c)
		s++;
	while (!*s && c)
		return (0);
	return ((char *)s);
}
char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if (*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{
		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if (ft_strchr(s, *format))
	{
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'h') && (arg->length = "j");
		(*format == 'l') && (arg->length = "t");
		(*format == 'h') && (arg->length = "z");
		(*format == 'l') && (arg->length = "q");
		return (format + 1);
	}
	return (format);

}
int	ft_isdigit(int c)
{
	return (c > 47 && c < 58);
}
char	*ft_pres(char *format, t_tab *arg, va_list ap)
{
	if(*format == '.')
	{
		format++;
		arg->pres = 1;
		if(ft_isdigit(*format))
			arg->pres_nb = 0;
		while(ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width(char *format, t_tab *arg, va_list ap)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb *10 + *format++ - '0';
	return (format);
}
char    *ft_flag(char *format, t_tab *arg)
{
	while (*format == '#' || *format == '0' || *format == '-' || *format == ' ' || *format == '+')
	{
	(*format == '0') && (arg->flag_zero = 1);
	(*format == '-') && (arg->flag_minus = 1);
	(*format == ' ') && (arg->flag_space = 1);
	(*format == '+') && (arg->flag_plus = 1);
	(arg->flag_minus) && (arg->flag_zero = 0);
	(arg->flag_plus) && (arg->flag_space = 0);
	format++;
	}
	return (format);
}
void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}
char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;
	s = "sSdDioOuUxXcC";
	(!*format) && (format = NULL);
	(!(format = ft_flag(format, arg))) && (format = NULL);
	(!(format = ft_width(format, arg, ap))) && (format = NULL);
	(!(format = ft_pres(format, arg, ap))) && (format = NULL);
	(!(format = ft_length(format, arg))) && (format = NULL);
	if (ft_strchr(s, *format) == NULL)
		(write(1, "%", 1)) && (format = arg->format);
	(*format == 's' || *format == 'S') && (print_s(arg, ap));
	(*format == 'p') && (print_s(arg, ap));
	(*format == 'd' || *format == 'D' || *format == 'i') && (print_s(arg, ap));
	(*format == 'o' || *format == 'O') && (print_s(arg, ap));
	(*format == 'u' || *format == 'U') && (print_s(arg, ap));
	(*format == 'x' || *format == 'X') && (print_s(arg, ap));
	(*format == 'c' || *format == 'C') && (print_s(arg, ap));
	return (format);
}
int    ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%')
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if(*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	return (arg->len);
}
int main()
{

	ft_printf("ft_printf %.2s.\n", "coco ei titi");
	printf("printf %.2s.\n", "coco ei titi");

	ft_printf("ft_printf %.0s.\n", "coco ei titi");
	printf("printf %.0s.\n", "coco ei titi");

	ft_printf("ft_printf %.s.\n", "coco");
	printf("printf %.s.\n", "coco");

	ft_printf("ft_printf %.2s.\n", NULL);
	printf("printf %.2s.\n", NULL);

	ft_printf("ft_printf %10s.\n", NULL);
	printf("printf %10s.\n", NULL);

	ft_printf("ft_printf %-8s.\n", "coco");
	printf("printf %-8s.\n", "coco");
	
		ft_printf("ft_printf %8s.\n", "coco");
	printf("printf %8s.\n", "coco");

	ft_printf("ft_printf %-2s.\n", "");
	printf("printf %-2s.\n", "");
	
	ft_printf("ft_printf %1s.\n", "hi");
	printf("printf %1s.\n", "hi");
	

	ft_printf("ft_printf %.0s.%s.%---12s.\n", "hi", "coco", NULL);
	printf("printf %.0s.%s.%---12s.\n", "hi", "coco", NULL);

	ft_printf("ft_printf %1.4s et %-6.8s et %4.2s\n", "tuuu", "12345", "hu");
	printf("printf %1.4s et %-6.8s et %4.2s\n", "tuuu", "12345", "hu");
	return (0);
}
