#include "ft_printf.h"

uintmax_t	print_pres_nb(t_tab *arg, uintmax_t num, int arg_len)
{
	(arg->flag_plus && num >= 0) && (write(1, "+", 1));
	if(num < 0)
		write(1, "-", 1) && (num *= -1) && arg->pres_nb++;
	print_pad(arg->pres_nb - arg_len, arg, '0');
	return (num);
}
void	print_width_nb(t_tab *arg, intmax_t num, char c, int arg_len)
{
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
		if(num < 0 && !arg->pres && arg->flag_zero)
			write(1, "-", 1) && (num *= -1);
		(arg->flag_plus && num >= 0) && arg->width_nb--;
		print_pad(arg->width_nb, arg, c);
}

int        print_x(t_tab *arg, va_list ap, char c)
{
    uintmax_t    num;
    char        *str;
    int            arg_len;
	char	sign;

	sign = (arg->flag_zero > 0 ? '0' : ' ');
	(arg->pres) && (sign = ' ');
    num = va_arg(ap, uintmax_t);
	num_uintmax_t(num, arg);
    str = ft_itoa_base(num, 16, c);
    (arg_len = strlen(str)) && (arg->len += arg_len);
	if (arg->pres_nb < 1 && arg->pres && !num)
	{	write(1, "", 1);
		return (1);
	}
	(arg->flag_plus && num >= 0 && !arg->pres) && write(1, "+", 1);
	(!arg->flag_minus && arg->flag_hash && num) && (arg->width_nb -= 2);
	if(arg->width_nb > 0 && !arg->flag_minus)
		print_width_nb(arg, num, sign, arg_len);
	if(arg->flag_hash == 1 && num != 0)
		write(1, "0x", 2) && (arg->len += 2);
	if(arg->pres_nb > 0)
		num = print_pres_nb(arg, num, arg_len);
	write(1, str, arg_len);
	if(arg->width_nb > 0 && arg->flag_minus)
		print_width_nb(arg, num, sign, arg_len);
    return (arg->len);
}
