#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
typedef struct s_tab
{
    int    flag_hash;
    int    flag_zero;
    int    flag_minus;
    int    flag_space;
    int    flag_plus;
    int    pres;
    int    pres_nb;
    int    width;
    int    width_nb;
    char    *length;
    int     len;
    char *format;
}        t_tab;

void    print_pad(int padded_len, t_tab *arg, char c)
{
    int    i;

    i = 0;
    while (i < padded_len)
    {
	write (1, &c, 1);
        arg->len++;
        i++;
    }
}

int	ft_strcmp(const char *s1, const char *s2)
{
	unsigned char *us1;
	unsigned char *us2;

	us1 = (unsigned char*)s1;
	us2 = (unsigned char*)s2;
	while (*us1 && *us1 == *us2)
	{
		us1++;
		us2++;
	}
	return (*us1 - *us2);
}

int		ft_countnbr(uintmax_t i, int base)
{
	int n = 1;
	if(i < 0)
	{
		n++;
		i *= -1;
	}
	while(i > 9)
	{
		i /= base;
		n++;
	}
	return n;
}
void ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(uintmax_t n, int base)
{
	uintmax_t tmp;

	tmp = (uintmax_t)n;
	if (n < 0)
	{
		ft_putchar('-');
		tmp *= -1;
	}
	if (tmp > 9)
		ft_putnbr(tmp / base, base);
	ft_putchar(tmp % base + '0');
}

int		print_o(t_tab *arg, va_list ap)
{
	int arg_len;
	uintmax_t	num;
	char c;
	
	c = (arg->flag_zero == 1 ? '0' : ' ');
	num = va_arg(ap, uintmax_t);
	if (arg->length == NULL)
		(num = (unsigned int)num);
	else if (!ft_strcmp(arg->length, "h"))
		num = (unsigned short)num;
	else if (!ft_strcmp(arg->length, "hh"))
		num = (unsigned char)num;
	else if (!ft_strcmp(arg->length, "l"))
		num = (unsigned long)num;
	else if (!ft_strcmp(arg->length, "ll") ||
			ft_strcmp(arg->length, "z"))
		num = (unsigned long long)num;
	arg_len = ft_countnbr(num, 8);
	if(arg->flag_hash == 1 && num != 0)
		arg->width_nb--;
	(arg->pres == 1) && (c = ' ');
	if (!arg->flag_hash && arg->pres_nb < 1 && arg->pres == 1 && !num && !arg->width_nb)
	{	write(1, "", 1);
		return (1);
	}
	arg->pres_nb > arg_len ? (arg->width_nb -= arg->pres_nb) : (arg->width_nb -= arg_len);
	if(arg->width_nb > 0 && arg->flag_minus == 0)
		print_pad(arg->width_nb, arg, c);
	if(arg->pres_nb > 0)
		print_pad(arg->pres_nb - arg_len, arg, '0');
	if(arg->flag_hash == 1 && num != 0 && arg->pres_nb <= arg_len)	
		write(1, "0", 1) && arg->len++;
	ft_putnbr(num, 8);
	if(arg->width_nb > 0 && arg->flag_minus == 1)
		print_pad(arg->width_nb, arg, c);
	return (arg->len);
}
char	*ft_strchr(const char *s, int c)
{
	while (*s && *s != c)
		s++;
	while (!*s && c)
		return (0);
	return ((char *)s);
}
char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if (*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{
		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if (ft_strchr(s, *format))
	{
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'j') && (arg->length = "j");
		(*format == 't') && (arg->length = "t");
		(*format == 'z') && (arg->length = "z");
		(*format == 'q') && (arg->length = "q");
		return (format + 1);
	}
	return (format);

}
int	ft_isdigit(int c)
{
	return (c > 47 && c < 58);
}
char	*ft_pres(char *format, t_tab *arg, va_list ap)
{
	if(*format == '.')
	{
		format++;
		arg->pres = 1;
		if(ft_isdigit(*format))
			arg->pres_nb = 0;
		while(ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width(char *format, t_tab *arg, va_list ap)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb *10 + *format++ - '0';
	return (format);
}
char    *ft_flag(char *format, t_tab *arg)
{
	while (*format == '#' || *format == '0' || *format == '-' || *format == ' ' || *format == '+')
	{
	(*format == '0') && (arg->flag_zero = 1);
	(*format == '-') && (arg->flag_minus = 1);
	(*format == ' ') && (arg->flag_space = 1);
	(*format == '+') && (arg->flag_plus = 1);
	(*format == '#') && (arg->flag_hash = 1);
	(arg->flag_minus) && (arg->flag_zero = 0);
	(arg->flag_plus) && (arg->flag_space = 0);
	format++;
	}
	return (format);
}
void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}
char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;
	s = "sSdDioOuUxXcC";
	format = ft_flag(format, arg);
	format = ft_width(format, arg, ap);
	format = ft_pres(format, arg, ap);
	format = ft_length(format, arg);
	if (ft_strchr(s, *format) == NULL)
		(write(1, "%", 1)) && (format = arg->format);
//	(*format == 's' || *format == 'S') && (print_d(arg, ap));
//	(*format == 'p') && (print_d(arg, ap));
//	(*format == 'd' || *format == 'D' || *format == 'i') && (print_d(arg, ap));
	(*format == 'o' || *format == 'O') && (print_o(arg, ap));
//	(*format == 'u' || *format == 'U') && (print_u(arg, ap));
//	(*format == 'x' || *format == 'X') && (print_d(arg, ap));
//	(*format == 'c' || *format == 'C') && (print_d(arg, ap));
	return (format);
}
int    ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%')
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if(*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	return (arg->len);
}
int	main()
{
	ft_printf("%o\n", 0);
	printf("%o\n", 0);
	ft_printf("%o\n", 1475);
	printf("%o\n", 1475);

	ft_printf("%o\n", -123654789);
	printf("%o\n", -123654789);

	ft_printf("%#o\n", 0);
	printf("%#o\n", 0);


ft_printf("%#o\n", 1000); //0
printf("%#o\n", 1000);
ft_printf("%#o\n", -896);//0
printf("%#o\n", -896);

ft_printf("%hho\n", (unsigned char)-12);
printf("%hho\n", (unsigned char)-12);

ft_printf("%ho\n", (unsigned short)1475);
printf("%ho\n", (unsigned short)1475);

ft_printf("%lo\n", (unsigned long)258);
printf("%lo\n", (unsigned long)258);

ft_printf("%O\n", 0);
printf("%O\n", 0);

ft_printf("%O\n", -1470);
printf("%O\n", -1470);

ft_printf("%.2o\n", 0);
printf("%.2o\n", 0);

ft_printf("%.2o\n", 120);
printf("%.2o\n", 120);

ft_printf("%03o\n", 0);
printf("%03o\n", 0);
ft_printf("%.o\n", 12012);
printf("%.o\n", 12012);

ft_printf("%.24o\n", 12012);
printf("%.24o\n", 12012);

ft_printf("%1o\n", 0);
printf("%1o\n", 0);

ft_printf("%01o\n", 0);
printf("%01o\n", 0);

ft_printf("%03o\n", 0);
printf("%03o\n", 0);

ft_printf("%6o\n", 01423);
printf("%6o\n", 01423);

ft_printf("%2o\n", 01423);
printf("%2o\n", 01423);

ft_printf("%-12o.\n", 01423);
printf("%-12o.\n", 01423);

ft_printf("%011o\n", 013);
printf("%011o\n", 013);

ft_printf("%-6o\n", 0155224);
printf("%-6o\n", 0155224);

ft_printf("coco et %-#-#--24O titi%#012o\n", 12, -874); //0
printf("coco et %-#-#--24O titi%#012o\n", 12, -874);

ft_printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);
printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);

ft_printf("%024hho et%#.o %0012.O\n", (unsigned char)12, 1, 123654789);
printf("%024hho et%#.o %0012.O\n", (unsigned char)12, 1, 123654789);

ft_printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);
printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);

ft_printf("%.0o\n", 0);
printf("%.0o\n", 0);

ft_printf("%.O\n", 0);
printf("%.O\n", 0);

ft_printf("toto %###.0o%#.O et %#.1o !\n", 0, 0, 0);
printf("toto %###.0o%#.O et %#.1o !\n", 0, 0, 0);

ft_printf("m%#.9odee\n", 123456789);
printf("m%#.9odee\n", 123456789);

ft_printf("%o\n", 0);
	printf("%o\n", 0);

ft_printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);
printf("test%#.4o et %02o. %0#14.0o!!\n", 012, 036, 12587499);

ft_printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);
printf("t%04.2o%#2oet %#-8.3o titi\n", 0, 0, 0);

ft_printf("%.2o\n", 0);
printf("%.2o\n", 0);

	return 0;//
}
