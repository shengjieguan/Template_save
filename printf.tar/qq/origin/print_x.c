#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#define HEX "0123456789abcdef"
#define HEX_BIG "0123456789ABCDEF"
typedef struct s_tab
{
    int    flag_hash;
    int    flag_zero;
    int    flag_minus;
    int    flag_space;
    int    flag_plus;
    int    pres;
    int    pres_nb;
    int    width;
    int    width_nb;
    char    *length;
    int     len;
    char *format;
}        t_tab;
char    *ft_itoa_base(uintmax_t value, uintmax_t base, char c)
{
    size_t    i;
    size_t    len;
    uintmax_t        sign;
    char    tmp[130];
    char    *ret;

    len = 0;
    sign = (value < 0 ? -1 : 1);
    if (value == 0)
        tmp[len++] = '0';
    while (value)
    {
		if(c == 'x' || c == 'p')
        	tmp[len++] = HEX[value % base * sign];
		if(c == 'X')
			tmp[len++] = HEX_BIG[value % base * sign];
        value /= base;
    }
    if (sign == -1 && base == 10)
        tmp[len++] = '-';
    if (!(ret = (char*)malloc(sizeof(char) * (len + 1))))
        return (NULL);
    ret[len] = 0;
    i = -1;
    while (++i < len)
        ret[i] = tmp[len - 1 - i];
    return (ret);
}
void    print_pad(int padded_len, t_tab *arg, char c)
{
    int    i;

    i = 0;
    while (i < padded_len)
    {
	write (1, &c, 1);
        arg->len++;
        i++;
    }
}

int	ft_strcmp(const char *s1, const char *s2)
{
	unsigned char *us1;
	unsigned char *us2;

	us1 = (unsigned char*)s1;
	us2 = (unsigned char*)s2;
	while (*us1 && *us1 == *us2)
	{
		us1++;
		us2++;
	}
	return (*us1 - *us2);
}

int        print_x(t_tab *arg, va_list ap, char c)
{
    uintmax_t    nb;
    char        *str;
    int            arg_len;
	char	sign;

	sign = (arg->flag_zero > 0 ? '0' : ' ');
    nb = va_arg(ap, uintmax_t);
	if (arg->length == NULL)
 		(nb = (int)nb);
 	else if (!ft_strcmp(arg->length, "h"))
 		nb = (unsigned short)nb;
 	else if (!ft_strcmp(arg->length, "hh"))
		nb = (unsigned char)nb;
	else if (!ft_strcmp(arg->length, "l"))
 		nb = (unsigned long)nb;
	else if (!ft_strcmp(arg->length, "ll") || ft_strcmp(arg->length, "z"))
		nb = (unsigned long long)nb;

    str = ft_itoa_base(nb, 16, c);
    (arg_len = strlen(str)) && (arg->len += arg_len);
//	ft_putnbr(nb);
	if(arg->width_nb > 0 && arg->flag_minus == 0 && arg->flag_hash == 0)
	{
		if(arg->pres == 1)
			sign = ' ';
		if(arg->pres_nb < arg_len)
			print_pad(arg->width_nb - arg_len, arg, sign);
		else
			print_pad(arg->width_nb - arg->pres_nb, arg, sign);
	}
	if(arg->width_nb > 0 && arg->flag_hash == 1 && arg->flag_zero == 1 && arg->pres == 1)
		print_pad(arg->width_nb - arg_len - 2, arg, ' ');
	if(arg->flag_hash == 1 && nb != 0)
		write(1, "0x", 2) && (arg->len += 2);
	if(arg->pres_nb >= 0)
	{
		print_pad(arg->pres_nb - arg_len, arg, '0');
		arg->width_nb -= arg->pres_nb - arg_len;
	}
	if(arg->width_nb > 0 && arg->flag_hash == 1 && arg->pres_nb < 0)
	{
		if(nb == 0)
			print_pad(arg->width_nb - 2, arg, sign);
		print_pad(arg->width_nb - arg_len - 2, arg, sign);
	}
	(arg->pres_nb < 1 && arg->pres == 1 && nb == 0) && (arg_len = 0);
	(arg->flag_hash == 1 && arg->flag_zero == 1 && arg->width_nb == 0) && (arg_len = 1);
	write(1, str, arg_len);
	if(arg->width_nb > 0 && arg->flag_minus == 1)
		print_pad(arg->width_nb - arg_len, arg, sign);
    return (arg->len);
}
char	*ft_strchr(const char *s, int c)
{
	while (*s && *s != c)
		s++;
	while (!*s && c)
		return (0);
	return ((char *)s);
}
char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if (*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{
		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if (ft_strchr(s, *format))
	{
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'j') && (arg->length = "j");
		(*format == 't') && (arg->length = "t");
		(*format == 'z') && (arg->length = "z");
		(*format == 'q') && (arg->length = "q");
		return (format + 1);
	}
	return (format);

}
int	ft_isdigit(int c)
{
	return (c > 47 && c < 58);
}
char	*ft_pres(char *format, t_tab *arg, va_list ap)
{
	if(*format == '.')
	{
		format++;
		arg->pres = 1;
		if(ft_isdigit(*format))
			arg->pres_nb = 0;
		while(ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width(char *format, t_tab *arg, va_list ap)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb *10 + *format++ - '0';
	return (format);
}
char    *ft_flag(char *format, t_tab *arg)
{
	while (*format == '#' || *format == '0' || *format == '-' || *format == ' ' || *format == '+')
	{
	(*format  == '#') && (arg->flag_hash = 1);
	(*format == '0') && (arg->flag_zero = 1);
	(*format == '-') && (arg->flag_minus = 1);
	(*format == ' ') && (arg->flag_space = 1);
	(*format == '+') && (arg->flag_plus = 1);
	(arg->flag_minus) && (arg->flag_zero = 0);
	(arg->flag_plus) && (arg->flag_space = 0);
	format++;
	}
	return (format);
}
void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}
char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;
	s = "sSdDioOuUxXcCp";
	format = ft_flag(format, arg);
	format = ft_width(format, arg, ap);
	format = ft_pres(format, arg, ap);
	format = ft_length(format, arg);
	if (ft_strchr(s, *format) == NULL)
		(write(1, "%", 1)) && (format = arg->format);
	
	(*format == 'x' || *format == 'X') && (print_x(arg, ap, *format));
	return (format);
}
int    ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%')
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if(*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	return (arg->len);
}
int main()
{
    int a;
ft_printf("%x\n", 0);
printf("%x\n", 0);

ft_printf("%X\n", 0xa0);
printf("%X\n", 0xa0);

ft_printf("%x\n", 0xa0ffff);
printf("%x\n", 0xa0ffff);

ft_printf("%x\n", -12345678);
printf("%x\n", -12345678);

ft_printf("%X\n", -1234567800);
printf("%X\n", -1234567800);

ft_printf("%#X\n", 0);
printf("%#X\n", 0);

ft_printf("%#x.\n", 0x78aa);
printf("%#x.\n", 0x78aa);

ft_printf("%#X\n", 0xff7744);
printf("%#X\n", 0xff7744);

ft_printf("%.x.\n", 12);
printf("%.x.\n", 12);

ft_printf("%.0X.\n", 0xaabbcc);
printf("%.0X.\n", 0xaabbcc);

ft_printf("%4x\n", 0xdd);
printf("%4x\n", 0xdd);

ft_printf("%011X\n", 0xdd66);
printf("%011X\n", 0xdd66);

ft_printf("%-6x.\n", 0xdd66);
printf("%-6x.\n", 0xdd66);

ft_printf("%-2x.\n", 0xadd66);
printf("%-2x.\n", 0xadd66);

ft_printf("%20x\n", 0x123456bc);
printf("%20x\n", 0x123456bc);

ft_printf("test%---10.6x et %01hhX !!\n", 0xaabb, (unsigned char)0);
printf("test%---10.6x et %01hhX !!\n", 0xaabb, (unsigned char)0);

ft_printf("t %#7.5X%0006.2x et %lX!\n", 0xab, 0x876, 0xff11ff11ff1);
printf("t %#7.5X%0006.2x et %lX!\n", 0xab, 0x876, 0xff11ff11ff1);

ft_printf("toto %0##0.4X%#4.2xet c'est fini .\n", 0x037a, 0x9e);
printf("toto %0##0.4X%#4.2xet c'est fini .\n", 0x037a, 0x9e);

ft_printf("cc%#.4X et %#0012x %#04hX !!\n", 0xaef, 0xe, (unsigned short)0);
printf("cc%#.4X et %#0012x %#04hX !!\n", 0xaef, 0xe, (unsigned short)0);

ft_printf("%#.22zX et %020.14jx\n", 0xff1144ff1144, 0xffaabbccee);
printf("%#.22zX et %020.14jx\n", 0xff1144ff1144, 0xffaabbccee);

ft_printf("osef ! %#9llX et %-12hhx.\n", (unsigned long long)-1248759650, (unsigned char)-1478223695);
printf("osef ! %#9llX et %-12hhx.\n", (unsigned long long)-1248759650, (unsigned char)-1478223695);

ft_printf("%hhx\n", (unsigned char)-10);
printf("%hhx\n", (unsigned char)-10);

ft_printf("%hX\n", (unsigned short)40);
printf("%hX\n", (unsigned short)40);

ft_printf("%lx\n", 30000001245258745);
printf("%lx\n", 30000001245258745);

ft_printf("%llX\n", (unsigned long long)0xaaffee11996677);
printf("%llX\n", (unsigned long long)0xaaffee11996677);

ft_printf("%lx\n", (unsigned long)-178965423);
printf("%lx\n", (unsigned long)-178965423);

ft_printf("%jX\n", (uintmax_t)-1765423);
printf("%jX\n", (uintmax_t)-1765423);

ft_printf("%zx\n", 65423000000);
printf("%zx\n", 65423000000);

ft_printf("%.7X\n", 0xaa);
ft_printf("%.7X\n", 0xaa);

ft_printf("%.0x.\n", 0);
printf("%.0x.\n", 0);

ft_printf("toto %##.0xet %#.X.%###.1x\n", 0, 0, 0);
printf("toto %##.0xet %#.X.%###.1x\n", 0, 0, 0);

ft_printf("%0#10.0x %0#x\n", 12345, 0);
printf("%0#10.0x %0#x\n", 12345, 0);

ft_printf("%0#10.0x\n", 0);
printf("%0#10.0x\n", 0);
  return 0;
}

