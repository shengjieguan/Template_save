#include "../includes/ft_printf.h"

char	*ft_length(char *format, t_tab *arg)
{
	char *s;

	s = "hljtzq";
	if (*format == *(format + 1) && (*format == 'h' || *format == 'l'))
	{
		(*format == 'h') && (arg->length = "hh");
		(*format == 'l') && (arg->length = "ll");
		return (format + 2);
	}
	else if (ft_strchr(s, *format))
	{
		(*format == 'h') && (arg->length = "h");
		(*format == 'l') && (arg->length = "l");
		(*format == 'j') && (arg->length = "j");
		(*format == 't') && (arg->length = "t");
		(*format == 'z') && (arg->length = "z");
		(*format == 'q') && (arg->length = "q");
		return (format + 1);
	}
	return (format);

}
char	*ft_pres_nb(char *format, t_tab *arg)
{
	if(*format == '.')
	{
		format++;
		arg->pres = 1;
		if(ft_isdigit(*format))
			arg->pres_nb = 0;
		while(ft_isdigit(*format))
			arg->pres_nb = arg->pres_nb * 10 + *format++ - '0';
	}
	return (format);
}

char	*ft_width_nb(char *format, t_tab *arg)
{
	arg->width_nb = 0;
	while (ft_isdigit(*format))
		arg->width_nb = arg->width_nb *10 + *format++ - '0';
	return (format);
}
char    *ft_flag(char *format, t_tab *arg)
{
	while (*format == '#' || *format == '0' || *format == '-' || *format == ' ' || *format == '+')
	{
	(*format == '0') && (arg->flag_zero = 1);
	(*format == '-') && (arg->flag_minus = 1);
	(*format == ' ') && (arg->flag_space = 1);
	(*format == '+') && (arg->flag_plus = 1);
	(*format == '#') && (arg->flag_hash = 1);
	(arg->flag_minus) && (arg->flag_zero = 0);
	(arg->flag_plus) && (arg->flag_space = 0);
	format++;
	}
	return (format);
}
void	init_arg(t_tab *arg)
{
	arg->flag_hash = 0;
	arg->flag_zero = 0;
	arg->flag_minus = 0;
	arg->flag_space = 0;
	arg->flag_plus = 0;
	arg->pres = 0;
	arg->pres_nb = -1;
	arg->width = 0;
	arg->width_nb = 0;
	arg->length = NULL;
}
char	*check_format(char *format, t_tab *arg, va_list ap)
{
	char *s;
	s = "sSdDioOuUxXcCp%";
//	printf("len =%d", arg->len);
	format = ft_flag(format, arg);
	format = ft_width_nb(format, arg);
	format = ft_pres_nb(format, arg);
	format = ft_length(format, arg);
	if (ft_strchr(s, *format) == NULL)
		(write(1, "%", 1)) && (format = arg->format);
	(*format == 's' || *format == 'S') && (print_s(arg, ap));
	(*format == 'p') && (print_p(arg, ap));
	(*format == 'd' || *format == 'D' || *format == 'i') && (print_d(arg, ap));
	(*format == 'o' || *format == 'O') && (print_o(arg, ap));
	(*format == 'u' || *format == 'U') && (print_u(arg, ap));
	(*format == 'x' || *format == 'X') && (print_x(arg, ap, *format));
	(*format == 'c' || *format == 'C') && (print_c(arg, ap));
	(*format == '%') && (print_percentage(arg));
	//printf("len_2 =%d", arg->len);

	return (format);
}
int    ft_printf(const char *format, ...)
{
	va_list	ap;
	t_tab	*arg;

	arg = malloc(sizeof(t_tab));
	arg->len = 0;
	va_start(ap, format);
	while (*format)
	{
		if (*format == '%')
		{
			init_arg(arg);
			(arg->format = (char *)format) && format++;
			format = check_format((char *)format, arg, ap);
		}
		else if(*format != '%')
			(write(1, format, 1)) && (arg->len++);
		format++;
	}
	va_end(ap);
	//	printf("len_fin =%d", arg->len);

	return (arg->len);
}

