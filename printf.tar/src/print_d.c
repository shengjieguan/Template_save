#include "../includes/ft_printf.h"
intmax_t	print_width_nb(t_tab *arg, intmax_t num, char c)
{

		//if(num < 0 && !arg->pres && arg->flag_zero && !arg->flag_plus)
		//	write(1, "-", 1) && (num *= -1);
		
		print_pad(arg->width_nb, arg, c);
		return (num);
}

int		print_d(t_tab *arg, va_list ap)
{
	int arg_len;
	intmax_t	num;
	char c;
	
	c = (arg->flag_zero ? '0' : ' ');
	(arg->flag_zero && arg->pres) && (c = ' ');
	num = num_intmax_t(arg, ap);
	(arg_len = ft_countnbr_signed(num, 10)) && (arg->len += arg_len);
	(arg->flag_plus && num >= 0 && !arg->flag_minus) && arg->width_nb--;
	if(arg->pres && (arg->pres_nb < 1) && !num)
	{
		print_pad(arg->width_nb, arg, c);
		arg->len--;
		return (arg->len);
	}
	if (arg->flag_space == 1 && !arg->flag_minus && !arg->flag_plus && num >= 0)
	{
		(write(1, " ", 1)) && arg->width_nb--;
		arg->len++;
	}
	if (arg->flag_plus && num >= 0 && !arg->pres)
		write(1, "+", 1) && arg->len++;
	if (arg->width_nb > arg_len && num < 0 && arg->flag_zero)
		write(1, "-", 1) && (num *= -1) && arg_len-- && arg->width_nb--;
	if (arg->width_nb && arg->pres)
		arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
	if (arg->width_nb && !arg->pres)
		arg->width_nb -= arg_len;
	//(num < 1 && num != 0 && arg->pres) && arg->width_nb--;
	if(arg->width_nb > 0 && !arg->flag_minus)
		num = print_width_nb(arg, num, c);
	//			printf("l = %d len = %d", arg->pres_nb, arg_len);

	if(arg->pres_nb > 0)
	{
		(arg->flag_plus && num >= 0) && (write(1, "+", 1)) && arg->width_nb-- && arg->len++;
		if(num < 0)
			write(1, "-", 1) && (num *= -1) && arg->pres_nb++;
	//	printf("l = %d len = %d", arg->pres_nb, arg_len);
		print_pad(arg->pres_nb - arg_len, arg, '0');
	}
	ft_putnbr_signed(num, 10);	
	if(arg->width_nb > 0 && arg->flag_minus)
		num = print_width_nb(arg, num, c);
	return (arg->len);
}
