#include "../includes/ft_printf.h"

void	display(t_tab *arg, char c, char *str)
{
	int n;

	n = arg->width_nb - ft_strlen(str);
	if(n > 0)
	{
		arg->len += n;
		while(n-->0)
			write(1, &c, 1);
	}
}

int	print_s(t_tab *arg, va_list ap)
{
	char	*str;
	char	c;
	int		arg_len;

	//			printf("l =%d", arg->width_nb);

	str = va_arg(ap, char *);
	c = (arg->flag_zero == 1 ? '0' : ' ');
	if(str == NULL)
		str = "(null)";
	//puts(str);
	arg_len = ft_strlen(str);
	if(arg->pres && arg->pres_nb)
		arg_len = (arg->pres_nb - arg_len > 0 ? arg_len : arg->pres_nb);
	//if(arg->width_nb > arg_len && arg->pres)
	//	arg->width_nb -= arg_len;
	//if(arg->width_nb > arg_len && !arg->pres)
		arg->width_nb -= arg_len;

	if(!arg->flag_minus && arg->width_nb)
		print_pad(arg->width_nb, arg, c);

	
	//(arg->pres_nb - arg_len < 0) && (arg_len = arg->pres_nb);
	if(arg->pres == 1 && !arg->pres_nb)
		return (1);
	//if(!arg->pres)
	//{
	//	printf("l =%d", arg_len);
		write(1, str, arg_len);
	//}
	if (arg->flag_minus == 1  && arg->width_nb)
		print_pad(arg->width_nb, arg, ' ');
	arg->len += arg_len;
	//printf("al = %d l = %d", arg->len, arg_len);
	return (arg->len);
}
