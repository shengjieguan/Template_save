#include "../includes/ft_printf.h"

static void	print_pres_nb(t_tab *arg, uintmax_t num, int arg_len)
{
	(arg->flag_plus && (num || num == 0)) && (write(1, "+", 1));
	//(arg->flag_plus && num >= 0) && (write(1, "+", 1));
	if(!num && num != 0)
		write(1, "-", 1) && (num *= -1) && arg->pres_nb++;
	print_pad(arg->pres_nb - arg_len, arg, '0');
	//return (num);
}
static void	print_width_nb(t_tab *arg, intmax_t num, char c)
{
	
	(arg->pres_nb < 1 && arg->pres && !num) && arg->width_nb++;
		if(num < 0 && !arg->pres && arg->flag_zero)
			write(1, "-", 1) && (num *= -1);
		(arg->flag_plus && num >= 0) && arg->width_nb--;

		print_pad(arg->width_nb, arg, c);
}

int        print_x(t_tab *arg, va_list ap, char c)
{
    uintmax_t    num;
    char        *str;
    int            arg_len;
	char	sign;

	sign = (arg->flag_zero > 0 ? '0' : ' ');
	(arg->pres) && (sign = ' ');
	num = num_uintmax_t(arg, ap);
	//(num == 4294967296) && (num = 0);
    str = ft_itoa_base(num, 16, c);
    arg_len = ft_strlen(str);
	arg->width_nb -= (arg->pres_nb > arg_len ? arg->pres_nb : arg_len);
//	(arg->flag_plus && !arg->pres) && write(1, "+", 1);
	(arg->flag_plus && (num || num == 0) && !arg->pres) && write(1, "+", 1);
	//(!arg->flag_minus && arg->flag_hash && num) && (arg->width_nb -= 2);
	
	if(arg->flag_hash == 1 && num != 0)
	{

		(arg->flag_zero) && (write(1, "0", 1) && write(1, &c, 1)); 
		(arg->width_nb -= 2) && (arg->len += 2);
	//	write(1, "0", 1) && write(1, &c, 1);
	}
	if(arg->width_nb > 0 && !arg->flag_minus)
		print_width_nb(arg, num, sign);
	if(arg->flag_hash == 1 && num != 0 && !arg->flag_zero)
		write(1, "0", 1) && write(1, &c, 1); 

	if (arg->pres_nb < 1 && arg->pres && !num)
		return (1);
	if(arg->pres_nb > 0)
		print_pres_nb(arg, num, arg_len);
	write(1, str, arg_len);
	if(arg->width_nb > 0 && arg->flag_minus)
		print_width_nb(arg, num, sign);
	arg->len += arg_len;
    return (arg->len);
}
