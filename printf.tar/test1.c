#include "includes/ft_printf.h"

int main()
{
	ft_printf("%%\n");
	printf("%%\n");

	ft_printf(".%5%.\n"); 
	printf(".%5%.\n"); 

	ft_printf("%-5%\n");
	printf("%-5%\n");

	ft_printf("%.0%.\n"); 
	printf("%.0%.\n"); 

	ft_printf("%%\n", "test"); 
//	printf("%%\n", "test"); 

ft_printf("%   %\n", "test");
//	printf("%   %\n", "test");

ft_printf("%x.\n", -42);
printf("%x.\n", -42);

ft_printf("%X\n", -42);
printf("%X\n", -42);

ft_printf("%x\n", 4294967296);
//printf("%x\n", 4294967296);

ft_printf("%X\n", 4294967296);
//printf("%X\n", 4294967296);

ft_printf("%#X\n", 42);
printf("%#X\n", 42);

ft_printf("%#x\n", 42);
printf("%#x\n", 42);

ft_printf("%#08x\n", 42);
printf("%#08x\n", 42);

ft_printf("%#-08x\n", 42);
//printf("%#-08x\n", 42);

ft_printf("@moulitest: %#.x. %#.0x.\n", 0, 0);
printf("@moulitest: %#.x. %#.0x.\n", 0, 0);

ft_printf("@moulitest: %.x. %.0x.\n", 0, 0); 
printf("@moulitest: %.x. %.0x.\n", 0, 0); 

ft_printf("@moulitest: %5.x. %5.0x.\n", 0, 0); 
printf("@moulitest: %5.x. %5.0x.\n", 0, 0); 

ft_printf("%.2s is a string.\n", "this");
printf("%.2s is a string.\n", "this");

ft_printf("%5.2s is a string\n", "this");
printf("%5.2s is a string\n", "this");

ft_printf("%-.2s is a string.\n", "this");
printf("%-.2s is a string.\n", "this");

ft_printf("%-5.2s is a string.\n", "this");
printf("%-5.2s is a string\n", "this");

ft_printf("%o\n", 40); 
printf("%o\n", 40);
    
    
    int main()
    {
        ft_printf("%%\n");
        printf("%%\n");
        
        ft_printf("%5%\n");
        printf("%5%\n");
        
        ft_printf("%-5%\n");
        printf("%-5%\n");
        
        ft_printf("%.0%\n");
        printf("%.0%\n");
        
        ft_printf("%x\n", -42);
        printf("%x\n", -42);
        
        ft_printf("%X\n", -42);
        printf("%X\n", -42);
        
        ft_printf("%lx\n", 4294967296);
        printf("%lx\n", 4294967296);
        
        ft_printf("%llX\n", 4294967296);
        //printf("%llX\n", 4294967296);
        
        ft_printf("%#8x\n", 42);
        printf("%#8x\n", 42); //0x
        
        ft_printf("%#-08x\n", 42);
        //printf("%#-08x\n", 42);
        
        ft_printf("@moulitest: %#.x. %#.0x.\n", 0, 0);
        printf("@moulitest: %#.x. %#.0x.\n", 0, 0);
        
        ft_printf("@moulitest: %.x %.0x\n", 0, 0);
        printf("@moulitest: %.x %.0x\n", 0, 0);
        
        ft_printf("%s\n", "abc");
        printf("%s\n", "abc");
        
        ft_printf("%s\n", "this is a string");
        printf("%s\n", "this is a string");
        
        ft_printf("%.2s is a string\n", "this");
        printf("%.2s is a string\n", "this");
        
        ft_printf("%-10s is a string\n", "this");
        printf("%-10s is a string\n", "this");
        
        ft_printf("%o\n", 40);
        printf("%o\n", 40);
        
        ft_printf("%-5o\n", 2500);
        printf("%-5o\n", 2500);
        
        ft_printf("@moulitest: %.o %.0o\n", 0, 0);
        printf("@moulitest: %.o %.0o\n", 0, 0);
        
        ft_printf("@moulitest: %5.o %5.0o\n", 0, 0);
        printf("@moulitest: %5.o %5.0o\n", 0, 0);
        
        ft_printf("% d\n", 42);
        ft_printf("% d\n", 42);
        
        ft_printf("%+d\n", 42);
        printf("%+d\n", 42);
        
        ft_printf("%5d\n", 42);
        printf("%5d\n", 42);
        
        ft_printf("%.10d\n", 4242);
        printf("%.10d\n", 4242);
        
        ft_printf("% 10.5d\n", 4242);
        printf("% 10.5d\n", 4242);
        return (0);
        
    }

	return (0);
}
