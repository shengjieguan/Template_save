/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:23:27 by shguan            #+#    #+#             */
/*   Updated: 2020/01/10 10:28:39 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/header.h"

void	check_input_2(t_sort *array, char *line)
{
	if (!ft_strcmp(line, ft_strdup("pa")))
		pa(array, line);
	else if (!ft_strcmp(line, ft_strdup("pb")))
		pb(array, line);
	else if (!ft_strcmp(line, ft_strdup("sa")))
		sa_sb(&array->a[0], &array->a[1], line, array);
	else if (!ft_strcmp(line, ft_strdup("sb")))
		sa_sb(&array->b[0], &array->b[1], line, array);
	else if (!ft_strcmp(line, ft_strdup("ra")))
		ra_rb(array->a, array->x, line, array);
	else if (!ft_strcmp(line, ft_strdup("rb")))
		ra_rb(array->b, array->y, line, array);
	else if (!ft_strcmp(line, ft_strdup("rra")))
		rra_rrb(array->a, array->x, line, array);
	else if (!ft_strcmp(line, ft_strdup("rrb")))
		rra_rrb(array->b, array->y, line, array);
	else if (!ft_strcmp(line, ft_strdup("ss")))
		ss(array);
	else if (!ft_strcmp(line, ft_strdup("rr")))
		rr(array);
	else if (!ft_strcmp(line, ft_strdup("rrr")))
		rrr(array);
}

int		check_input(t_sort *array)
{
	char *line;

	array->y = 0;
	while (get_next_line(0, &line))
	{
		if (!ft_strcmp(line, ft_strdup("pa"))
			|| !ft_strcmp(line, ft_strdup("pb"))
			|| !ft_strcmp(line, ft_strdup("sa"))
			|| !ft_strcmp(line, ft_strdup("sb"))
			|| !ft_strcmp(line, ft_strdup("ra"))
			|| !ft_strcmp(line, ft_strdup("rb"))
			|| !ft_strcmp(line, ft_strdup("rra"))
			|| !ft_strcmp(line, ft_strdup("rrb"))
			|| !ft_strcmp(line, ft_strdup("ss"))
			|| !ft_strcmp(line, ft_strdup("rr"))
			|| !ft_strcmp(line, ft_strdup("rrr")))
			check_input_2(array, line);
		else if (*line)
			return (ft_putstr("Error"));
		else
			break ;
		free(line);
	}
	return (2);
}

int		main(int ar, char **av)
{
	t_sort	array;
	char	*tmp;

	array.puts_instruction = 0;
	if (ar == 1)
		return (ft_putstr("Error"));
	if (!ft_strcmp(av[1], (tmp = ft_strdup("-v"))))
	{
		ar--;
		av++;
		array.v = 1;
		free(tmp);
	}
	if (!check_av(ar, av, &array))
		return (ft_putstr("Error"));
	if (check_input(&array) != 1)
	{
		if (check_result(&array))
			ft_putstr("ok");
		if (!check_result(&array))
			ft_putstr("ko");
	}
	return (0);
}
