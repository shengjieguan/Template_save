/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 13:21:57 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 14:11:35 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include "../libft/libft.h"
# include "../libft/get_next_line.h"

typedef struct	s_sort
{
	int			a[9999];
	int			x;
	int			b[9999];
	int			num[9999];
	int			z;
	int			y;
	int			puts_instruction;
	int			v;
}				t_sort;

int				ft_count_nb(int num);
void			print_sort(t_sort *array);
int				sa_sb(int *x, int *y, char *s, t_sort *array);
int				ss(t_sort *array);
int				ra_rb(int x[9999], int num, char *s, t_sort *array);
int				rr(t_sort *array);
int				pb(t_sort *array, char *s);
int				pa(t_sort *array, char *s);
int				rra_rrb(int	x[9999], int	num, char *s, t_sort *array);
int				rrr(t_sort *array);
int				check_input(t_sort *array);
int				check_av(int ar, char **av, t_sort *array);
int				check_result(t_sort *array);
void			sort_num(int *a_sort, int x, t_sort *array);
void			ft_num_delete(int	*a, int	*x, int	*min);
void			push_swap_4_5(t_sort *array);
void			push_swap_2_3(t_sort *array);
void			push_swap_6(t_sort *array);
void			push_swap_6_2(t_sort *array);
void			push_some_b_to_a(t_sort *array, int i);
void			sort_num_to_a(t_sort *array, int *i);
int				find_num(int *num, int start, int end, int n);
int				find_max(int a[9999], int x);
int				find_min(int a[9999], int x);

#endif
