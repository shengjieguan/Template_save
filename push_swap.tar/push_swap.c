#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "libft/libft.h"
#include "libft/get_next_line.h"
typedef struct s_sort
{
	int	a[255];
	int	x;
	int	b[255];
	int	y;
	int puts_instruction;
}				t_sort;

int		sa_sb(int *x, int *y, char *s, t_sort *array)
{
	int	temp;

	temp = *x;
	*x = *y;
	*y = temp;

	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	return (1);
}
int		ss(t_sort *array)
{
	sa_sb(&array->a[0], &array->a[1], "ss\n", array);
	sa_sb(&array->a[0], &array->a[1], "", array);
	return (1);
}

int		ra_rb(int x[255], int num, char *s, t_sort *array)
{
	int	first;
	int i;

	i = 0;
	first = x[0];
	while(i < (num - 1))
	{
		x[i] = x[i + 1];
		i++;
	}
	x[i] = first;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	return (1);
}

int		rr(t_sort *array)
{
	ra_rb(array->a, array->x, "rr\n", array);
	ra_rb(array->b, array->y, "", array);
	return (1);

}
int		pb(t_sort *array, char *s)
{
	int x;
	int y;
	
	if(array->x == 0)
		return (0);
	x = array->y;
	y = 0;
	--array->x;
	array->b[x] = array->b[x - 1];
	while(--x > 0)
	{
		array->b[x] = array->b[x -1];
	}
	array->b[0] = array->a[0];
	while(y < array->x)
	{
		array->a[y] = array->a[y + 1];
		y++;
	}
	array->y++;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	return (0);

}
int		pa(t_sort *array, char *s)
{
	int x;
	int y;
	
	//printf("y=%d", array->y);
	if(array->y == 0)
		return (0);
	x = array->x;
	y = 0;
	--array->y;
	array->a[x] = array->a[x - 1];
	while(--x > 0)
	{
		array->a[x] = array->a[x -1];
	}
	array->a[0] = array->b[0];
	while(y < array->y)
	{
		array->b[y] = array->b[y + 1];
		y++;
	}
	array->x++;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	return (1);

}
// int		pa_pb(int f[255], int s[255], int *x, int *y)
// {
// 	int num_1;
// 	int num_2;

// 	if(y == 0)
// 		return (0);
// 	num_1 = x;
// 	num_2 = 0;
// 	--y;
// 	f[x] = f[x - 1];
// 	while(--num_1 > 0)
// 	{
// 		f[num_1] = f[num_1 -1];
// 	}
// 	f[0] = s[0];
// 	while(num_2 < y)
// 	{
// 		s[num_2] = s[num_2 + 1];
// 		num_2++;
// 	}
// 	x++;
// 	return (1);
// }

int		rra_rrb(int	x[255], int	num, char *s, t_sort *array)
{
	int	last;
	int i;

	i = num;
	last = x[num - 1];
	while(--i > 0)
	{
		x[i] = x[i -1];
	}
	x[0] = last;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	return (1);
}

int		rrr(t_sort *array)
{
	rra_rrb(array->a, array->x, "rrr\n", array);
	rra_rrb(array->b, array->y, "", array);
	return (0);
}


int	check_av(int ar, char **av, t_sort *array)
{
	char **s;
	int i;
	int j;

	j = -1;
	s = (ar == 2 ? ft_strsplit(av[1], ' ') : ++av);
	while(s[++j])
	{	
		i = -1;
		while(s[j][++i])
			if(!ft_isdigit(s[j][i]))
				if((ar == 2 && s[j][i] != 32) || ar > 2)
					return (0);
		if(atoi(s[j]) > 2147483647 || atoi(s[j]) < -2147483648)
			return (0);
		array->a[j] = atoi(s[j]);
		i = j;
		while(--i >= 0)
			if(array->a[j] == array->a[i])
				return (0);
	}
	array->x = j;
	if((ar == 2 && --j < 1) || ar < 2)
		return (0);
	return (1);
}
int		check_result(t_sort *array)
{
	int i;

	i = 0;
	while(i < (array->x - 1))
	{
		if(array->a[i] > array->a[i + 1])
			return (0);
		i++;
	}
	return (1);
}

// int		find_min(int a, int b, int c, t_sort *array)
// {
// 	int	min;

// 	if(array->x == 2)
// 	{
// 		if(array->y > 1)
// 		{
// 			if ((a > array->b[0] || a < array->b[x] || b > array->b[0] || b < array->b[x]) && (a > b))
		
// 			else 
// 				min = b[0];
// 		}
// 		if(array->y = 1)
// 		{
// 				min = (a > b ? b : a);
// 		}
// 		if(array->y == 0)

		
// 	}
// }

// void	push_swap(t_sort *array)
// {
// 	array.y = 0;
// 	int	min;

// 	while(array.x > 0)
// 	{
// 		if(x == 1)
// 		{
// 			if(a[0] > b[0] || a[0] < b[y])
// 				min = a[0];
// 			else
// 				break;
// 		}
// 		if (x >= 2)
// 			min = find_min(array->a[0], array->a[1], array->a[x], array);
// 		if (min == array->a[0])
// 		{
// 			pb(array);
// 			puts("pb\n");
// 		}
// 		else if(min == array->a[1] && x >= 3)
// 		{
// 			sa(array);
// 			pb(array);
// 			puts("sa\npb\n");
// 		}
// 		else if (min == array->a[x] && x >= 2)
// 		{
// 			rra();
// 			pb();
// 			puts("rra\npb\n");
// 		}
// 		else if(min = b[0])
// 		{
// 			min = array->a[0];
// 			rra();
// 			rra();
// 			puts("rra\nrra\n");
// 			if(min == array->a[0])
// 				break;
// 		}
// 	}
// }
int	find_min(int a, int b, int c)
{
	int min;
	min = (a > b ? b : a);
	min = (min > c ? c : min);
	return (min);
}
void	push_swap_2_3(t_sort *array)
{
	int min;
	if(array->x == 2)
		sa_sb(&array->a[0], &array->a[1], "sa\n", array);
	while(array->x == 3)
	{
		min = find_min(array->a[0], array->a[1], array->a[2]);
		if(min == array->a[0] || min == array->a[2])
			rra_rrb(array->a, array->x, "rra\n", array);
		else if(min == array->a[1] && array->a[0] > array->a[2])
			ra_rb(array->a, array->x, "ra\n", array);
		else if(min == array->a[1] && array->a[0] < array->a[2])
			sa_sb(&array->a[0], &array->a[1], "sa\n", array);
		if(check_result(array))
			break;
		//	printf("%d %d %d \n", array->a[0], array->a[1], array->a[2]);
	}
}
void	push_swap_4_5(t_sort *array)
{
	int i;
	int	max;
	i = 0;
	while(array->x != 3)
		pb(array, "pb\n");
	push_swap_2_3(array);
	max = array->a[2];
	// {
	if(array->b[0] > array->b[array->y - 1])
	  		sa_sb(&array->b[0], &array->b[array->y - 1], "sb\n", array);
	// 	max = array->a[0];
	// }

	while(i < array->y)
	{
		if(array->b[0] < array->a[0] || array->b[0] > max)
		{
			pa(array, "pa\n");
			if(array->a[0] > max)
				ra_rb(array->a, array->x, "ra\n", array);
		}
		else if(array->b[0] > array->a[0])
			rr(array);
	}
	if (!check_result(array))
		ra_rb(array->a, array->x, "ra\n", array);
	printf("%d %d %d \n", array->a[0], array->a[1], array->a[2]);
}
int	main(int ar, char **av)
{
	t_sort	array;
	
	array.puts_instruction = 1;
	if(!check_av(ar, av, &array))
	{
		return (0);
	}
	if(check_result(&array))
		return (0);
	push_swap_2_3(&array);
	push_swap_4_5(&array);
	// if(check_result(&array))
	// 	puts("ok");
	// if(!check_result(&array))
	// 	puts("ko");
	 return (0);
}

