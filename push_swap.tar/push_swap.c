#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "libft/libft.h"
#include "libft/get_next_line.h"
typedef struct s_sort
{
	int	a[9999];
	int	x;
	int	b[9999];
	int	num[9999];
	int	z;
	int	y;
	int puts_instruction;
	int total;
}				t_sort;

int		sa_sb(int *x, int *y, char *s, t_sort *array)
{
	int	temp;

	temp = *x;
	*x = *y;
	*y = temp;

	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	array->total++;
	return (1);
}
int		ss(t_sort *array)
{
	sa_sb(&array->a[0], &array->a[1], "ss\n", array);
	sa_sb(&array->a[0], &array->a[1], "", array);
	array->total++;
	return (1);
}

int		ra_rb(int x[9999], int num, char *s, t_sort *array)
{
	int	first;
	int i;

	i = 0;
	first = x[0];
	while(i < (num - 1))
	{
		x[i] = x[i + 1];
		i++;
	}
	x[i] = first;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	array->total++;
	return (1);
}

int		rr(t_sort *array)
{
	ra_rb(array->a, array->x, "rr\n", array);
	ra_rb(array->b, array->y, "", array);
	array->total--;
	return (1);

}
int		pb(t_sort *array, char *s)
{
	int x;
	int y;
	
	if(array->x == 0)
		return (0);
	x = array->y;
	y = 0;
	--array->x;
	array->b[x] = array->b[x - 1];
	while(--x > 0)
	{
		array->b[x] = array->b[x -1];
	}
	array->b[0] = array->a[0];
	while(y < array->x)
	{
		array->a[y] = array->a[y + 1];
		y++;
	}
	array->y++;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	//printf("%d %d %d \n", array->y, 0, 0);
	array->total++;
	return (0);

}
int		pa(t_sort *array, char *s)
{
	int x;
	int y;
	
	//printf("y=%d", array->y);
	if(array->y == 0)
		return (0);
	x = array->x;
	y = 0;
	--array->y;
	array->a[x] = array->a[x - 1];
	while(--x > 0)
	{
		array->a[x] = array->a[x -1];
	}
	array->a[0] = array->b[0];
	while(y < array->y)
	{
		array->b[y] = array->b[y + 1];
		y++;
	}
	array->x++;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	array->total++;
	return (1);

}

int		rra_rrb(int	x[9999], int	num, char *s, t_sort *array)
{
	int	last;
	int i;

	i = num;
	last = x[num - 1];
	while(--i > 0)
	{
		x[i] = x[i -1];
	}
	x[0] = last;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
		array->total++;
	return (1);
}

int		rrr(t_sort *array)
{
	rra_rrb(array->a, array->x, "rrr\n", array);
	rra_rrb(array->b, array->y, "", array);
	array->total--;
	return (0);
}


int	check_av(int ar, char **av, t_sort *array)
{
	char **s;
	int i;
	int j;

	j = -1;
	s = (ar == 2 ? ft_strsplit(av[1], ' ') : ++av);
	while(s[++j])
	{	
		i = -1;
		while(s[j][++i])
			if(!ft_isdigit(s[j][i]))
				if((ar == 2 && s[j][i] != 32) || ar > 2)
					return (0);
		if(atoi(s[j]) > 2147483647 || atoi(s[j]) < -2147483648)
			return (0);
		array->a[j] = atoi(s[j]);
		i = j;
		while(--i >= 0)
			if(array->a[j] == array->a[i])
				return (0);
	}
	array->x = j;
	if((ar == 2 && --j < 1) || ar < 2)
		return (0);
	return (1);
}
int		check_result(t_sort *array)
{
	int i;

	i = 0;
	while(i < (array->x - 1))
	{
		if(array->a[i] > array->a[i + 1])
			return (0);
		i++;
	}
	return (1);
}
int		check_result_2(int x[9999], int n)
{
	int i;

	i = 0;
	while(i < (n - 1))
	{
		if(x[i] > x[i + 1])
			return (0);
		i++;
	}
	return (1);
}

int	find_min(int a[9999], int x)
{
	 int min;

	min = a[x -1];
	while(--x > 0)
	{
		if(a[x - 1] < min)
			min = a[x -1];
	}
	return (min);
}
int	find_max(int a[9999], int x)
{
	 int max;
	
	max = a[x -1];
	while(--x > 0)
	{
		if(a[x - 1] > max)
			max = a[x -1];
	}
	return (max);
}

int		find_num(int *num, int start, int end, int n)
{
	while(start <= end)
	{
		if(num[start] == n)
			return (1);
		start++;
	}
	return (0);
}
void sort_num_to_a(t_sort *array, int *i)
{
	if(array->a[0] == array->num[*i])
	{
		ra_rb(array->a, array->x, "ra\n", array);
		++*i;
	}
	else if(find_num(array->b, 0, array->y - 1, array->num[*i]))
	{
		while(array->num[*i] != array->b[0])
			ra_rb(array->b, array->y, "rb\n", array);
		pa(array, "pa\n");
		ra_rb(array->a, array->x, "ra\n", array);
		++*i;
	}
	else
		pb(array, "pb\n");
}

void	push_some_b_to_a(t_sort *array, int i)
{
	if (find_num(array->num, i - 10, i - 1, array->b[0]))
		pa(array, "pa\n");
	else
		ra_rb(array->b, array->y, "rb\n", array);
}
void push_swap_6_100_2(t_sort *array)
{
	int i;

	i = 0;
	while(i <= array->z / 2)
		sort_num_to_a(array, &i);
	while(array->a[0] != array->num[0])
	 	pb(array, "pb\n");
	i = array->y;
	while (array->y > 10)
	{
	 	i = array->z / 2 + array->y;
		while (array->y > i - array->z /2 - 10)
			push_some_b_to_a(array, i);
	}
	i = array->z / 2 + 1;
	while(i < array->z)
		sort_num_to_a(array, &i);
}

void	push_swap_6_100(t_sort *array)
{
	int i;
	int j;

	j = 0;
	i = array->x / 2;
	while (array->x >= i)
	{
		if (find_num(array->num, 0, i, array->a[0]))
			pb(array, "pb\n");
		else
			ra_rb(array->a, array->x, "ra\n", array);
	}
	while (array->y > 10)
	{
	 	i = array->y;
		while (array->y > i - 10)
			push_some_b_to_a(array, i);
	}
	i = 0;
	push_swap_6_100_2(array);
}

	// printf("tot=%d \n", array->total);
	// j = -1;
			
	// 		while(++j < array->x)
	// 		{
	// 			printf("%d ", array->a[j]);
	// 		}
	// 		printf("\n\n");
			// j = -1;
			// while (++i < array->y)
			// 	printf("%d ", array->b[j]);
			

void	push_swap_2_3(t_sort *array)
{
	int min;
	if(array->x == 2)
		sa_sb(&array->a[0], &array->a[1], "sa\n", array);
	while(array->x == 3)
	{
		min = find_min(array->a, array->x);
		if(min == array->a[0] || min == array->a[2])
			rra_rrb(array->a, array->x, "rra\n", array);
		else if(min == array->a[1] && array->a[0] > array->a[2])
			ra_rb(array->a, array->x, "ra\n", array);
		else if(min == array->a[1] && array->a[0] < array->a[2])
			sa_sb(&array->a[0], &array->a[1], "sa\n", array);
		if(check_result(array))
			break;
		
	}
	//printf("%d %d %d %d \n", array->a[0], array->a[1], array->a[2], min);
}

void	push_swap_4_5(t_sort *array)
{
	int min;
	int max;

	min = find_min(array->a, array->x);
	max = find_max(array->a, array->x);
	while(array->y < 2)
	{
		if(array->a[0] != min && array->a[0] != max)
			ra_rb(array->a, array->x, "ra\n", array);
		else
				pb(array, "pb\n");
	}
	push_swap_2_3(array);
	while(array->y > 0)
	{
		pa(array, "pa\n");
		if(array->a[0] > array->a[1])
				ra_rb(array->a, array->x, "ra\n", array);
	}
}

void		ft_num_delete(int	*a, int	*x, int	*min)
{
	int i;

	i = 0;
	while(a[i] != *min && i < *x)
	{
		i++;
	}
	a[i] = a[*x - 1];
	--*x;
	
}
void	sort_num(int *a_sort, int x, t_sort *array)
{
	int i;
	int	j;
	int	min;
	int a[9999];

	i = x;
	while(--i >= 0)
		a[i] = a_sort[i];
	array->z = x;
	i = -1;
	while(++i < array->z)
	{
		array->num[i] = find_min(a, x);
		
		ft_num_delete(&*a, &x, &array->num[i]);
	}
}
int	main(int ar, char **av)
{
	t_sort	array;
	
	array.puts_instruction = 1;
	if(!check_av(ar, av, &array))
	{
		return (0);
	}
	if(check_result(&array))
		return (0);
	sort_num(array.a, array.x, &array);
	if (array.x < 4)
		push_swap_2_3(&array);
	if(array.x > 3 && array.x < 6)
		push_swap_4_5(&array);
	if (array.x > 5)
		push_swap_6_100(&array);
	 return (0);
}

