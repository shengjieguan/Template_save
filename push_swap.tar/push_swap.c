/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:23:42 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 15:19:12 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/header.h"

int		main(int ar, char **av)
{
	t_sort	array;

	if (ar < 2)
		return (0);
	array.puts_instruction = 1;
	if (!ft_strcmp(av[1], ft_strdup("-v")))
	{
		ar--;
		av++;
		array.v = 1;
	}
	if (!check_av(ar, av, &array))
	{
		return (0);
	}
	if (check_result(&array))
		return (0);
	sort_num(array.a, array.x, &array);
	if (array.x < 4)
		push_swap_2_3(&array);
	if (array.x > 3 && array.x < 6)
		push_swap_4_5(&array);
	if (array.x > 5)
		push_swap_6(&array);
	return (0);
}
