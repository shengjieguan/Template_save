/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_av_result.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:22:39 by shguan            #+#    #+#             */
/*   Updated: 2020/01/10 10:11:27 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

int		check_av(int ar, char **av, t_sort *array)
{
	char	**s;
	int		i;
	int		j;

	j = -1;
	s = (ar == 2 ? ft_strsplit(av[1], ' ') : ++av);
	while (s[++j])
	{
		i = -1;
		while (s[j][++i])
			if (!ft_isdigit(s[j][i]))
				if ((ar == 2 && s[j][i] != 32) || ar > 2)
					return (0);
		if (atoi(s[j]) > 2147483647 || atoi(s[j]) < -2147483648)
			return (0);
		array->a[j] = atoi(s[j]);
		i = j;
		while (--i >= 0)
			if (array->a[j] == array->a[i])
				return (0);
	}
	array->x = j;
	if ((ar == 2 && --j < 1) || ar < 2)
		return (0);
	return (1);
}

int		check_result(t_sort *array)
{
	int i;

	i = 0;
	while (i < (array->x - 1))
	{
		if (array->a[i] > array->a[i + 1])
			return (0);
		i++;
	}
	return (1);
}
