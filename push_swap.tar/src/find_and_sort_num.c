/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_and_sort_num.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:15:43 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 14:16:47 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

int		find_min(int *a, int x)
{
	int min;

	min = a[x - 1];
	while (--x > 0)
	{
		if (a[x - 1] < min)
			min = a[x - 1];
	}
	return (min);
}

int		find_max(int *a, int x)
{
	int	max;

	max = a[x - 1];
	while (--x > 0)
	{
		if (a[x - 1] > max)
			max = a[x - 1];
	}
	return (max);
}

int		find_num(int *num, int start, int end, int n)
{
	while (start <= end)
	{
		if (num[start] == n)
			return (1);
		start++;
	}
	return (0);
}

void	ft_num_delete(int *a, int *x, int *min)
{
	int i;

	i = 0;
	while (a[i] != *min && i < *x)
	{
		i++;
	}
	a[i] = a[*x - 1];
	--*x;
}
