/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   instruction.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:12:31 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 14:13:02 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

int		sa_sb(int *x, int *y, char *s, t_sort *array)
{
	int	temp;

	temp = *x;
	*x = *y;
	*y = temp;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	if (array->v)
		print_sort(array);
	return (1);
}

int		ss(t_sort *array)
{
	sa_sb(&array->a[0], &array->a[1], "ss\n", array);
	sa_sb(&array->a[0], &array->a[1], "", array);
	return (1);
}

int		ra_rb(int x[9999], int num, char *s, t_sort *array)
{
	int	first;
	int i;

	i = 0;
	first = x[0];
	while (i < (num - 1))
	{
		x[i] = x[i + 1];
		i++;
	}
	x[i] = first;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	if (array->v)
		print_sort(array);
	return (1);
}

int		rr(t_sort *array)
{
	ra_rb(array->a, array->x, "rr\n", array);
	ra_rb(array->b, array->y, "", array);
	return (1);
}
