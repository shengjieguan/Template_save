/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   instruction_2.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:13:11 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 14:14:36 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

int		pb(t_sort *array, char *s)
{
	int x;
	int y;

	if (array->x == 0)
		return (0);
	x = array->y;
	y = 0;
	--array->x;
	array->b[x] = array->b[x - 1];
	while (--x > 0)
		array->b[x] = array->b[x - 1];
	array->b[0] = array->a[0];
	while (y < array->x)
	{
		array->a[y] = array->a[y + 1];
		y++;
	}
	array->y++;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	if (array->v)
		print_sort(array);
	return (0);
}

int		pa(t_sort *array, char *s)
{
	int x;
	int y;

	if (array->y == 0)
		return (0);
	x = array->x;
	y = 0;
	--array->y;
	array->a[x] = array->a[x - 1];
	while (--x > 0)
	{
		array->a[x] = array->a[x - 1];
	}
	array->a[0] = array->b[0];
	while (y < array->y)
	{
		array->b[y] = array->b[y + 1];
		y++;
	}
	array->x++;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	if (array->v)
		print_sort(array);
	return (1);
}

int		rra_rrb(int *x, int num, char *s, t_sort *array)
{
	int	last;
	int	i;

	i = num;
	last = x[num - 1];
	while (--i > 0)
		x[i] = x[i - 1];
	x[0] = last;
	if (array->puts_instruction && s != NULL)
		ft_putstr(s);
	if (array->v)
		print_sort(array);
	return (1);
}

int		rrr(t_sort *array)
{
	rra_rrb(array->a, array->x, "rrr\n", array);
	rra_rrb(array->b, array->y, "", array);
	return (0);
}
