/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:15:09 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 14:15:31 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

int		ft_count_nb(int num)
{
	int	i;

	i = 1;
	if (num < 0)
	{
		num *= -1;
		i++;
	}
	while (num > 9)
	{
		num /= 10;
		i++;
	}
	return (i);
}

void	print_sort(t_sort *array)
{
	int i;

	i = 0;
	ft_putstr(" A      B\n");
	ft_putstr("---    ---\n");
	while (i < array->x || i < array->y)
	{
		if (i < array->x)
			ft_putnbr(array->a[i]);
		write(1, "       ", 7 - ft_count_nb(array->a[i]));
		if (i < array->y)
			ft_putnbr(array->b[i]);
		write(1, "\n", 1);
		i++;
	}
}
