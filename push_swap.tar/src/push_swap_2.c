/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap_2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:17:26 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 14:19:13 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

void	push_swap_4_5(t_sort *array)
{
	int min;
	int max;

	min = find_min(array->a, array->x);
	max = find_max(array->a, array->x);
	while (array->y < 2)
	{
		if (array->a[0] != min && array->a[0] != max)
			ra_rb(array->a, array->x, "ra\n", array);
		else
			pb(array, "pb\n");
	}
	push_swap_2_3(array);
	while (array->y > 0)
	{
		pa(array, "pa\n");
		if (array->a[0] > array->a[1])
			ra_rb(array->a, array->x, "ra\n", array);
	}
}

void	push_swap_2_3(t_sort *array)
{
	int min;

	if (array->x == 2)
		sa_sb(&array->a[0], &array->a[1], "sa\n", array);
	while (array->x == 3)
	{
		min = find_min(array->a, array->x);
		if (min == array->a[0] || min == array->a[2])
			rra_rrb(array->a, array->x, "rra\n", array);
		else if (min == array->a[1] && array->a[0] > array->a[2])
			ra_rb(array->a, array->x, "ra\n", array);
		else if (min == array->a[1] && array->a[0] < array->a[2])
			sa_sb(&array->a[0], &array->a[1], "sa\n", array);
		if (check_result(array))
			break ;
	}
}

void	push_swap_6_2(t_sort *array)
{
	int i;

	i = 0;
	while (i <= array->z / 2)
		sort_num_to_a(array, &i);
	while (array->a[0] != array->num[0])
		pb(array, "pb\n");
	i = array->y;
	while (array->y > 10)
	{
		i = (array->z / 2 + array->y);
		while (array->y > i - array->z / 2 - 10)
			push_some_b_to_a(array, i);
	}
	i = array->z / 2 + 1;
	while (i < array->z)
		sort_num_to_a(array, &i);
}

void	push_swap_6(t_sort *array)
{
	int	i;
	int	j;

	j = 0;
	i = array->x / 2;
	while (array->x >= i)
	{
		if ((find_num(array->num, 0, i + 1, array->a[0]) && (i * 2 < array->z))
			|| (find_num(array->num, 0, i, array->a[0]) && (i * 2 == array->z)))
			pb(array, "pb\n");
		else
			ra_rb(array->a, array->x, "ra\n", array);
	}
	while (array->y > 10)
	{
		i = array->y;
		while (array->y > i - 10)
			push_some_b_to_a(array, i);
	}
	push_swap_6_2(array);
}
