/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_stack.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shguan <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/09 14:19:26 by shguan            #+#    #+#             */
/*   Updated: 2020/01/09 14:21:10 by shguan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/header.h"

void	sort_num_to_a(t_sort *array, int *i)
{
	if (array->a[0] == array->num[*i])
	{
		ra_rb(array->a, array->x, "ra\n", array);
		++*i;
	}
	else if (find_num(array->b, 0, array->y - 1, array->num[*i]))
	{
		while (array->num[*i] != array->b[0])
			ra_rb(array->b, array->y, "rb\n", array);
		pa(array, "pa\n");
		ra_rb(array->a, array->x, "ra\n", array);
		++*i;
	}
	else
		pb(array, "pb\n");
}

void	push_some_b_to_a(t_sort *array, int i)
{
	if (find_num(array->num, i - 10, i - 1, array->b[0]))
		pa(array, "pa\n");
	else
		ra_rb(array->b, array->y, "rb\n", array);
}

void	sort_num(int *a_sort, int x, t_sort *array)
{
	int i;
	int a[9999];

	i = x;
	while (--i >= 0)
		a[i] = a_sort[i];
	array->z = x;
	i = -1;
	while (++i < array->z)
	{
		array->num[i] = find_min(a, x);
		ft_num_delete(&*a, &x, &array->num[i]);
	}
}
