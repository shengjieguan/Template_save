#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "get_next_line.h"

# define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
# define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
# define H(x, y, z) ((x) ^ (y) ^ (z))
# define I(x, y, z) ((y) ^ ((x) | (~z)))

# define MD5_A 0x67452301
# define MD5_B 0xefcdab89
# define MD5_C 0x98badcfe
# define MD5_D 0x10325476
# define A 0
# define B 1
# define C 2
# define D 3
# define L_ROT(x, n, b) (((x) << (n)) | ((x) >> (b - (n))))
typedef struct            s_dgst {
    uint32_t            state[4];
    uint32_t            f;
}                        t_dgst;

static const uint32_t    g_k[64] = {
    0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
    0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
    0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
    0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
    0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
    0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
    0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
    0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
    0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
    0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
    0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
    0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
    0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
    0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
    0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
    0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391};


static const uint32_t    g_s[64] = {
    7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, \
    5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, \
    4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, \
    6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
};

typedef struct s_ssl
{
	char *model;
	char *input;
	unsigned char *m;
	uint64_t		len;
	uint64_t		l;
	int			s;
	int			r;
	int			q;
	int			p;
}				t_ssl;
void                    md5_set(t_dgst *dgst, uint32_t *m, uint8_t g, int i)
{
    uint32_t            tmp;

    tmp = dgst->state[D];
    dgst->state[D] = dgst->state[C];
    dgst->state[C] = dgst->state[B];
    dgst->state[B] = dgst->state[B] + \
    L_ROT((dgst->state[A] + dgst->f + g_k[i] + m[g]), g_s[i], 32);
    dgst->state[A] = tmp;
}

void                    md5_compress(t_dgst *dgst, uint32_t *m, int i)
{
    uint8_t                g;

    if (i < 16)
    {
        dgst->f = F(dgst->state[B], dgst->state[C], dgst->state[D]);
        g = i;
    }
    else if (i < 32)
    {
        dgst->f = G(dgst->state[B], dgst->state[C], dgst->state[D]);
        g = (5 * i + 1) % 16;
    }
    else if (i < 48)
    {
        dgst->f = H(dgst->state[B], dgst->state[C], dgst->state[D]);
        g = (3 * i + 5) % 16;
    }
    else
    {
        dgst->f = I(dgst->state[B], dgst->state[C], dgst->state[D]);
        g = (7 * i) % 16;
    }
    md5_set(dgst, m, g, i);
}
void                    md5_update(t_dgst *dgst, t_dgst *prev)
{
    int                    i;

    i = -1;
    while (++i < 4)
        dgst->state[i] += prev->state[i];
    i = -1;
    while (++i < 4)
        prev->state[i] = dgst->state[i];
}

void                    *md5_init(t_dgst *dgst)
{
    dgst->state[A] = MD5_A;
    dgst->state[B] = MD5_B;
    dgst->state[C] = MD5_C;
    dgst->state[D] = MD5_D;
    dgst->f = 0;
    return (dgst);
}
void					encode(unsigned char *output, uint32_t *input, \
						unsigned int len)
{
	unsigned int		i;
	unsigned int		j;

	j = 0;
	i = 0;
	while (j < len)
	{
		output[j] = (unsigned char)(input[i] & 0xff);
		output[j + 1] = (unsigned char)((input[i] >> 8) & 0xff);
		output[j + 2] = (unsigned char)((input[i] >> 16) & 0xff);
		output[j + 3] = (unsigned char)((input[i] >> 24) & 0xff);
		i++;
		j += 4;
	}
}
void					print_hash(uint32_t *state, uint8_t len)
{
	unsigned char		digest[len];
	unsigned int		i;

	encode(digest, state, len);
	i = 0;
	while (i < len)
		printf("%02x", digest[i++]);
}
void   md5(unsigned char *m, uint32_t l)
{
	t_dgst                dgst;
    t_dgst                prev;
    uint64_t            block;
    int                    i;

    md5_init(&dgst);
    md5_init(&prev);
    block = 0;
    while (block < l)
    {
        i = 0;
        while (i < 64)
        {
            md5_compress(&dgst, (uint32_t *)(m + block), i);
            i++;
        }
		md5_update(&dgst, &prev);
        block += 64;
    }
    print_hash(dgst.state, 16);
}

void					pad_m(char *input, t_ssl *ssl)
{
	int					i;
	int					mod;

	//printf("len=%lld\n", ssl->len);
	i = -1;
	mod = 64;
	ssl->l = ssl->len + 9;
	while (ssl->l % mod != 0)
		ssl->l += 1;
	if (!(ssl->m = (unsigned char *)malloc(sizeof(unsigned char) * ssl->l)))
		//ssl_error((char *)ssl->m, MALL_ERR);
		return ;
	ft_bzero(ssl->m, ssl->l);
	ft_memcpy(ssl->m, input, ssl->len);
	*(uint32_t *)(ssl->m + ssl->len) = 128;
	*(uint64_t *)(ssl->m + (ssl->l - 8)) = (8 * ssl->len);
	i = -1;
	//while (++i < ssl->l)
	//	printf("%hhu %d %llu\n", ssl->m[i], i, ssl->l);
}

void	ft_md5(t_ssl *ssl)
{
	int i;
	i = -1;
			
		pad_m(ssl->input, ssl);
		while(++i < 64)
				printf("%hhu %lld %d\n", ssl->m[i], ssl->len, i);
		md5(ssl->m, ssl->l);

}


char		*copy_file_content(const int fd)
{
	static char	*s[4096];
	char		buf[4096];
	char		*tmp;
	int			ret;

	if (fd < 0 || fd > 4096)
		return (NULL);
	if (s[fd] == NULL)
		s[fd] = ft_memalloc(1);
	while ((ret = read(fd, buf, BUFF_SIZE)) > 0)
	{
		buf[ret] = '\0';
		tmp = s[fd];
		s[fd] = ft_strjoin(tmp, buf);
		free(tmp);
	}
	if (ret <= 0 && (s[fd] == NULL || s[fd][0] == '\0'))
		return (NULL);
	return (s[fd]);
}

void	get_file(char *s, t_ssl *ssl)
{
	int	fd;
	char *line;

	puts(s);
	fd = open(s, O_RDONLY);
	line = copy_file_content(fd);
	puts(line);
	ssl->input = ft_strdup(line);
	ssl->len = (ft_strlen(line));
}
int		get_flag(char *s, t_ssl *ssl)
{
	if (ft_strequ(s, "-p"))
		ssl->p = 1;
	else if (ft_strequ(s, "-r"))
		ssl->r = 1;
	else if (ft_strequ(s, "-q"))
		ssl->q = 1;
	else if (ft_strequ(s, "-s"))
		ssl->s = 2;
	else
		return (0);
	return (1);
}
int		get_model(char *s, t_ssl *ssl, int *i)
{
	if(ft_strequ(s, "md5"))
	{
		ssl->model = ft_strdup(s);
		++*i;

	}
	else
	{
		return (0);
	}
	
	return (1);
}
void	init(t_ssl *ssl)
{
	ssl->len = 0;
	ssl->input = NULL;
	ssl->model = NULL;
	ssl->s = 0;
	ssl->p = 0;
	ssl->q = 0;
	ssl->r = 0;

}
void	change_input(char *s, t_ssl *ssl)
{
	char   str[4096];
	int i;

	i = 0;
	if(ssl->s)
	{
		str[i++] = '"';
		while(*s)
		{
			str[i++] = *s;
			s++;
		}	
		str[i++] = '"';
	}
	str[i] = '\0';
	ssl->input = str;
	ssl->len += 2;
}
int		main(int ar, char **av)
{
	t_ssl	ssl;
	
	int		i;
	
	// 
	puts("1");
	i = 1;
	//i = ar;
	init(&ssl);
	// if(++i < ar)
		
	// while((av = get_flag(av, &ssl)) != NULL)
	// 	i++;
	// printf("%d %s\n", i, *av);
	if (i < ar)
	{
		if (!get_model(av[i], &ssl, &i))
			return (0);
		printf("%d %s\n", i, av[i]);
		while(get_flag(av[i], &ssl))
		{
			if(get_flag(av[i], &ssl) == 2)
				break ;
			i++;
		}	
		printf("%d %s\n", i, av[i]);
		// if(av[i] == NULL || ssl.p || ssl.r || ssl.q)
		// // if(i == ar && (ssl.p || ssl.r || ssl.q))
		// {
		// 	ssl.input = copy_file_content(0);
		// 	ssl.len = ft_strlen(ssl.input);
			
		// 	ft_md5(&ssl);
		// }
		while(i < ar)
		{
			if (ssl.s)
			{
				change_input(av[i], &ssl);
			}
			else
				get_file(av[i], &ssl);
			
			if(!ssl.r)
			{
				if (!ssl.q) 
					printf("MD5 (%s) = ", ssl.input);
			}
			ft_md5(&ssl);
			if(ssl.r)
			{
				(!ssl.q) && printf(" %s\n", ssl.input);
			}
			i++;
			
		}
		// 
	}

	return (0);
}
