#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "get_next_line.h"
# define A 0
# define B 1
# define C 2
# define D 3
# define E 4
# define F 5
# define G 6
# define H 7
# define R_ROT(x, n, b) (((x) >> (n)) | ((x) << (b - (n))))
# define R_SHIFT(x, n) ((x) >> (n))
// # define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
// # define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
// # define H(x, y, z) ((x) ^ (y) ^ (z))
// # define I(x, y, z) ((y) ^ ((x) | (~z)))

// # define MD5_A 0x67452301
// # define MD5_B 0xefcdab89
// # define MD5_C 0x98badcfe
// # define MD5_D 0x10325476
// # define A 0
// # define B 1
// # define C 2
// # define D 3
// # define L_ROT(x, n, b) (((x) << (n)) | ((x) >> (b - (n))))
// typedef struct            s_dgst {
//     uint32_t            state[4];
//     uint32_t            f;
// }                        t_dgst;

// static const uint32_t    g_k[64] = {
//     0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
//     0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
//     0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
//     0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
//     0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
//     0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
//     0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
//     0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
//     0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
//     0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
//     0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
//     0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
//     0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
//     0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
//     0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
//     0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391};


// static const uint32_t    g_s[64] = {
//     7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, \
//     5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, \
//     4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, \
//     6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
// };

typedef struct s_ssl
{
	char *model;
	char *input;
	unsigned char *m;
	uint64_t		len;
	uint64_t		l;
	int			s;
	int			r;
	int			q;
	int			p;
}				t_ssl;
// void                    md5_set(t_dgst *dgst, uint32_t *m, uint8_t g, int i)
// {
//     uint32_t            tmp;

//     tmp = dgst->state[D];
//     dgst->state[D] = dgst->state[C];
//     dgst->state[C] = dgst->state[B];
//     dgst->state[B] = dgst->state[B] + \
//     L_ROT((dgst->state[A] + dgst->f + g_k[i] + m[g]), g_s[i], 32);
//     dgst->state[A] = tmp;
// }

// void                    md5_compress(t_dgst *dgst, uint32_t *m, int i)
// {
//     uint8_t                g;

//     if (i < 16)
//     {
//         dgst->f = F(dgst->state[B], dgst->state[C], dgst->state[D]);
//         g = i;
//     }
//     else if (i < 32)
//     {
//         dgst->f = G(dgst->state[B], dgst->state[C], dgst->state[D]);
//         g = (5 * i + 1) % 16;
//     }
//     else if (i < 48)
//     {
//         dgst->f = H(dgst->state[B], dgst->state[C], dgst->state[D]);
//         g = (3 * i + 5) % 16;
//     }
//     else
//     {
//         dgst->f = I(dgst->state[B], dgst->state[C], dgst->state[D]);
//         g = (7 * i) % 16;
//     }
//     md5_set(dgst, m, g, i);
// }
// void                    md5_update(t_dgst *dgst, t_dgst *prev)
// {
//     int                    i;

//     i = -1;
//     while (++i < 4)
//         dgst->state[i] += prev->state[i];
//     i = -1;
//     while (++i < 4)
//         prev->state[i] = dgst->state[i];
// }

// void                    *md5_init(t_dgst *dgst)
// {
//     dgst->state[A] = MD5_A;
//     dgst->state[B] = MD5_B;
//     dgst->state[C] = MD5_C;
//     dgst->state[D] = MD5_D;
//     dgst->f = 0;
//     return (dgst);
// }

void					change_Binary_and_print_hash(uint32_t *state, uint8_t len)
{
	unsigned char		digest[len];
	unsigned int		i;
	unsigned int		j;

	j = 0;
	i = 0;
	while (j < len)
	{
		digest[j] = (unsigned char)(state[i] & 0xff);
		digest[j + 1] = (unsigned char)((state[i] >> 8) & 0xff);
		digest[j + 2] = (unsigned char)((state[i] >> 16) & 0xff);
		digest[j + 3] = (unsigned char)((state[i] >> 24) & 0xff);
		i++;
		j += 4;
	}
	i = 0;
	while (i < len)
		printf("%02x\n", digest[i++]);
}
// void   md5(unsigned char *m, uint32_t l)
// {
// 	t_dgst                dgst;
//     t_dgst                prev;
//     uint64_t            block;
//     int                    i;

//     md5_init(&dgst);
//     md5_init(&prev);
//     block = 0;
//     while (block < l)
//     {
//         i = 0;
//         while (i < 64)
//         {
//             md5_compress(&dgst, (uint32_t *)(m + block), i);
//             i++;
//         }
// 		md5_update(&dgst, &prev);
//         block += 64;
//     }
//     print_hash(dgst.state, 16);
// }

// void					pad_m(char *input, t_ssl *ssl)
// {
// 	int					i;
// 	int					mod;

// 	//printf("len=%lld\n", ssl->len);
// 	i = -1;
// 	mod = 64;
// 	ssl->l = ssl->len + 9;
// 	while (ssl->l % mod != 0)
// 		ssl->l += 1;
// 	if (!(ssl->m = (unsigned char *)malloc(sizeof(unsigned char) * ssl->l)))
// 		//ssl_error((char *)ssl->m, MALL_ERR);
// 		return ;
// 	ft_bzero(ssl->m, ssl->l);
// 	ft_memcpy(ssl->m, input, ssl->len);
// 	*(uint32_t *)(ssl->m + ssl->len) = 128;
// 	*(uint64_t *)(ssl->m + (ssl->l - 8)) = (8 * ssl->len);
// 	i = -1;
// 	//while (++i < ssl->l)
// 	//	printf("%hhu %d %llu\n", ssl->m[i], i, ssl->l);
// }


// void	ft_md5(t_ssl *ssl)
// {
// 	int i;
// 	i = -1;
			
// 		pad_m(ssl->input, ssl);
// 		// while(++i < 64)
// 		// 		printf("%hhu %lld %d\n", ssl->m[i], ssl->len, i);
// 		md5(ssl->m, ssl->l);

// }
# define SIG0(x) (R_ROT(x,  7, 32) ^ R_ROT(x, 18, 32) ^ R_SHIFT(x,  3))
# define SIG1(x) (R_ROT(x, 17, 32) ^ R_ROT(x, 19, 32) ^ R_SHIFT(x, 10))
# define S0(x) (R_ROT(x, 2, 32) ^ R_ROT(x, 13, 32) ^ R_ROT(x, 22, 32))
# define S1(x) (R_ROT(x, 6, 32) ^ R_ROT(x, 11, 32) ^ R_ROT(x, 25, 32))

# define SHA256_A 0x6a09e667
# define SHA256_B 0xbb67ae85
# define SHA256_C 0x3c6ef372
# define SHA256_D 0xa54ff53a
# define SHA256_E 0x510e527f
# define SHA256_F 0x9b05688c
# define SHA256_G 0x1f83d9ab
# define SHA256_H 0x5be0cd19

# define CH(x, y, z)  (((x) & ((y) ^ (z))) ^ (z))
# define MAJ(x, y, z) (((x) & ((y) | (z))) | ((y) & (z)))

typedef struct			s_dgst {
	uint32_t			state[8];
}						t_dgst;

static const uint32_t	g_k[64] = {
	0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
	0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
	0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
	0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
	0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
	0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
	0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
	0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
	0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
	0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
	0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
	0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
	0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
	0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
	0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
	0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};

uint32_t		ft_swap_endian32(uint32_t n)
{
	return ((((n >> 24) & 0x000000ff) | \
			((n >> 8) & 0x0000ff00) | \
			((n << 8) & 0x00ff0000) | \
			((n << 24) & 0xff000000)));
}

void					sha256_expand(uint32_t *m, uint32_t *w)
{
	int					i;

	i = -1;
	while (++i < 16)
		w[i] = ft_swap_endian32(m[i]);
	while (i < 64)
	{
		w[i] = w[i - 16] + SIG0(w[i - 15]) + \
				w[i - 7] + SIG1(w[i - 2]);
		i++;
	}
}

void					sha256_compress(t_dgst *dgst, uint32_t *m)
{
	uint32_t			w[64];
	uint32_t			temp1;
	uint32_t			temp2;
	int					i;

	i = -1;
	sha256_expand(m, w);
	while (++i < 64)
	{
		temp1 = dgst->state[H] + w[i] + g_k[i] + S1(dgst->state[E]) + \
				CH(dgst->state[E], dgst->state[F], dgst->state[G]);
		temp2 = S0(dgst->state[A]) + \
				MAJ(dgst->state[A], dgst->state[B], dgst->state[C]);
		dgst->state[H] = dgst->state[G];
		dgst->state[G] = dgst->state[F];
		dgst->state[F] = dgst->state[E];
		dgst->state[E] = dgst->state[D] + temp1;
		dgst->state[D] = dgst->state[C];
		dgst->state[C] = dgst->state[B];
		dgst->state[B] = dgst->state[A];
		dgst->state[A] = temp1 + temp2;
	}
}

void					sha256_update(t_dgst *dgst, t_dgst *prev)
{
	int					i;

	i = -1;
	while (++i < 8)
		dgst->state[i] += prev->state[i];
	i = -1;
	while (++i < 8)
		prev->state[i] = dgst->state[i];
}
t_dgst					*sha256_init(t_dgst *dgst)
{

	
	dgst->state[A] = SHA256_A;
	dgst->state[B] = SHA256_B;
	dgst->state[C] = SHA256_C;
	dgst->state[D] = SHA256_D;
	dgst->state[E] = SHA256_E;
	dgst->state[F] = SHA256_F;
	dgst->state[G] = SHA256_G;
	dgst->state[H] = SHA256_H;
	return (dgst);
}



uint64_t		ft_swap_endian64(uint64_t n)
{
	return (((n << 56) | \
			((n & 0x000000000000FF00) << 40) | \
			((n & 0x0000000000FF0000) << 24) | \
			((n & 0x00000000FF000000) << 8) | \
			((n & 0x000000FF00000000) >> 8) | \
			((n & 0x0000FF0000000000) >> 24) | \
			((n & 0x00FF000000000000) >> 40) | \
			(n >> 56)));
}
void					pad_m(char *input, t_ssl *ssl)
{
	int					i;
	int					mod;

	//printf("len=%lld\n", ssl->len);
	i = -1;
	mod = 64;
	ssl->l = ssl->len + 9;
	while (ssl->l % mod != 0)
		ssl->l += 1;
	if (!(ssl->m = (unsigned char *)malloc(sizeof(unsigned char) * ssl->l)))
		//ssl_error((char *)ssl->m, MALL_ERR);
		return ;
	ft_bzero(ssl->m, ssl->l);
	ft_memcpy(ssl->m, input, ssl->len);
	*(uint32_t *)(ssl->m + ssl->len) = 128;
	*(uint64_t *)(ssl->m + (ssl->l - 8)) = ft_swap_endian64(8 * ssl->len);
	i = -1;
	// while (++i < ssl->l)
	// 	printf("%d %hhu  %llu %llu\n", i, ssl->m[i],  ssl->l, ssl->len);
}

void	sha256(unsigned char *m, uint64_t l)
{
	t_dgst				dgst;
	t_dgst				prev;
	uint64_t			block;
	uint64_t					i;

	i = -1;
	//puts(ssl->input);
	while (++i < l)
		printf("%llu %hhu %llu\n", i, m[i], l);
	sha256_init(&dgst);
	sha256_init(&prev);
	block = 0;
	while (block < l)
	{
		sha256_compress(&dgst, (uint32_t *)(m + block));
		sha256_update(&dgst, &prev);
		block += 64;
	}
	i = -1;
	while (++i < 8)
	{
		printf("%u\n", dgst.state[i]);
		dgst.state[i] = ft_swap_endian32(dgst.state[i]);
	}
		
	change_Binary_and_print_hash(dgst.state, 32);
}

void	ft_sha256(t_ssl *ssl)
 {
	 pad_m(ssl->input, ssl);
	 sha256(ssl->m, ssl->l);
 }

char		*copy_file_content(const int fd)
{
	static char	*s[4096];
	char		buf[4096];
	char		*tmp;
	int			ret;

	if (fd < 0 || fd > 4096)
		return (NULL);
	if (s[fd] == NULL)
		s[fd] = ft_memalloc(1);
	while ((ret = read(fd, buf, BUFF_SIZE)) > 0)
	{
		buf[ret] = '\0';
		tmp = s[fd];
		s[fd] = ft_strjoin(tmp, buf);
		free(tmp);
	}
	if (ret <= 0 && (s[fd] == NULL || s[fd][0] == '\0'))
		return (NULL);
	return (s[fd]);
}

void	get_file(char *s, t_ssl *ssl)
{
	int	fd;
	char *line;

	//puts(s);
	fd = open(s, O_RDONLY);
	line = copy_file_content(fd);
	puts(line);
	ssl->input = ft_strdup(line);
	ssl->len = (ft_strlen(line));
}
int		get_flag(char *s, t_ssl *ssl)
{
	if (!ft_strcmp(s, "-p"))
		ssl->p = 1;
	else if (!ft_strcmp(s, "-r"))
		ssl->r = 1;
	else if (!ft_strcmp(s, "-q"))
		ssl->q = 1;
	else if (!ft_strcmp(s, "-s"))
		return (ssl->s = 2);
	else
		return (0);
	return (1);
}
int		get_model(char *s, t_ssl *ssl, int *i)
{
	if(!ft_strcmp(s, "md5"))
	{
		ssl->model = ft_strdup(s);
		++*i;

	}
	else if(!ft_strcmp(s, "sha256"))
	{
		ssl->model = ft_strdup(s);
		++*i;

	}
	else
	{
		return (0);
	}
	
	return (1);
}
void	init(t_ssl *ssl)
{
	ssl->len = 0;
	ssl->input = NULL;
	ssl->model = NULL;
	ssl->s = 0;
	ssl->p = 0;
	ssl->q = 0;
	ssl->r = 0;

}

int		main(int ar, char **av)
{
	t_ssl	ssl;
	
	int		i;
	
	i = 1;
	init(&ssl);
	
	write(1, "a\n", 2);
	if (i < ar)
	{
		write(1, "a\n", 2);
		if (!get_model(av[i], &ssl, &i))
			return (0);
		
			while(i < ar && get_flag(av[i], &ssl))
			{
				get_flag(av[i], &ssl);
				if(get_flag(av[i], &ssl) == 2)
				{
					i++;
					break ;
				}
				i++;
			}
		write(1, "a\n", 2);
		if(av[i] == NULL || ssl.p)
		{
			ssl.input = copy_file_content(0);
			
			ssl.len = ft_strlen(ssl.input);
			if (ssl.p)
				ft_putstr(ssl.input);
			//ft_md5(&ssl);
			ft_sha256(&ssl);
		}
		write(1, "a\n", 2);
		while(i < ar)
		{
			if (ssl.s)
			{
				ssl.input = av[i];
				ssl.len = ft_strlen(av[i]);
				//printf("input = %s %llu\n ", ssl.input, ssl.len);
			}
			else
				get_file(av[i], &ssl);
			
			if(!ssl.r && !ssl.q)
			{
				(ssl.s) ? printf("MD5 (\"%s\") = ", ssl.input) : printf("MD5 (%s) = ", ssl.input);
			}
			//ft_md5(&ssl);
			ft_sha256(&ssl);
			if(ssl.r && !ssl.q)
			{
				(ssl.s) ? printf(" (\"%s\")\n", ssl.input) : printf(" %s\n", ssl.input);
			}
			i++;
			
		}
		// 
	}

	return (0);
}
