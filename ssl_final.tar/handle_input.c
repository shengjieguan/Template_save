#include "ssl.h"
#include <fcntl.h> 

char		*copy_file_content(const int fd)
{
	char	*s[4096];
	char		buf[99999];
	char		*tmp;
	int		ret;

	if (fd < 0 || fd > 4096)
		return (NULL);
	if (s[fd] == NULL)
		s[fd] = ft_memalloc(1);
	while ((ret = read(fd, buf, 99998)) > 0)
	{
		buf[ret] = '\0';
		tmp = s[fd];
		s[fd] = ft_strjoin(tmp, buf);
		free(tmp);
	}
	if (ret <= 0 && (s[fd] == NULL || s[fd][0] == '\0'))
		return (NULL);
	return (s[fd]);
}

void		get_file(char *s, t_ssl *ssl)
{
	int	fd;
	char	*line;

	fd = open(s, O_RDONLY);
	line = copy_file_content(fd);
	ssl->input = ft_strdup(line);
	ssl->len = (ft_strlen(line));
}

int		get_flag(char *s, t_ssl *ssl)
{
	if (!ft_strcmp(s, "-p"))
		ssl->p = 1;
	else if (!ft_strcmp(s, "-r"))
		ssl->r = 1;
	else if (!ft_strcmp(s, "-q"))
		ssl->q = 1;
	else if (!ft_strcmp(s, "-s"))
		return (ssl->s = 2);
	else
		return (0);
	return (1);
}

int		get_model(char *s, t_ssl *ssl, int *i)
{
	if (!ft_strcmp(s, "md5"))
	{
		ssl->model = ft_strdup(s);
		++*i;
	}
	else if (!ft_strcmp(s, "sha256"))
	{
		ssl->model = ft_strdup(s);
		++*i;
	}
	else
		return (0);
	return (1);
}

