
#include "ssl.h"

void		init(t_ssl *ssl)
{
	ssl->len = 0;
	ssl->input = NULL;
	ssl->model = NULL;
	ssl->s = 0;
	ssl->p = 0;
	ssl->q = 0;
	ssl->r = 0;

}

void		save_content(int ar, char **av, t_ssl *ssl, int i)
{
	if (av[i] == NULL || ssl->p)
	{
		ssl->input = copy_file_content(0);
		ssl->len = ft_strlen(ssl->input);
		if (ssl->p)
			ft_putstr(ssl->input);
		!ft_strcmp(ssl->model, "md5") ? ft_md5(ssl) : ft_sha256(ssl);
	}
	while (i < ar)
	{
		if (ssl->s)
		{
			ssl->input = av[i];
			ssl->len = ft_strlen(av[i]);
		}
		else
			get_file(av[i], ssl);
		if (!ssl->r && !ssl->q)
			(ssl->s) ? printf("MD5 (\"%s\") = ", ssl->input) : printf("MD5 (%s) = ", ssl->input);
		!ft_strcmp(ssl->model, "md5") ? ft_md5(ssl) : ft_sha256(ssl);
		if (ssl->r && !ssl->q)
			(ssl->s) ? printf(" (\"%s\")\n", ssl->input) : printf(" %s\n", ssl->input);
		i++;
	}	
}

int		main(int ar, char **av)
{
	t_ssl	ssl;
	int		i;
	
	i = 1;
	init(&ssl);
	if (i < ar)
	{
		if (!get_model(av[i], &ssl, &i))
			return (0);
		while (i < ar && get_flag(av[i], &ssl))
		{
			get_flag(av[i], &ssl);
			if (get_flag(av[i], &ssl) == 2)
			{
				i++;
				break ;
			}
			i++;
		}
		save_content(ar, av, &ssl, i);
	}
	return (0);
}
