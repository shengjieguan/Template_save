#include "ft_md5.h"
#include "ssl.h"

void		md5_set(t_md5 *dgst, uint32_t *m, uint8_t g, int i)
{
	uint32_t	tmp;

	tmp = dgst->state[D];
	dgst->state[D] = dgst->state[C];
	dgst->state[C] = dgst->state[B];
	dgst->state[B] = dgst->state[B] + \
	L_ROT((dgst->state[A] + dgst->f + md5_g_k[i] + m[g]), g_s[i], 32);
	dgst->state[A] = tmp;
}

void			md5_compress(t_md5 *dgst, uint32_t *m, int i)
{
	uint8_t		g;

	if (i < 16)
	{
		dgst->f = _F(dgst->state[B], dgst->state[C], dgst->state[D]);
		g = i;
	}
	else if (i < 32)
	{
		dgst->f = _G(dgst->state[B], dgst->state[C], dgst->state[D]);
		g = (5 * i + 1) % 16;
	}
	else if (i < 48)
	{
		dgst->f = _H(dgst->state[B], dgst->state[C], dgst->state[D]);
		g = (3 * i + 5) % 16;
	}
	else
	{
		dgst->f = _I(dgst->state[B], dgst->state[C], dgst->state[D]);
		g = (7 * i) % 16;
	}
	md5_set(dgst, m, g, i);
}
void		md5_update(t_md5 *dgst, t_md5 *prev)
{
	int		i;

	i = -1;
	while (++i < 4)
		dgst->state[i] += prev->state[i];
	i = -1;
	while (++i < 4)
		prev->state[i] = dgst->state[i];
}

void		md5_init(t_md5 *dgst)
{
	dgst->state[A] = MD5_A;
	dgst->state[B] = MD5_B;
	dgst->state[C] = MD5_C;
	dgst->state[D] = MD5_D;
	dgst->f = 0;
}


void		md5_algorithm(unsigned char *m, uint32_t l, t_md5 *dgst)
{
	t_md5		prev;
	uint64_t	block;
	int		i;

	md5_init(dgst);
	md5_init(&prev);
	block = 0;
	while (block < l)
	{
		i = 0;
		while (i < 64)
		{
			md5_compress(dgst, (uint32_t *)(m + block), i);
			i++;
		}
		md5_update(dgst, &prev);
		block += 64;
	}
}

void		ft_md5(t_ssl *ssl)
{
	t_md5	dgst;

	pad_m(ssl->input, ssl);
	md5_algorithm(ssl->m, ssl->l, &dgst);
	change_Binary_and_print_hash(dgst.state, 16);
}
