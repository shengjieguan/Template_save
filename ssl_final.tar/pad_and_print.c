#include "ssl.h"

void		change_Binary_and_print_hash(uint32_t *state, uint8_t len)
{
	unsigned char	digest[len];
	unsigned int	i;
	unsigned int	j;

	j = 0;
	i = 0;
	while (j < len)
	{
		digest[j] = (unsigned char)(state[i] & 0xff);
		digest[j + 1] = (unsigned char)((state[i] >> 8) & 0xff);
		digest[j + 2] = (unsigned char)((state[i] >> 16) & 0xff);
		digest[j + 3] = (unsigned char)((state[i] >> 24) & 0xff);
		i++;
		j += 4;
	}
	i = 0;
	while (i < len)
		printf("%02x", digest[i++]);
}

void		pad_m(char *input, t_ssl *ssl)
{
	int	mod;

	mod = 64;
	ssl->l = ssl->len + 9;
	while (ssl->l % mod != 0)
		ssl->l += 1;
	ft_bzero(ssl->m, ssl->l);
	ft_memcpy(ssl->m, input, ssl->len);
	*(uint32_t *)(ssl->m + ssl->len) = 128;
	if (!ft_strcmp(ssl->model, "md5"))
		*(uint64_t *)(ssl->m + (ssl->l - 8)) = (8 * ssl->len);
	else
		*(uint64_t *)(ssl->m + (ssl->l - 8)) = swap_endian64(8 * ssl->len);
}

