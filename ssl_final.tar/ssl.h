# ifndef SSL_H
# define SSL_H
# include <fcnal.h>
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include "ft_sha256.h"
# include <stdint.h>
# include "ft_md5.h"
# include "libft/libft.h"

typedef struct		s_ssl
{
	char		*model;
	char		*input;
	unsigned char	m[99999];
	uint64_t	len;
	uint64_t	l;
	int		s;
	int		r;
	int		q;
	int		p;
}			t_ssl;

typedef struct		s_dgst
{
	uint32_t	state[8];
}			t_dgst;

typedef struct		s_md5
{
	uint32_t	state[4];
	uint32_t	f;
}			t_md5;


uint32_t		swap_endian32(uint32_t n);
uint64_t		swap_endian64(uint64_t n);
void			sha256_expand(uint32_t *m, uint32_t *w);
void			sha256_compress(t_dgst *dgst, uint32_t *m);
void			sha256_update(t_dgst *dgst, t_dgst *prev);
t_dgst			*sha256_init(t_dgst *dgst);
void			sha256_algorithm(unsigned char *m, uint64_t l, t_dgst *dgst);
void			ft_sha256(t_ssl *ssl);
void			change_Binary_and_print_hash(uint32_t *state, uint8_t len);
void			pad_m(char *input, t_ssl *ssl);
char			*copy_file_content(const int fd);
void			get_file(char *s, t_ssl *ssl);
int			get_flag(char *s, t_ssl *ssl);
int			get_model(char *s, t_ssl *ssl, int *i);
void			init(t_ssl *ssl);
void			md5_set(t_md5 *dgst, uint32_t *m, uint8_t g, int i);
void			md5_compress(t_md5 *dgst, uint32_t *m, int i);
void			md5_update(t_md5 *dgst, t_md5 *prev);
void			md5_init(t_md5 *dgst);
void			md5_algorithm(unsigned char *m, uint32_t l, t_md5 *dgst);
void			ft_md5(t_ssl *ssl);


#endif
