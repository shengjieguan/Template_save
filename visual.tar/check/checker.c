/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 14:36:45 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 14:36:48 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../public/public.h"

int		check_asc(t_stack *arr)
{
	int i;

	i = 0;
	if (arr->b_size != 0)
		return (0);
	while (i + 1 < arr->a_size)
	{
		if (arr->a[i] > arr->a[i + 1])
			return (0);
		i++;
	}
	return (1);
}

void	check_result(t_stack arr)
{
	char	*line;
	int		input;

	while (1)
	{
		input = 0;
		if ((get_next_line(0, &line) <= 0))
		{
			if (check_asc(&arr))
				write(1, "\033[0;32mOK\n", 10);
			else
				write(1, "\033[0;31mKO\n", 10);
			return ;
		}
		if ((input = check_input(line)) == 0)
		{
			write(1, "\033[0;31mError\n", 13);
			return ;
		}
		execute_input(input, &arr);
		free(line);
	}
}

int		main(int argc, char **argv)
{
	t_stack arr;

	if (argc == 1)
	{
		write(1, "Usage : ./checker [number]\n", 27);
		return (0);
	}
	arr = get_stack(&argv[1], argc - 1);
	check_result(arr);
	return (0);
}
