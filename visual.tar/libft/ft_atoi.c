/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 15:06:43 by zliew             #+#    #+#             */
/*   Updated: 2019/09/20 09:26:01 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_atoi(const char *str)
{
	unsigned int	a;
	int				neg;
	int				num;

	a = 0;
	neg = 0;
	num = 0;
	while (str[a] == ' ' || str[a] == '\t' || str[a] == '\n' ||
			str[a] == '\v' || str[a] == '\f' || str[a] == '\r')
		a++;
	if (str[a] == '+' || str[a] == '-')
	{
		if (str[a] == '-')
			neg = 1;
		a++;
	}
	while (str[a] != '\0' && (str[a] >= '0' && str[a] <= '9'))
	{
		num = (num * 10) + (str[a] - '0');
		a++;
	}
	if (neg == 1)
		num = num * -1;
	return (num);
}
