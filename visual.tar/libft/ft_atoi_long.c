/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_long.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 14:57:57 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 14:57:58 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

long int	ft_atoi_long(const char *str)
{
	unsigned int	a;
	int				neg;
	long int		num;

	a = 0;
	neg = 0;
	num = 0;
	while (str[a] == ' ' || str[a] == '\t' || str[a] == '\n' ||
			str[a] == '\v' || str[a] == '\f' || str[a] == '\r')
		a++;
	if (str[a] == '+' || str[a] == '-')
	{
		if (str[a] == '-')
			neg = 1;
		a++;
	}
	while (str[a] != '\0' && (str[a] >= '0' && str[a] <= '9'))
	{
		num = (num * 10) + (str[a] - '0');
		a++;
	}
	if (neg == 1)
		num = num * -1;
	return (num);
}
