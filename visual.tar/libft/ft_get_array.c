/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_array.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/18 19:04:13 by zliew             #+#    #+#             */
/*   Updated: 2019/09/20 10:05:19 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	**ft_get_array(char *str, char c, int split_count, int count)
{
	int		a;
	int		i;
	char	**array;

	a = 0;
	i = 0;
	if (!(array = malloc(sizeof(char*) * split_count + 1)))
		return (NULL);
	while (i < split_count && str[a])
	{
		while (str[a] == c && str[a])
			a++;
		while (str[a] != c && str[a])
		{
			count++;
			a++;
		}
		if (!(array[i] = malloc(sizeof(char) * (count + 1))))
			return (NULL);
		if (count == 0)
			array[i] = 0;
		i++;
		count = 0;
	}
	return (array);
}
