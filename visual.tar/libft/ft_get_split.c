/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_split.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/18 19:03:43 by zliew             #+#    #+#             */
/*   Updated: 2019/09/18 19:04:02 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_get_split(char *str, char c)
{
	int a;
	int count;

	a = 0;
	count = 0;
	if (!str || !c)
		return (0);
	if (str[a] != c)
	{
		a++;
		count++;
	}
	while (str[a])
	{
		a++;
		if (str[a - 1] == c && str[a] != c)
			count++;
	}
	return (count);
}
