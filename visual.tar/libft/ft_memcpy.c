/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 18:19:37 by zliew             #+#    #+#             */
/*   Updated: 2019/09/16 18:33:02 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dst, const void *src, size_t n)
{
	size_t				a;
	unsigned char		*ptr1;
	const unsigned char	*ptr2;

	a = 0;
	if (n == 0 || dst == src)
		return (dst);
	ptr1 = (unsigned char*)dst;
	ptr2 = (unsigned char*)src;
	while (a < n)
	{
		ptr1[a] = ptr2[a];
		a++;
	}
	return (dst);
}
