/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 21:13:44 by zliew             #+#    #+#             */
/*   Updated: 2019/09/16 21:22:09 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s1)
{
	char			*new;
	unsigned int	a;
	unsigned int	b;

	a = 0;
	b = 0;
	while (s1[a] != '\0')
		a++;
	if (!(new = (char*)malloc(sizeof(char) * (a + 1))))
		return (NULL);
	while (s1[b] != '\0')
	{
		new[b] = s1[b];
		b++;
	}
	new[b] = '\0';
	return (new);
}
