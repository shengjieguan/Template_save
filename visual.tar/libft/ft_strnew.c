/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 11:45:59 by zliew             #+#    #+#             */
/*   Updated: 2019/10/08 15:44:26 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnew(size_t size)
{
	char	*new;
	size_t	a;

	a = 0;
	if (!(new = (char*)malloc(sizeof(char) * size + 1)))
		return (NULL);
	while (a <= size)
	{
		new[a] = '\0';
		a++;
	}
	return (new);
}
