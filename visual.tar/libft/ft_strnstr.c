/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 09:27:40 by zliew             #+#    #+#             */
/*   Updated: 2019/09/17 09:40:50 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *src, const char *find, size_t len)
{
	unsigned int a;
	unsigned int b;

	if (!*find)
		return ((char*)src);
	a = 0;
	while (src[a] != '\0' && (size_t)a < len)
	{
		if (src[a] == find[0])
		{
			b = 1;
			while (find[b] != '\0' && src[a + b] == find[b] &&
					(size_t)(a + b) < len)
				b++;
			if (find[b] == '\0')
				return ((char*)&src[a]);
		}
		a++;
	}
	return (0);
}
