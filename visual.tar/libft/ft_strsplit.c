/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsplit.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 17:45:22 by zliew             #+#    #+#             */
/*   Updated: 2019/09/20 10:28:52 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	**ft_strsplit(char const *str, char c)
{
	int		i;
	int		count;
	int		split;
	char	**array;

	i = -1;
	if (!str || !c)
		return (NULL);
	split = ft_get_split((char*)str, c);
	if (!(array = ft_get_array((char*)str, c, split, 0)))
		return (NULL);
	while (i++ < split && *str && array[i])
	{
		count = 0;
		while (*str == c && *str)
			str++;
		while (*str != c && *str)
		{
			array[i][count] = *(str++);
			count++;
		}
		array[i][count] = '\0';
	}
	array[i] = NULL;
	return (array);
}
