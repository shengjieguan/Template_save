/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 21:49:15 by zliew             #+#    #+#             */
/*   Updated: 2019/09/17 09:27:03 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strstr(const char *src, const char *find)
{
	unsigned int a;
	unsigned int b;

	a = 0;
	if (!*find)
		return ((char*)src);
	while (src[a] != '\0')
	{
		if (src[a] == find[0])
		{
			b = 1;
			while (find[b] != '\0' && src[a + b] == find[b])
				b++;
			if (find[b] == '\0')
				return ((char*)&src[a]);
		}
		a++;
	}
	return (0);
}
