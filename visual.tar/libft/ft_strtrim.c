/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 15:38:10 by zliew             #+#    #+#             */
/*   Updated: 2019/09/20 10:15:47 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s)
{
	char	*result;
	int		i;
	int		len;
	int		a;

	a = -1;
	if (!s)
		return (NULL);
	len = ft_strlen((char*)s);
	i = 0;
	while (s[len - 1] == ' ' || s[len - 1] == '\t' || s[len - 1] == '\n')
		len--;
	while ((s[i] == ' ' || s[i] == '\t' || s[i] == '\n') && len > 0)
	{
		i++;
		len--;
	}
	if (!(result = (char*)malloc(sizeof(char) * (len + 1))))
		return (NULL);
	while (++a < len)
		result[a] = s[i + a];
	result[a] = '\0';
	return (result);
}
