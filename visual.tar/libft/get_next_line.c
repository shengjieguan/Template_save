/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/07 10:38:18 by zliew             #+#    #+#             */
/*   Updated: 2019/10/09 19:08:43 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static char	*declare(char **s, int fd)
{
	if (s[fd] == NULL)
	{
		s[fd] = ft_strnew(1);
	}
	return (s[fd]);
}

static char	*ft_join(char const *s1, char const *s2)
{
	char	*s3;
	char	*tmp;
	int		a;
	int		b;

	a = 0;
	b = 0;
	while (s1[a])
		a++;
	while (s2[b])
		b++;
	if (!s1 || !s2 || !(s3 = (char *)malloc(sizeof(char) * (a + b + 1))))
		return (NULL);
	tmp = s3;
	while (*s1 != '\0')
		*(tmp++) = *(s1++);
	while (*s2 != '\0')
		*(tmp++) = *(s2++);
	*tmp = '\0';
	return (s3);
}

int			get_line(char **s, char **line, int fd)
{
	int		leng;
	char	*tmp;
	int		a;

	leng = 0;
	a = 0;
	while (s[fd][leng] != '\n' && s[fd][leng] != '\0')
		leng++;
	if (s[fd][leng] == '\n')
	{
		*line = ft_strsub(s[fd], 0, leng);
		tmp = ft_strdup(s[fd] + leng + 1);
		free(s[fd]);
		s[fd] = tmp;
		a = 1;
	}
	else if (s[fd][leng] == '\0')
	{
		*line = ft_strdup(s[fd]);
		ft_strdel(&s[fd]);
	}
	if (a == 1 && s[fd][0] == '\0')
		ft_strdel(&s[fd]);
	return (1);
}

int			return_value(char **s, char **line, int fd, int a)
{
	if (a < 0)
		return (-1);
	else if (a == 0 && (s[fd] == NULL || s[fd][0] == '\0'))
		return (0);
	else
		return (get_line(s, line, fd));
}

int			get_next_line(const int fd, char **line)
{
	t_var		var;
	static char	*s[4096];

	if (fd < 0 || line == NULL)
		return (-1);
	while ((var.a = read(fd, var.buff, BUFF_SIZE)) > 0)
	{
		var.buff[var.a] = '\0';
		s[fd] = declare(s, fd);
		var.tmp = ft_join(s[fd], var.buff);
		free(s[fd]);
		s[fd] = var.tmp;
		if (ft_strchr(var.buff, '\n'))
			break ;
	}
	return (return_value(s, line, fd, var.a));
}
