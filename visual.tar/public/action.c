/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   action.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 15:07:18 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 15:07:20 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "public.h"

void	swap(int *swap, int size)
{
	int tmp;

	if (size < 2)
		return ;
	tmp = swap[0];
	swap[0] = swap[1];
	swap[1] = tmp;
}

void	push(int *push, int *receive, int *p_size, int *r_size)
{
	int tmp;
	int i;

	i = 0;
	if (*p_size < 1)
		return ;
	while (i < *r_size)
	{
		tmp = receive[i + 1];
		receive[i + 1] = receive[0];
		receive[0] = tmp;
		i++;
	}
	receive[0] = push[0];
	*r_size += 1;
	i = 0;
	while (i + 1 < *p_size)
	{
		push[i] = push[i + 1];
		i++;
	}
	*p_size -= 1;
}

void	rotate(int *rot, int size)
{
	int i;
	int tmp;

	i = 0;
	if (size < 2)
		return ;
	tmp = rot[i];
	while (i + 1 < size)
	{
		rot[i] = rot[i + 1];
		i++;
	}
	rot[i] = tmp;
}

void	re_rotate(int *rot, int size)
{
	int i;
	int tmp;

	i = 0;
	if (size < 2)
		return ;
	i = size - 1;
	tmp = rot[i];
	while (i > 0)
	{
		rot[i] = rot[i - 1];
		i--;
	}
	rot[0] = tmp;
}
