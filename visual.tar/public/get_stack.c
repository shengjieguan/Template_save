/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_stack.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 15:35:54 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 15:35:55 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "public.h"

int		check_valid(char *s)
{
	long int a;

	a = 0;
	while (s[a] != '\0')
	{
		if (s[a] < '0' || s[a] > '9')
			return (1);
		a++;
	}
	a = ft_atoi_long(s);
	if (a < -2147483648 || a > 2147483647)
		return (1);
	return (0);
}

void	check_dup(t_stack *arr)
{
	int a;
	int b;

	a = 0;
	while (a + 1 < arr->size)
	{
		b = a + 1;
		while (b < arr->size)
		{
			if (arr->a[a] == arr->a[b])
			{
				write(1, "\033[0;31mError\n", 13);
				exit(0);
			}
			b++;
		}
		a++;
	}
}

t_stack	get_stack(char **s, int size)
{
	int		i;
	t_stack	arr;

	arr.a_size = size;
	arr.b_size = 0;
	arr.size = size;
	arr.biggest = 0;
	arr.a = malloc(sizeof(int) * arr.a_size);
	arr.b = malloc(sizeof(int) * arr.a_size);
	arr.sort = malloc(sizeof(int) * arr.a_size);
	i = 0;
	while (s[i] != '\0')
	{
		if (check_valid(s[i]))
		{
			write(1, "\033[0;31mError\n", 13);
			exit(0);
		}
		arr.a[i] = ft_atoi(s[i]);
		arr.sort[i] = arr.a[i];
		arr.biggest = (arr.a[i] > arr.biggest) ? arr.a[i] : arr.biggest;
		i++;
	}
	check_dup(&arr);
	return (arr);
}
