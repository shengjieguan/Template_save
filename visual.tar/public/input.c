/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 15:34:45 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 15:34:46 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "public.h"

int		check_input(char *s)
{
	if (ft_strsr(s, "sa"))
		return (1);
	else if (ft_strsr(s, "sb"))
		return (2);
	else if (ft_strsr(s, "ss"))
		return (3);
	else if (ft_strsr(s, "pa"))
		return (4);
	else if (ft_strsr(s, "pb"))
		return (5);
	else if (ft_strsr(s, "ra"))
		return (6);
	else if (ft_strsr(s, "rb"))
		return (7);
	else if (ft_strsr(s, "rr"))
		return (8);
	else if (ft_strsr(s, "rra"))
		return (9);
	else if (ft_strsr(s, "rrb"))
		return (10);
	else if (ft_strsr(s, "rrr"))
		return (11);
	return (0);
}

void	execute_input(int input, t_stack *arr)
{
	if (input == 1 || input == 3)
		swap(arr->a, arr->a_size);
	if (input == 2 || input == 3)
		swap(arr->b, arr->b_size);
	if (input == 4)
		push(arr->b, arr->a, &arr->b_size, &arr->a_size);
	if (input == 5)
		push(arr->a, arr->b, &arr->a_size, &arr->b_size);
	if (input == 6 || input == 8)
		rotate(arr->a, arr->a_size);
	if (input == 7 || input == 8)
		rotate(arr->b, arr->b_size);
	if (input == 9 || input == 11)
		re_rotate(arr->a, arr->a_size);
	if (input == 10 || input == 11)
		re_rotate(arr->b, arr->b_size);
}
