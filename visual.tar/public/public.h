/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   public.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 15:45:06 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 15:45:07 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUBLIC_H
# define PUBLIC_H
# include "../libft/libft.h"

typedef struct	s_stack
{
	int	*a;
	int	*b;
	int	*sort;
	int	a_size;
	int	b_size;
	int	size;
	int	biggest;
}				t_stack;

int				check_valid(char *s);
int				check_input(char *s);
void			execute_input(int input, t_stack *arr);
void			swap(int *swap, int size);
void			push(int *push, int *receive, int *p_size, int *r_size);
void			rotate(int *rot, int size);
void			re_rotate(int *rot, int size);
t_stack			get_stack(char **s, int size);

#endif
