/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   action.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 19:13:30 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 19:13:31 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int		check_asc(t_stack *arr)
{
	int i;

	i = 0;
	if (arr->b_size != 0)
		return (0);
	while (i + 1 < arr->a_size)
	{
		if (arr->a[i] > arr->a[i + 1])
			return (0);
		i++;
	}
	return (1);
}

void	swap(int *swap, int size, int choice)
{
	int tmp;

	if (size < 2)
		return ;
	tmp = swap[0];
	swap[0] = swap[1];
	swap[1] = tmp;
	if (choice == 1)
		write(1, "sa\n", 3);
	else if (choice == 2)
		write(1, "sb\n", 3);
}

void	swap_both(t_stack *arr)
{
	swap(arr->a, arr->a_size, 0);
	swap(arr->b, arr->b_size, 0);
	write(1, "ss\n", 3);
}

void	push_a(int *push, int *receive, int *p_size, int *r_size)
{
	int tmp;
	int i;

	i = 0;
	if (*p_size < 1)
		return ;
	while (i < *r_size)
	{
		tmp = receive[i + 1];
		receive[i + 1] = receive[0];
		receive[0] = tmp;
		i++;
	}
	receive[0] = push[0];
	*r_size += 1;
	i = 0;
	while (i + 1 < *p_size)
	{
		push[i] = push[i + 1];
		i++;
	}
	*p_size -= 1;
	write(1, "pa\n", 3);
}

void	push_b(int *push, int *receive, int *p_size, int *r_size)
{
	int tmp;
	int i;

	i = 0;
	if (*p_size < 1)
		return ;
	while (i < *r_size)
	{
		tmp = receive[i + 1];
		receive[i + 1] = receive[0];
		receive[0] = tmp;
		i++;
	}
	receive[0] = push[0];
	*r_size += 1;
	i = 0;
	while (i + 1 < *p_size)
	{
		push[i] = push[i + 1];
		i++;
	}
	*p_size -= 1;
	write(1, "pb\n", 3);
}
