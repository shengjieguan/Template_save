/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   action2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 19:15:02 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 19:15:03 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	check_dup(t_stack *arr)
{
	int a;
	int b;

	a = 0;
	while (a + 1 < arr->size)
	{
		b = a + 1;
		while (b < arr->size)
		{
			if (arr->a[a] == arr->a[b])
			{
				write(1, "\033[0;31mError\n", 13);
				exit(0);
			}
			b++;
		}
		a++;
	}
}

void	rotate(int *rot, int size, int choice)
{
	int i;
	int tmp;

	i = 0;
	if (size < 2)
		return ;
	tmp = rot[i];
	while (i + 1 < size)
	{
		rot[i] = rot[i + 1];
		i++;
	}
	rot[i] = tmp;
	if (choice == 1)
		write(1, "ra\n", 3);
	else if (choice == 2)
		write(1, "rb\n", 3);
}

void	rotate_both(t_stack *arr)
{
	rotate(arr->a, arr->a_size, 0);
	rotate(arr->b, arr->b_size, 0);
	write(1, "rr\n", 3);
}

void	re_rotate(int *rot, int size, int choice)
{
	int i;
	int tmp;

	i = 0;
	if (size < 2)
		return ;
	i = size - 1;
	tmp = rot[i];
	while (i > 0)
	{
		rot[i] = rot[i - 1];
		i--;
	}
	rot[0] = tmp;
	if (choice == 1)
		write(1, "rra\n", 4);
	else if (choice == 2)
		write(1, "rrb\n", 4);
}

void	re_rotate_both(t_stack *arr)
{
	re_rotate(arr->a, arr->a_size, 0);
	re_rotate(arr->b, arr->b_size, 0);
	write(1, "rrr\n", 4);
}
