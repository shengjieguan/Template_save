/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 17:08:52 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 17:08:53 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int		check_valid(char *s)
{
	long int a;

	a = 0;
	while (s[a] != '\0')
	{
		if (s[a] < '0' || s[a] > '9')
			return (1);
		a++;
	}
	a = ft_atoi_long(s);
	if (a < -2147483648 || a > 2147483647)
		return (1);
	return (0);
}

t_stack	get_stack(char **s, int size)
{
	int		i;
	t_stack	arr;

	arr.a_size = size;
	arr.size = size;
	arr.b_size = 0;
	arr.a = malloc(sizeof(int) * arr.a_size);
	arr.b = malloc(sizeof(int) * arr.a_size);
	arr.sort = malloc(sizeof(int) * arr.a_size);
	i = 0;
	while (s[i] != '\0')
	{
		if (check_valid(s[i]))
		{
			write(1, "\033[0;31mError\n", 13);
			exit(0);
		}
		arr.a[i] = ft_atoi(s[i]);
		arr.sort[i] = arr.a[i];
		i++;
	}
	check_dup(&arr);
	return (arr);
}

void	sort_arr(t_stack *arr)
{
	int find;

	if (arr->a_size == 1 || check_asc(arr))
		return ;
	else if (arr->a_size <= 3)
		sort_size_3(arr);
	else if (arr->a_size <= 5)
		sort_size_5(arr);
	else if (arr->a_size <= 99)
		sort_size_small(arr);
	else
	{
		find = sort_first_half(arr);
		sort_second_half(arr, find);
	}
}

void	get_sort(t_stack *arr)
{
	int tmp;
	int i;

	i = 0;
	while (i + 1 < arr->a_size)
	{
		if (arr->sort[i] > arr->sort[i + 1])
		{
			tmp = arr->sort[i];
			arr->sort[i] = arr->sort[i + 1];
			arr->sort[i + 1] = tmp;
			i = 0;
		}
		else
			i++;
	}
}

int		main(int argc, char **argv)
{
	t_stack	arr;

	if (argc == 1)
	{
		write(1, "Usage : ./push_swap [number]\n", 29);
		return (0);
	}
	arr = get_stack(&argv[1], argc - 1);
	get_sort(&arr);
	sort_arr(&arr);
	return (0);
}
