/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/19 10:35:15 by zliew             #+#    #+#             */
/*   Updated: 2019/12/19 10:35:16 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H
# include "../libft/libft.h"

typedef struct	s_stack
{
	int *a;
	int *b;
	int *sort;
	int a_size;
	int b_size;
	int size;
}				t_stack;

typedef struct	s_sort
{
	int i;
	int first;
	int find;
	int tmp;
	int mid;
	int mid_fix;
	int last;
	int pivot_next;
	int pivot;
	int pivot_start;
	int pivot_add;
	int times;
	int rotate_back;
}				t_sort;

typedef struct	s_big
{
	int a;
	int tmp;
	int mid;
	int count;
	int find;
	int chunks_size;
	int pivot;
	int pivot_start;
	int rotate_back;
}				t_big;

void			swap(int *swap, int size, int choice);
void			swap_both(t_stack *arr);
void			push_a(int *push, int *receive, int *p_size, int *r_size);
void			push_b(int *push, int *receive, int *p_size, int *r_size);
void			rotate(int *rot, int size, int choice);
void			rotate_both(t_stack *arr);
void			re_rotate(int *rot, int size, int choice);
void			re_rotate_both(t_stack *arr);
void			sort_size_3(t_stack *arr);
void			sort_size_5(t_stack *arr);
int				sort_first_half(t_stack *arr);
void			sort_first_chunk(t_stack *arr, t_big *var);
void			sort_chunks(t_stack *arr, t_big *var);
void			rotate_chunks(t_stack *arr, t_big *var);
void			push_sec_half(t_stack *arr, t_big *var);
void			return_chunks_sec(t_stack *arr, t_big *var);
void			sort_sec_first_chunk(t_stack *arr, t_big *var);
void			rotate_sec_chunks(t_stack *arr, t_big *var, int flag);
void			sort_sec_chunks(t_stack *arr, t_big *var);
void			sort_size_small(t_stack *arr);
void			rotate_to_b(t_stack *arr, t_sort *var);
void			rotate_a_back(t_stack *arr, t_sort *var);
void			sort_b(t_stack *arr, t_sort *var);
int				check_asc(t_stack *arr);
void			sort_second_half(t_stack *arr, int find);
void			rotate_big_a_back(t_stack *arr, t_big *var);
void			check_dup(t_stack *arr);

#endif
