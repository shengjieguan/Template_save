/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_3n5.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 17:29:58 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 17:30:00 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	sort_size_3(t_stack *arr)
{
	if (arr->a_size == 2)
		swap(arr->a, arr->a_size, 1);
	else
	{
		if (arr->a[0] > arr->a[1])
		{
			if (arr->a[0] < arr->a[2])
				swap(arr->a, arr->a_size, 1);
			else
				rotate(arr->a, arr->a_size, 1);
			if (arr->a[0] > arr->a[1])
				swap(arr->a, arr->a_size, 1);
		}
		else if (arr->a[0] < arr->a[1])
		{
			re_rotate(arr->a, arr->a_size, 1);
			if (arr->a[0] > arr->a[1])
				swap(arr->a, arr->a_size, 1);
		}
	}
}

void	sort_remain(t_stack *arr)
{
	int i;

	i = 0;
	while (i + 1 < arr->a_size)
	{
		if (arr->a[i] > arr->a[i + 1])
		{
			sort_size_3(arr);
			break ;
		}
		i++;
	}
	push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
	push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
	if (arr->a[0] > arr->a[1])
		swap(arr->a, arr->a_size, 1);
}

void	sort_size_5(t_stack *arr)
{
	int i;
	int pivot;
	int mid;

	i = 0;
	mid = (arr->a_size % 2 == 0) ? arr->a_size / 2 : (arr->a_size - 1) / 2;
	pivot = (arr->a_size % 2 == 0) ? arr->sort[mid] : arr->sort[mid];
	while (i < arr->a_size)
	{
		if (arr->a[i] < pivot)
		{
			if (i == 0)
				push_b(arr->a, arr->b, &arr->a_size, &arr->b_size);
			else
				rotate(arr->a, arr->a_size, 1);
			i = 0;
		}
		else
			i++;
	}
	sort_remain(arr);
}
