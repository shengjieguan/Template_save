/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_first_half.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 21:11:36 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 21:11:37 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	declare_var_first(t_stack *arr, t_big *var)
{
	var->a = 0;
	var->find = 0;
	var->rotate_back = 0;
	var->pivot = arr->sort[arr->size / 2];
	var->pivot_start = arr->sort[0] - 1;
	if (arr->size / 2 <= 50)
		var->chunks_size = (arr->size / 4) - 8;
	else
		var->chunks_size = 40;
}

void	push_half(t_stack *arr, t_big *var)
{
	while (var->a < arr->a_size)
	{
		if (arr->a[var->a] > var->pivot_start && arr->a[var->a] < var->pivot)
		{
			if (var->a == 0)
				push_b(arr->a, arr->b, &arr->a_size, &arr->b_size);
			else
			{
				if (arr->b_size >= 2)
				{
					if (arr->b[0] < arr->sort[arr->size / 4])
						rotate_both(arr);
					else
						rotate(arr->a, arr->a_size, 1);
				}
				else
					rotate(arr->a, arr->a_size, 1);
			}
			var->a = 0;
		}
		else
			var->a++;
	}
}

void	return_chunks(t_stack *arr, t_big *var)
{
	var->pivot = arr->size / 2 - var->chunks_size;
	var->count = var->chunks_size;
	while (arr->b_size > 0)
	{
		if (var->pivot <= 0)
			break ;
		if (arr->b[0] == arr->sort[var->find])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			rotate(arr->a, arr->a_size, 1);
			var->find++;
		}
		else if (arr->b[0] >= arr->sort[var->pivot])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->count--;
			if (var->count == 0)
			{
				var->count = var->chunks_size;
				var->pivot -= var->chunks_size;
			}
		}
		else
			rotate(arr->b, arr->b_size, 2);
	}
}

void	check_stack(t_stack *arr, t_big *var)
{
	var->a = 0;
	while (var->a < arr->a_size)
	{
		if (arr->a[0] == arr->sort[var->find])
		{
			rotate(arr->a, arr->a_size, 1);
			var->pivot_start = arr->sort[var->find];
			var->find++;
			var->a = 0;
		}
		else
			var->a++;
	}
}

int		sort_first_half(t_stack *arr)
{
	t_big var;

	declare_var_first(arr, &var);
	push_half(arr, &var);
	return_chunks(arr, &var);
	sort_first_chunk(arr, &var);
	check_stack(arr, &var);
	while (var.find < arr->size / 2)
	{
		var.pivot = var.chunks_size / 2;
		if (var.find + var.pivot >= arr->size / 2 ||
			var.find + (var.pivot * 2) >= arr->size / 2)
		{
			var.pivot = (arr->size / 2) - var.find;
		}
		var.tmp = var.pivot - 1;
		rotate_chunks(arr, &var);
		rotate_big_a_back(arr, &var);
		sort_chunks(arr, &var);
		check_stack(arr, &var);
	}
	return (var.find);
}
