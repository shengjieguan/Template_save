/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_first_half2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 21:45:14 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 21:45:15 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	sort_chunks_ft(t_stack *arr, t_big *var)
{
	if (var->a == 0)
	{
		push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
		rotate(arr->a, arr->a_size, 1);
		var->find++;
		var->tmp--;
	}
	else if (var->a == 1 && arr->b[0] == arr->sort[var->a + 1])
		swap(arr->b, arr->b_size, 2);
	else if (var->a > var->mid)
		re_rotate(arr->b, arr->b_size, 2);
	else
		rotate(arr->b, arr->b_size, 2);
	var->a = 0;
}

void	sort_first_chunk(t_stack *arr, t_big *var)
{
	var->a = 0;
	var->tmp = 1;
	while (arr->b_size > 0)
	{
		var->mid = (arr->b_size % 2 == 0) ?
					arr->b_size / 2 : (arr->b_size - 1) / 2;
		if (arr->b[0] == arr->sort[var->chunks_size - var->tmp])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->tmp++;
			var->a = 0;
		}
		if (arr->b[var->a] == arr->sort[var->find])
			sort_chunks_ft(arr, var);
		else
			var->a++;
	}
}

void	sort_chunks(t_stack *arr, t_big *var)
{
	var->a = 0;
	while (arr->b_size > 0)
	{
		var->mid = (arr->b_size % 2 == 0) ?
					arr->b_size / 2 : (arr->b_size - 1) / 2;
		if (arr->b[0] == arr->sort[var->find + var->tmp])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->tmp--;
			var->a = 0;
		}
		else if (arr->b[var->a] == arr->sort[var->find])
			sort_chunks_ft(arr, var);
		else
			var->a++;
	}
}

void	rotate_chunks2(t_stack *arr, t_big *var)
{
	if (var->a == 0)
		push_b(arr->a, arr->b, &arr->a_size, &arr->b_size);
	else
	{
		var->rotate_back++;
		if (arr->b_size >= 2)
		{
			if (arr->b[0] < arr->sort[arr->size / 4])
				rotate_both(arr);
			else
				rotate(arr->a, arr->a_size, 1);
		}
		else
			rotate(arr->a, arr->a_size, 1);
	}
	var->a = 0;
}

void	rotate_chunks(t_stack *arr, t_big *var)
{
	var->a = 0;
	while (var->a < arr->a_size)
	{
		if (var->rotate_back == 0 && arr->a[0] == arr->sort[var->find])
		{
			rotate(arr->a, arr->a_size, 1);
			var->find++;
			var->pivot--;
			var->tmp--;
			var->a = 0;
		}
		if (arr->a[var->a] > arr->sort[var->find - 1] &&
			arr->a[var->a] < arr->sort[var->find + var->pivot])
			rotate_chunks2(arr, var);
		else
			var->a++;
	}
}
