/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_sec_half.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 21:47:38 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 21:47:39 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int		declare_var_sec(t_stack *arr, t_big *var, int find)
{
	var->a = 0;
	var->rotate_back = 0;
	var->find = find;
	if (arr->size / 2 <= 50)
		var->chunks_size = arr->size / 4;
	else
		var->chunks_size = 40;
	if (var->chunks_size >= 25)
		var->pivot = arr->sort[arr->size - var->chunks_size];
	else
		var->pivot = arr->sort[arr->size - 1] + 1;
	var->pivot_start = arr->sort[var->find] - 1;
	return (0);
}

void	check_stack_sec(t_stack *arr, t_big *var)
{
	var->a = 0;
	while (var->a < arr->a_size)
	{
		if (arr->a[0] == arr->sort[var->find])
		{
			rotate(arr->a, arr->a_size, 1);
			var->pivot_start = arr->sort[var->find];
			var->find++;
			var->a = 0;
		}
		else
			var->a++;
	}
}

void	sort_second_half(t_stack *arr, int find)
{
	int		flag;
	t_big	var;

	flag = declare_var_sec(arr, &var, find);
	push_sec_half(arr, &var);
	rotate_big_a_back(arr, &var);
	return_chunks_sec(arr, &var);
	sort_sec_first_chunk(arr, &var);
	check_stack_sec(arr, &var);
	while (var.find < arr->size)
	{
		var.count = var.chunks_size / 2;
		var.pivot = var.find + (var.chunks_size / 2);
		if (var.find + (var.chunks_size / 2) >= arr->size)
		{
			var.count = arr->size - var.find;
			var.pivot = arr->size - 1;
			flag = 1;
		}
		var.tmp = var.count - 1;
		rotate_sec_chunks(arr, &var, flag);
		rotate_big_a_back(arr, &var);
		sort_sec_chunks(arr, &var);
		check_stack_sec(arr, &var);
	}
}
