/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_sec_half2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/19 10:25:52 by zliew             #+#    #+#             */
/*   Updated: 2019/12/19 10:25:53 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	push_sec_half2(t_stack *arr, t_big *var)
{
	if (var->a == 0)
		push_b(arr->a, arr->b, &arr->a_size, &arr->b_size);
	else
	{
		var->rotate_back++;
		if (arr->b_size >= 2)
		{
			if (arr->b[0] < arr->sort[(arr->size / 2)
				+ (arr->size / 4)])
				rotate_both(arr);
			else
				rotate(arr->a, arr->a_size, 1);
		}
		else
			rotate(arr->a, arr->a_size, 1);
	}
	var->a = 0;
}

void	push_sec_half(t_stack *arr, t_big *var)
{
	while (var->a < arr->a_size)
	{
		if (var->rotate_back == 0 && arr->a[0] == arr->sort[var->find])
		{
			if (arr->b_size >= 2)
			{
				if (arr->b[0] < arr->sort[(arr->size / 2) + (arr->size / 4)])
					rotate_both(arr);
				else
					rotate(arr->a, arr->a_size, 1);
			}
			else
				rotate(arr->a, arr->a_size, 1);
			var->pivot_start = arr->sort[var->find];
			var->find++;
		}
		if (arr->a[var->a] > var->pivot_start && arr->a[var->a] < var->pivot)
			push_sec_half2(arr, var);
		else
			var->a++;
	}
}

void	return_chunks_sec(t_stack *arr, t_big *var)
{
	var->pivot = arr->size - (var->chunks_size * 2);
	var->count = var->chunks_size;
	while (arr->b_size > 0)
	{
		if (var->pivot <= arr->size / 2)
			break ;
		if (arr->b[0] == arr->sort[var->find])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			rotate(arr->a, arr->a_size, 1);
			var->find++;
		}
		else if (arr->b[0] >= arr->sort[var->pivot])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->count--;
			if (var->count == 0)
			{
				var->count = var->chunks_size;
				var->pivot -= var->chunks_size;
			}
		}
		else
			rotate(arr->b, arr->b_size, 2);
	}
}

void	sort_sec_first_chunk2(t_stack *arr, t_big *var)
{
	if (var->a == 0)
	{
		push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
		rotate(arr->a, arr->a_size, 1);
		var->find++;
	}
	else if (var->a == 1 && arr->b[0] == arr->sort[var->find + 1])
		swap(arr->b, arr->b_size, 2);
	else if (var->a > var->mid)
		re_rotate(arr->b, arr->b_size, 2);
	else
		rotate(arr->b, arr->b_size, 2);
	var->a = 0;
}

void	sort_sec_first_chunk(t_stack *arr, t_big *var)
{
	var->a = 0;
	var->tmp = 1;
	while (arr->b_size > 0)
	{
		var->mid = (arr->b_size % 2 == 0) ?
					arr->b_size / 2 : (arr->b_size - 1) / 2;
		if (arr->a[0] == arr->sort[var->find])
		{
			rotate(arr->a, arr->a_size, 1);
			var->find++;
			var->tmp--;
			var->a = 0;
		}
		if (arr->b[0] == arr->sort[(arr->size / 2)
			+ var->chunks_size - var->tmp])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->tmp++;
			var->a = 0;
		}
		if (arr->b[var->a] == arr->sort[var->find])
			sort_sec_first_chunk2(arr, var);
		else
			var->a++;
	}
}
