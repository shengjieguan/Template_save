/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_sec_half3.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/19 10:27:46 by zliew             #+#    #+#             */
/*   Updated: 2019/12/19 10:27:47 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	rotate_big_a_back(t_stack *arr, t_big *var)
{
	while (var->rotate_back > 0)
	{
		re_rotate(arr->a, arr->a_size, 1);
		var->rotate_back--;
	}
}

void	rotate_sec_chunks2(t_stack *arr, t_big *var)
{
	if (var->a == 0)
		push_b(arr->a, arr->b, &arr->a_size, &arr->b_size);
	else
	{
		var->rotate_back++;
		if (arr->b_size >= 2)
		{
			if (arr->b[0] < arr->sort[arr->size / 4])
				rotate_both(arr);
			else
				rotate(arr->a, arr->a_size, 1);
		}
		else
			rotate(arr->a, arr->a_size, 1);
	}
	var->a = 0;
}

void	rotate_sec_chunks(t_stack *arr, t_big *var, int flag)
{
	var->a = 0;
	while (var->a < arr->a_size)
	{
		if (var->rotate_back == 0 && arr->a[0] == arr->sort[var->find])
		{
			rotate(arr->a, arr->a_size, 1);
			var->find++;
			var->tmp--;
			var->a = 0;
		}
		if (arr->a[var->a] > arr->sort[var->find - 1] &&
			arr->a[var->a] < arr->sort[var->pivot] + flag)
			rotate_sec_chunks2(arr, var);
		else
			var->a++;
	}
}

void	sort_sec_chunks2(t_stack *arr, t_big *var)
{
	if (var->a == 0)
	{
		push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
		rotate(arr->a, arr->a_size, 1);
		var->find++;
		var->tmp--;
	}
	else if (var->a == 1 && arr->b[0] == arr->sort[var->a + 1])
		swap(arr->b, arr->b_size, 2);
	else if (var->a > var->mid)
		re_rotate(arr->b, arr->b_size, 2);
	else
		rotate(arr->b, arr->b_size, 2);
	var->a = 0;
}

void	sort_sec_chunks(t_stack *arr, t_big *var)
{
	var->a = 0;
	while (arr->b_size > 0)
	{
		var->mid = (arr->b_size % 2 == 0) ?
					arr->b_size / 2 : (arr->b_size - 1) / 2;
		if (arr->a[0] == arr->sort[var->find])
		{
			rotate(arr->a, arr->a_size, 1);
			var->find++;
			var->tmp--;
			var->a = 0;
		}
		if (arr->b[0] == arr->sort[var->find + var->tmp])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->tmp--;
			var->a = 0;
		}
		else if (arr->b[var->a] == arr->sort[var->find])
			sort_sec_chunks2(arr, var);
		else
			var->a++;
	}
}
