/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_small.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 19:23:36 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 19:23:38 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int		chunks(t_stack *arr)
{
	int tmp;
	int times;

	times = 3;
	if (arr->size <= 50)
		times = 2;
	else if (arr->size >= 100)
	{
		tmp = arr->size / 100;
		times += tmp;
	}
	return (times);
}

t_sort	declare_var(t_stack *arr)
{
	t_sort var;

	var.find = 0;
	var.first = 0;
	var.tmp = 1;
	var.times = chunks(arr);
	if (arr->size % var.times != 0)
		var.pivot_add += 1;
	else
		var.pivot_add = arr->size / var.times;
	var.mid_fix = var.pivot_add;
	var.pivot_start = arr->sort[0] - 1;
	return (var);
}

void	finish_touch(t_stack *arr, t_sort *var)
{
	var->i = 0;
	while (var->i < arr->a_size)
	{
		if (arr->a[0] == arr->sort[var->find])
		{
			rotate(arr->a, arr->a_size, 1);
			var->pivot_start = arr->sort[var->find];
			var->find++;
			var->i = 0;
		}
		else
			var->i++;
	}
	var->mid_fix += var->pivot_add;
	var->tmp = 1;
	if (var->mid_fix >= arr->size)
	{
		var->tmp = 0;
		var->mid_fix = arr->size - 1;
	}
	var->times--;
	var->first = 1;
}

void	sort_size_small(t_stack *arr)
{
	t_sort var;

	var = declare_var(arr);
	while (var.times > 0)
	{
		var.pivot = arr->sort[var.mid_fix];
		if (var.times == 1)
			var.pivot += 1;
		if (var.mid_fix + var.pivot_add <= arr->size)
			var.pivot_next = arr->sort[var.mid_fix + var.pivot_add];
		else
			var.pivot_next = var.pivot + 1;
		if (var.first == 0)
			var.pivot_next = arr->sort[arr->size / 2];
		var.rotate_back = 0;
		var.i = 0;
		rotate_to_b(arr, &var);
		rotate_a_back(arr, &var);
		sort_b(arr, &var);
		finish_touch(arr, &var);
	}
}
