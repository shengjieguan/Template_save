/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_small2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 20:55:15 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 20:55:16 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	rotate_to_b2(t_stack *arr, t_sort *var)
{
	if (var->i == 0)
		push_b(arr->a, arr->b, &arr->a_size, &arr->b_size);
	else
	{
		if (var->first == 1)
			var->rotate_back++;
		if (arr->b_size >= 2 && arr->b[0] >
			arr->sort[(var->mid_fix - (var->pivot_add / 2))])
			rotate_both(arr);
		else
			rotate(arr->a, arr->a_size, 1);
	}
	var->i = 0;
}

void	rotate_to_b(t_stack *arr, t_sort *var)
{
	while (var->i < arr->a_size)
	{
		if (var->first == 1 && var->rotate_back == 0 &&
			arr->a[0] == arr->sort[var->find])
		{
			if (arr->b_size >= 2 && arr->b[0] >
				arr->sort[(var->mid_fix - (var->pivot_add / 2))])
				rotate_both(arr);
			else
				rotate(arr->a, arr->a_size, 1);
			var->pivot_start = arr->sort[var->find];
			var->find++;
			var->i = 0;
		}
		else if (arr->a[0] > var->pivot - 1 && arr->a[0] < var->pivot_next)
		{
			push_b(arr->a, arr->b, &arr->a_size, &arr->b_size);
			var->i = 0;
		}
		else if (arr->a[var->i] > var->pivot_start
					&& arr->a[var->i] < var->pivot)
			rotate_to_b2(arr, var);
		else
			var->i++;
	}
}

void	rotate_a_back(t_stack *arr, t_sort *var)
{
	while (var->rotate_back > 0)
	{
		re_rotate(arr->a, arr->a_size, 1);
		var->rotate_back--;
	}
}

void	sort_b2(t_stack *arr, t_sort *var)
{
	if (var->i == 0)
	{
		push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
		rotate(arr->a, arr->a_size, 1);
		var->pivot_start = arr->sort[var->find];
		var->find++;
	}
	else if (var->i == 1 && arr->b[0] == arr->sort[var->find + 1])
		swap(arr->b, arr->b_size, 2);
	else if (var->i > var->mid)
		re_rotate(arr->b, arr->b_size, 2);
	else
		rotate(arr->b, arr->b_size, 2);
	var->i = 0;
}

void	sort_b(t_stack *arr, t_sort *var)
{
	var->i = 0;
	while (arr->b_size > 0)
	{
		var->mid = (arr->b_size % 2 == 0) ?
					arr->b_size / 2 : (arr->b_size - 1) / 2;
		if (arr->b[0] >= var->pivot && arr->b[0] < var->pivot_next)
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->i = 0;
		}
		if (arr->b[0] == arr->sort[var->mid_fix - var->tmp])
		{
			push_a(arr->b, arr->a, &arr->b_size, &arr->a_size);
			var->tmp++;
			var->i = 0;
		}
		if (arr->b[var->i] == arr->sort[var->find])
			sort_b2(arr, var);
		else
			var->i++;
	}
}
