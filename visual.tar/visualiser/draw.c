/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 15:17:02 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 15:17:03 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "visual.h"

t_color	declare_color(int red, int green, int blue)
{
	t_color	color;

	color.red = red;
	color.green = green;
	color.blue = blue;
	return (color);
}

int		get_pos(int x, t_stack arr)
{
	int a;

	a = 0;
	while (a < arr.size)
	{
		if (arr.sort[a] == x)
		{
			if (a > arr.size / 2)
				return (1);
			else
				return (0);
		}
		a++;
	}
	return (-1);
}

t_color	color_array(int stack, int x, t_stack arr)
{
	t_color	color;
	int		pos;

	pos = -1;
	color = declare_color(64, 64, 64);
	if (x < WIN_WIDTH / 2 && arr.a_size > stack)
	{
		if (x < arr.a[stack] * ((WIN_WIDTH / 2) / arr.biggest))
			pos = get_pos(arr.a[stack], arr);
	}
	else if (x >= WIN_WIDTH / 2 && arr.b_size > stack)
	{
		if (x - (WIN_WIDTH / 2) < arr.b[stack] *
			((WIN_WIDTH / 2) / arr.biggest))
			pos = get_pos(arr.b[stack], arr);
	}
	if (pos != -1)
	{
		pos == 1 ? color = declare_color(204, 0, 0) : color;
		pos == 0 ? color = declare_color(0, 204, 0) : color;
	}
	return (color);
}

void	declare_img(t_image *img, t_mlx *mlx)
{
	img->y = 0;
	img->i = 0;
	img->img = mlx_new_image(mlx->mlx, WIN_WIDTH, WIN_HEIGHT);
	img->img_data = mlx_get_data_addr(img->img, &img->bpp,
					&img->stride, &img->endian);
	img->bpp /= 8;
}

void	draw(t_mlx *mlx, t_stack arr)
{
	t_image	img;
	t_color	color;
	int		stack;

	stack = 0;
	declare_img(&img, mlx);
	while (img.y < WIN_HEIGHT)
	{
		img.x = 0;
		while (img.x < WIN_WIDTH)
		{
			color = color_array(stack, img.x, arr);
			img.i = (img.x * 4) + (img.y * img.stride);
			img.img_data[img.i++] = (char)color.blue;
			img.img_data[img.i++] = (char)color.green;
			img.img_data[img.i++] = (char)color.red;
			img.x++;
		}
		img.y++;
		if (img.y % (int)(WIN_HEIGHT / arr.size) == 0)
			stack++;
	}
	mlx_put_image_to_window(mlx->mlx, mlx->win, img.img, 0, 0);
	mlx_destroy_image(mlx->mlx, img.img);
}
