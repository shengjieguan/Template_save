/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   visual.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 15:13:05 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 15:13:06 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "visual.h"

int		key_pressed(int keycode, t_mlx *mlx)
{
	if (keycode == 49)
		mlx_clear_window(mlx->mlx, mlx->win);
	if (keycode == 53)
		exit(0);
	return (0);
}

int		loop_hook(t_mlx *mlx)
{
	char	*line;
	int		input;

	while (1)
	{
		input = 0;
		if ((get_next_line(0, &line) <= 0))
			break ;
		if ((input = check_input(line)) == 0)
		{
			write(1, "\033[0;31mError\n", 13);
			exit(0);
		}
		execute_input(input, &mlx->arr);
		mlx_clear_window(mlx->mlx, mlx->win);
		draw(mlx, mlx->arr);
		free(line);
		break ;
	}
	return (0);
}

void	get_sort(t_stack *arr)
{
	int tmp;
	int i;

	i = 0;
	while (i + 1 < arr->size)
	{
		if (arr->sort[i] > arr->sort[i + 1])
		{
			tmp = arr->sort[i];
			arr->sort[i] = arr->sort[i + 1];
			arr->sort[i + 1] = tmp;
			i = 0;
		}
		else
			i++;
	}
}

int		main(int argc, char **argv)
{
	t_mlx mlx;

	if (argc == 1)
	{
		write(1, "Usage : ./visual [number]\n", 26);
		return (0);
	}
	mlx.mlx = mlx_init();
	mlx.win = mlx_new_window(mlx.mlx, WIN_WIDTH, WIN_HEIGHT, "PUSH_SWAP");
	mlx.arr = get_stack(&argv[1], argc - 1);
	get_sort(&mlx.arr);
	draw(&mlx, mlx.arr);
	mlx_key_hook(mlx.win, key_pressed, &mlx);
	mlx_loop_hook(mlx.mlx, loop_hook, &mlx);
	mlx_loop(mlx.mlx);
	return (0);
}
