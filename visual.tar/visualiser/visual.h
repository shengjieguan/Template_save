/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   visual.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zliew <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/18 15:37:12 by zliew             #+#    #+#             */
/*   Updated: 2019/12/18 15:37:16 by zliew            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef VISUAL_H
# define VISUAL_H
# define WIN_HEIGHT 1200
# define WIN_WIDTH 1600
# include "../public/public.h"
# include "minilibx_macos/mlx.h"

typedef struct	s_mlx
{
	void	*mlx;
	void	*win;
	t_stack	arr;
}				t_mlx;

typedef struct	s_color
{
	int red;
	int blue;
	int green;
}				t_color;

typedef struct	s_image
{
	int		bpp;
	int		stride;
	int		endian;
	int		x;
	int		y;
	int		i;
	void	*img;
	char	*img_data;
}				t_image;

void			draw(t_mlx *mlx, t_stack arr);

#endif
